#!/usr/bin/env node
// -*- coding: utf-8 -*-
/**
 * Narzedzie pomocnicze: wycina fragment z zminifikowanego bundla PsychoJS.
 * Uzywane do weryfikacji atrapy w `js/psychojs_stub.mjs` wobec oryginalnego
 * kodu (bundl + mapa zrodlowa siedza w `Stop/lib/`).
 *
 *   node tests/bundle.mjs lib/psychojs-2025.1.1.js "isPressedIn" 0 800
 *   node tests/bundle.mjs lib/psychojs-2025.1.1.js.map "isEntryEmpty" 0 400
 *
 * Argumenty: <plik> <szukana fraza> [znakow przed] [znakow po]
 */
import fs from 'node:fs';

const [file, needle, before = '0', after = '600'] = process.argv.slice(2);
if (!file || !needle) {
  process.stderr.write('uzycie: node tests/bundle.mjs <plik> <fraza> [przed] [po]\n');
  process.exit(2);
}
const src = fs.readFileSync(file, 'utf8');
let i = -1;
let n = 0;
while ((i = src.indexOf(needle, i + 1)) !== -1) {
  n += 1;
  console.log(`--- trafienie #${n} @ ${i} ---`);
  console.log(src.slice(Math.max(0, i - Number(before)), i + Number(after)));
  if (n >= 3) break;
}
if (n === 0) console.log('NIE ZNALEZIONO');

