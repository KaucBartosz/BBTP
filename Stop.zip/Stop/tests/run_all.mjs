// -*- coding: utf-8 -*-
/**
 * Uruchamia WSZYSTKIE scenariusze w obu wersjach (fresh process per run)
 * i zapisuje wyniki w `Stop/out/<scenariusz>/`.
 *
 *     node tests/run_all.mjs                # wszystkie scenariusze
 *     node tests/run_all.mjs smoke mixed     # wybrane
 */
import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { writeScenarios, SCENARIOS } from './scenarios.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const OUT = path.resolve(HERE, '..', 'out');
const PY_RUNNER = path.join(HERE, 'py', 'run_main.py');
const JS_RUNNER = path.join(HERE, 'js', 'run_stop.mjs');

function run(cmd, args, label) {
  const started = Date.now();
  const res = spawnSync(cmd, args, {
    cwd: path.resolve(HERE, '..'),
    encoding: 'utf8',
    maxBuffer: 64 * 1024 * 1024,
    env: { ...process.env, PYTHONWARNINGS: 'ignore::DeprecationWarning' },
  });
  const wall = Date.now() - started;
  if (res.error) {
    return { label, ok: false, summary: null, wall, error: String(res.error) };
  }
  // ostatnia linia stdout to JSON-podsumowanie emitowane przez runnery
  const lines = (res.stdout ?? '').trim().split(/\r?\n/).filter((l) => l.trim().startsWith('{'));
  let summary = null;
  if (lines.length) {
    try { summary = JSON.parse(lines[lines.length - 1]); } catch { summary = null; }
  }
  return {
    label,
    ok: res.status === 0 && !!summary && summary.ok === true,
    exitCode: res.status,
    summary,
    wall,
    stderr: (res.stderr ?? '').trim(),
  };
}

function main() {
  const wanted = process.argv.slice(2).filter((a) => !a.startsWith('-'));
  const written = writeScenarios();
  const list = wanted.length
    ? written.filter((w) => wanted.includes(w.name))
    : written;
  if (!list.length) {
    process.stderr.write(`brak scenariuszy: ${wanted.join(', ')}\n`);
    return 2;
  }

  fs.mkdirSync(OUT, { recursive: true });
  const rows = [];
  for (const { name, file, description } of list) {
    const outDir = path.join(OUT, name);
    fs.mkdirSync(outDir, { recursive: true });
    process.stdout.write(`\n=== ${name} — ${description}\n`);
    const py = run(process.env.PYTHON ?? 'python', ['-W', 'ignore::DeprecationWarning', PY_RUNNER, '--scenario', file, '--out', outDir], `${name}/python`);
    const js = run(process.execPath, ['--no-warnings', JS_RUNNER, '--scenario', file, '--out', outDir], `${name}/node`);
    for (const r of [py, js]) {
      const mark = r.ok ? 'OK  ' : 'FAIL';
      const s = r.summary ?? {};
      process.stdout.write(
        `  ${mark} ${r.label.padEnd(14)} frames=${String(s.frames ?? '?').padStart(6)} ` +
        `trials=${String(s.trials ?? '?').padStart(3)} ` +
        `poprawne=${String(s.poprawne ?? '?').padStart(3)} bledne=${String(s.bledne ?? '?').padStart(3)} ` +
        `sr_RT=${String(s.sredni_rt_ms ?? '?').padStart(5)} ms  wall=${r.wall} ms\n`);
      if (!r.ok) {
        process.stdout.write(`       ! ${s.error ?? r.error ?? r.stderr ?? 'brak danych'}\n`);
      }
    }
    rows.push({ name, description, python: py, node: js });
  }

  fs.writeFileSync(path.join(OUT, 'run_all.json'),
    JSON.stringify(rows, null, 2), 'utf8');
  const failed = rows.filter((r) => !r.python.ok || !r.node.ok);
  process.stdout.write(`\n${rows.length - failed.length}/${rows.length} scenariuszy wykonane bez bledow\n`);
  return failed.length ? 1 : 0;
}

process.exitCode = main();

// eksport dla testow
export { SCENARIOS };
