// -*- coding: utf-8 -*-
/**
 * Wirtualny symulator PsychoJS dla testow parzystości (JS <-> Python).
 *
 * Dzieje `sim` jest JEDYNYM zrodlem prawdy: zegar wirtualny, generator
 * liczb pseudolosowych, kolejność zdarzen wejsciowych (klawiatura / mysz /
 * dotyk) oraz trace stanu bodzcow klatka po klatce.
 *
 * Protokol jest identyczny z tests/py/psychopy/_sim.py:
 *   - czas startuje w 0 i rośnie o `frame_ms` przy kazdym renderze (flipie),
 *   - LCG: state = (state * 1664525 + 1013904223) mod 2**32,
 *           random() = state / 2**32   (po aktualizacji),
 *   - zdarzenia sa dostarczane leniwie: przy kazdym odczycie wejscia
 *     (`getKeys`, `getPressed`, `getPos`, `isPressedIn`) flushujemy wszystkie
 *     akcje scenariusza, ktore maja `trial == biezaca proba` i czas
 *     `trial_start + at_ms <= teraz`.
 *
 * Wersja JS dodatkowo musi odtwarzac zachowanie przegladarki: zdarzenia
 * klawiatury/myszy sa *dostarczane do listenerow* (jak w prawdziwej
 * przegladarce), a nie odczytywane bezposrednio przez kod testu.
 */

export const FRAME_HISTORY_DECIMALS = 9;

// ------------------------------------------------------------------------ //
//  Generator liczb pseudolosowych (identyczny z tests/py/psychopy/_sim.py)
// ------------------------------------------------------------------------ //
export class LCG {
  constructor(seed = 1) {
    this.state = seed >>> 0;
    this.draws = 0;          // liczba wywolan - dowod zgodnosci strumienia RNG
  }

  random() {
    this.draws += 1;
    this.state = (Math.imul(this.state, 1664525) + 1013904223) >>> 0;
    return this.state / 4294967296;
  }

  // Odpowiednik *Python* random.randint(a, b) (wlaczony zakres).
  randint(a, b) {
    return a + Math.floor(this.random() * (b - a + 1));
  }

  /**
   * Ustawia stan na `seed + trial` przesunety o `k` krokow.
   *
   * Uzywane w trybie `reseed_per_trial`: `k` to liczba losowan, ktora
   * wypadla w oknie MIEDZY dwoma wywolaniami `eventManager.clearEvents()`,
   * czyli dokladnie losowania konfigurujace probu (`k` jest wykrywane
   * dynamicznie, wiec nie zalezy od tego ile ich jest w kodzie zrodlowym).
   */
  reseedWindow(seedValue, trial, k) {
    let s = (seedValue + trial) >>> 0;
    for (let i = 0; i < k; i += 1) s = (Math.imul(s, 1664525) + 1013904223) >>> 0;
    this.state = s;
  }
}

// ------------------------------------------------------------------------ //
//  Mapowanie nazw pygletowych (tak, jak w scenariuszu) na kod W3C
//  (tak, jak robi to przegladarka: event.key / event.code / event.keyCode)
// ------------------------------------------------------------------------ //
const DOM_KEYS = {
  space: { key: ' ', keyCode: 32, code: 'Space' },
  escape: { key: 'Escape', keyCode: 27, code: 'Escape' },
  esc: { key: 'Escape', keyCode: 27, code: 'Escape' },
  y: { key: 'y', keyCode: 89, code: 'KeyY' },
  n: { key: 'n', keyCode: 78, code: 'KeyN' },
  left: { key: 'ArrowLeft', keyCode: 37, code: 'ArrowLeft' },
  right: { key: 'ArrowRight', keyCode: 39, code: 'ArrowRight' },
  up: { key: 'ArrowUp', keyCode: 38, code: 'ArrowUp' },
  down: { key: 'ArrowDown', keyCode: 40, code: 'ArrowDown' },
  tab: { key: 'Tab', keyCode: 9, code: 'Tab' },
  enter: { key: 'Enter', keyCode: 13, code: 'Enter' },
  return: { key: 'Enter', keyCode: 13, code: 'Enter' },
};

function domKey(name) {
  if (name in DOM_KEYS) return DOM_KEYS[name];
  return { key: name, keyCode: 0, code: name };
}

let SIM = null;

export function setSim(s) {
  SIM = s;
}

export function sim() {
  if (SIM === null) throw new Error('SIM nie zostalo zainicjalizowane');
  return SIM;
}

// ------------------------------------------------------------------------ //
//  Symulacja
// ------------------------------------------------------------------------ //
export class Sim {
  constructor(scenario) {
    this.scenario = scenario;
    this.frameMs = Number(scenario.frame_ms ?? 1000 / 60);
    this.t = 0;
    this.frame = 0;
    this.seedValue = Number(scenario.seed ?? 1);
    this.rng = new LCG(this.seedValue);
    // `reseedPerTrial`: restart strumienia na kazdej prezentowanej klatce
    // (patrz `snapshot()`), dzieki czemu proby sa niezalezne - roznica w
    // liczbie losowan w probie N nie uniewaznia pozniejszych prob.
    this.reseedPerTrial = scenario.reseed_per_trial === true;
    // liczba losowan konfiguracyjnych jednej proby (`stopOnset`, `stopX`,
    // 2x strona, 2x pozycja dystraktorow, `distraction_speed`)
    this.setupDraws = Number(scenario.setup_draws ?? 7);
    this.rngAtTrialStart = 0;
    // skumulowana liczba losowan w chwili kazdego `eventManager.clearEvents()`;
    // roznica dwoch kolejnych wartosci = ile losowan "kosztowala" proba
    this.rngDrawsAtClear = [];
    this.rngWindowSizes = [];
    this.rngDrawsAtLastReseed = 0;
    this.setupDrawsSeen = new Set();
    this.rngTrace = [];
    this.recordTrace = scenario.record_trace !== false;
    this.traceStimNames = scenario.trace_stims ? [...scenario.trace_stims] : ['tlo', 'car', 'stop', 'jelonek', 'drzewo'];

    // okno (rozmiar w px; ustawiane przez stub Window)
    this.size = [Number(scenario.width_px ?? 1280), Number(scenario.height_px ?? 720)];

    this.actions = [...(scenario.actions ?? [])]
      .map((a, i) => ({ ...a, _seq: i }))
      .sort((a, b) => (Number(a.trial ?? -1) - Number(b.trial ?? -1)) || (Number(a.at_ms ?? 0) - Number(b.at_ms ?? 0)));
    this.actions = this.actions.map((a, i) => ({ ...a, _seq: i }));

    // kolejka zdarzen do dostarczenia (klawiatura / przyciski myszy)
    this.pending = [];
    this.pendingSeq = 0;

    this.currentTrial = -1;
    this.trialStartTime = 0;
    this.trialStarts = [];
    this.trialStartIndex = new Map();

    this.stopStimName = String(scenario.stop_stim ?? 'stop');
    this.stopVisible = false;
    this.stopVisibleAt = null;
    this.stopOnsets = [];

    this.keyEvents = [];

    this.mouseUnits = [0, 0];
    this.mouseButtons = [0, 0, 0];
    this.mouseClickCount = 0;

    this.stims = [];
    this.trace = [];
    this.traceMeta = {};
    this.log = [];

    // decyzje `Mouse.isPressedIn()` podmiescione w poblizu krawedzi bodzca.
    // Pelny log bylby wielki (wywolywanie co klatke), a raport potrzebuje
    // wylacznie przypadkow, w ktorych granica bodzca moze zmienic werdykt.
    this.edgeLog = [];

    // cel dostarczania zdarzen (ustawiany przez stuby PsychoJS)
    this.dispatch = () => {};
  }

  // ------------------------------------------------------------------ //
  //  zegar
  // ------------------------------------------------------------------ //
  advance() {
    this.t += this.frameMs / 1000;
    this.frame += 1;
  }

  get minSize() {
    return Math.min(this.size[0], this.size[1]);
  }

  /** pozycja myszy w pikselach canvasu (uklad EventManager) */
  get mousePx() {
    return this.unitsToPx(this.mouseUnits);
  }

  /** wspolrzedne w jednostkach okna (`units: 'height'`) -> piksele canvasu. */
  unitsToPx(units) {
    const m = this.minSize;
    return [units[0] * m + this.size[0] / 2, this.size[1] / 2 - units[1] * m];
  }

  snapshot() {
    this.watch();
    this.applyReseed('flip');
    if (!this.recordTrace) return;
    const row = { f: this.frame, t: round(this.t, FRAME_HISTORY_DECIMALS), tr: this.currentTrial };
    for (const stim of this.stims) {
      if (this.traceStimNames.includes(stim.simName)) {
        row[stim.simName] = [round(stim.pos[0], 6), round(stim.pos[1], 6), round(Number(stim.opacity), 4)];
      }
    }
    this.trace.push(row);
  }

  /**
   * Restart strumienia RNG na koncu klatki proby.
   *
   * Po kazdej klatce proby N nastepne losowania to konfiguracja proby N+1,
   * wiec stan ustawiamy na `seed + (N + 1)` przesuniety o `setupDraws` krokow.
   * Dzieki temu `stopOnset`, pozycje i predkosc dystraktorow proby N+1
   * zaleza wylacznie od N, a roznica w liczbie losowan w probie N nie
   * uniewaznia prob N+1, N+2, ...
   *
   * Wywolywane z DOWOLNEGO miejsca, w ktorym koncza sie losowania proby N:
   *  - `snapshot()` - klatka zostala zprezentowana (`win.flip()` / `render()`),
   *  - `sealFrame()` - klatka NIE zostala zprezentowana, bo `EachFrame`
   *    zwrocilo `Scheduler.Event.NEXT` zamiast `FLIP_REPEAT` (PsychoJS nie
   *    prezentuje ostatniej klatki rutyny).  W `main.py` ten przypadek nie
   *    istnieje: `win.flip()` jest wywolywane w kazdej iteracji petli.
   */
  applyReseed(tag) {
    if (!this.reseedPerTrial) return;
    if (process.env.SIM_DEBUG_RNG) {
      this.rngTrace.push([tag, this.frame, this.currentTrial, this.rng.draws, this.rng.state >>> 0]);
    }
    // ostatnie losowanie proby N = ostatnie losowanie przed restartem;
    // wszystko po nim nalezy juz do konfiguracji proby N+1
    this.rngDrawsAtLastReseed = this.rng.draws;
    this.rng.reseedWindow(this.seedValue, this.currentTrial + 1, this.setupDraws);
  }

  /** Klatka policzona, ale nie zprezentowana - patrz `applyReseed()`. */
  sealFrame() {
    this.applyReseed('seal');
  }

  /** Wykrywa moment pojawienia sie znaku STOP (niezaleznie od kadrowania petli). */
  watch() {
    if (this.currentTrial < 0) return;
    if (this.stopVisible) return;
    for (const stim of this.stims) {
      if (stim.simName === this.stopStimName) {
        if (Number(stim.opacity) > 0) {
          this.stopVisible = true;
          this.stopVisibleAt = this.t;
          this.stopOnsets.push([this.currentTrial, round(this.t, 9)]);
        }
        return;
      }
    }
  }

  // ------------------------------------------------------------------ //
  //  proba
  // ------------------------------------------------------------------ //
  /**
   * Wywolywane przez `eventManager.clearEvents()` na poczatku kazdej proby
   * (dokladnie tak, jak `event.clearEvents()` w wersji Python).
   */
  beginTrial() {
    this.currentTrial += 1;
    this.trialStartTime = this.t;
    this.trialStarts.push([this.currentTrial, round(this.t, 9)]);
    this.trialStartIndex.set(this.currentTrial, this.t);
    this.stopVisible = false;
    this.stopVisibleAt = null;
    this.keyEvents = [];
    // ile losowan RNG wykonano w tej probie (liczone do konca proby w meta)
    this.rngAtTrialStart = this.rng.draws;
    if (this.reseedPerTrial) {
      // `k` = dokladnie losowania konfiguracyjne TEJ proby: od ostatniego
      // restartu strumienia (koniec poprzedniej proby) do `clearEvents()`.
      // Sprawdzamy, czy jest ich dokladnie `setupDraws` - inaczej restart
      // w `applyReseed()` bylby przesuniety.
      const k = this.rng.draws - this.rngDrawsAtLastReseed;
      this.rngWindowSizes.push(k);
      this.setupDrawsSeen.add(k);
    }
    this.rngDrawsAtClear.push(this.rng.draws);
  }

  // ------------------------------------------------------------------ //
  //  wejscie
  // ------------------------------------------------------------------ //
  actionTime(act) {
    if ('after_stop_ms' in act || 'after_stop_frames' in act) {
      const delta = Number(act.after_stop_ms ?? 0) + Number(act.after_stop_frames ?? 0) * this.frameMs;
      const base = this.stopVisibleAt;
      if (base === null) return Infinity;
      return base + delta / 1000;
    }
    const base = this.trialStartIndex.has(this.currentTrial) ? this.trialStartIndex.get(this.currentTrial) : 0;
    return base + Number(act.at_ms ?? 0) / 1000;
  }

  schedule(when, fn) {
    this.pending.push({ when, seq: this.pendingSeq++, fn });
  }

  flush() {
    // 1) akcje scenariusza dla biezacej proby
    let i = 0;
    while (i < this.actions.length) {
      const act = this.actions[i];
      const trial = Number(act.trial ?? -1);
      if (trial > this.currentTrial) break;
      if (trial !== this.currentTrial) { i += 1; continue; }
      const when = this.actionTime(act);
      if (this.t + 1e-12 < when) { i += 1; continue; }
      this.actions.splice(i, 1);
      this.deliver(act, this.t);
    }

    // 2) zaplanowane zdarzenia (keyup, pointerup) w kolejnosci czasu
    let guard = 0;
    for (;;) {
      this.pending.sort((a, b) => (a.when - b.when) || (a.seq - b.seq));
      const next = this.pending[0];
      if (!next || this.t + 1e-12 < next.when) break;
      this.pending.shift();
      next.fn();
      if (++guard > 100000) break;
    }
  }

  deliver(act, now) {
    const kind = act.type;
    if (kind === 'key') {
      const name = act.key ?? 'space';
      const dk = domKey(name);
      const hold = Number(act.hold_ms ?? 40) / 1000;
      this.keyEvents.push({ name, tDown: now, tUp: now + hold });
      this.dispatch('keydown', { ...dk, repeat: false });
      this.schedule(now + hold, () => this.dispatch('keyup', { ...dk }));
      this.log.push({ t: round(now, 6), ev: 'key', name });
    } else if (kind === 'mouse_move') {
      this.mouseUnits = this.resolvePos(act);
      this.dispatch('pointermove', { offsetX: this.mousePx[0], offsetY: this.mousePx[1] });
      this.log.push({ t: round(now, 6), ev: 'mouse_move', pos: [...this.mouseUnits] });
    } else if (kind === 'click') {
      if ('pos' in act || 'target' in act) this.mouseUnits = this.resolvePos(act);
      const btn = Number(act.button ?? 0);
      const hold = Number(act.hold_ms ?? 40) / 1000;
      this.mouseButtons = [0, 0, 0];
      this.mouseButtons[btn] = 1;
      this.mouseClickCount += 1;
      this.dispatch('pointermove', { offsetX: this.mousePx[0], offsetY: this.mousePx[1] });
      this.dispatch('pointerdown', { button: btn, offsetX: this.mousePx[0], offsetY: this.mousePx[1] });
      this.schedule(now + hold, () => {
        this.mouseButtons[btn] = 0;
        this.dispatch('pointerup', { button: btn, offsetX: this.mousePx[0], offsetY: this.mousePx[1] });
      });
      this.log.push({ t: round(now, 6), ev: 'click', pos: [...this.mouseUnits], button: btn });
    } else if (kind === 'touch') {
      // ekran dotykowy - obslugiwany TYLKO przez wersje JS.
      // Wspolrzedne podajemy w jednostkach okna (`units: 'height'`), wiec
      // przeliczamy je na `clientX/clientY` tak samo jak `mousePx`.
      // UWAGA: prawdziwy ekran dotykowy emituje `touchstart` + `touchend`,
      // a `EventManager` trzyma `buttons.pressed[0] = 1` miedzy nimi - bez
      // `touchend` przycisk zostalby "wcisniety" na dobra probe.
      const units = this.resolvePos(act);
      const px = this.unitsToPx(units);
      const hold = Number(act.hold_ms ?? 40) / 1000;
      this.dispatch('touchstart', { touches: [{ clientX: px[0], clientY: px[1] }] });
      this.schedule(now + hold, () => this.dispatch('touchend', { touches: [] }));
      this.log.push({ t: round(now, 6), ev: 'touch', pos: units, client: [round(px[0], 3), round(px[1], 3)] });
    } else {
      throw new Error(`nieznany typ akcji: ${kind}`);
    }
  }

  resolvePos(act) {
    if ('target' in act) {
      const base = this.stimPos(act.target);
      const off = act.target_offset ?? [0, 0];
      return [Number(base[0]) + Number(off[0]), Number(base[1]) + Number(off[1])];
    }
    return [Number(act.pos[0]), Number(act.pos[1])];
  }

  stimPos(name) {
    for (const stim of this.stims) {
      if (stim.simName === name) return [Number(stim.pos[0]), Number(stim.pos[1])];
    }
    throw new Error(`brak bodzca ${name}`);
  }
}

function round(value, decimals) {
  const f = 10 ** decimals;
  return Math.round(value * f) / f;
}
