// -*- coding: utf-8 -*-
/**
 * Hak resolvera Node ESM: podmienia import `psychojs-2025.1.1.js` na atrapę
 * z `psychojs_stub.mjs`.  Dzieki temu ORYGINALNY `Stop/stop.js` jest
 * uruchamiany co do bajtu (bez zadnej modyfikacji) - zmienia sie tylko
 * implementacja importowanego frameworka.
 */
const STUB_URL = new URL('./psychojs_stub.mjs', import.meta.url).href;

const PSYCHOJS_RE = /psychojs-[\d.]+\.js(\?.*)?$/;

export async function resolve(specifier, context, nextResolve) {
  if (PSYCHOJS_RE.test(specifier)) {
    return { url: STUB_URL, shortCircuit: true, format: 'module' };
  }
  return nextResolve(specifier, context);
}
