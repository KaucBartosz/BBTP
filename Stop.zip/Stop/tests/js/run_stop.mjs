﻿// -*- coding: utf-8 -*-
/**
 * Harness testowy: uruchamia ORYGINALNY `Stop/stop.js` w wirtualnym
 * symulatorze PsychoJS i zapisuje wynik + trace do katalogu `out/`.
 *
 * Uzycie:
 *     node run_stop.mjs --scenario ../scenarios/smoke.json --out ../../out/smoke
 *
 * Kolejnosc (wazna!):
 *   1. utworzenie `Sim` (RNG + zegar wirtualny),
 *   2. instalacja atrapy DOM (`performance.now` -> `sim.t`),
 *   3. podmiana `Math.random` na LCG z symulatora,
 *   4. `window.electronTest` (integracja z launcherem),
 *   5. dynamiczny import `stop.js`  <- hak resolvera podmienia psychojs,
 *   6. pompowanie kolejki `requestAnimationFrame` do konca.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

import './loader.mjs';
import { Sim, setSim } from './sim.mjs';
import { installDOM } from './dom.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const STOP_DIR = path.resolve(HERE, '..', '..');

/** Buduje obiekt zdarzenia i dostarcza go do wlasciwego celu. */
function makeDispatcher(dom) {
  return function dispatch(type, props = {}) {
    const target = (type === 'keydown' || type === 'keyup') ? dom.window : dom.canvas;
    const ev = {
      type,
      target,
      currentTarget: target,
      defaultPrevented: false,
      preventDefault() { this.defaultPrevented = true; },
      stopPropagation() {},
      repeat: false,
      key: undefined,
      code: undefined,
      keyCode: 0,
      ...props,
    };
    target.dispatchEvent(ev);
    return ev;
  };
}

function parseArgs(argv) {
  const out = {};
  for (let i = 2; i < argv.length; i += 1) {
    const a = argv[i];
    if (a.startsWith('--')) {
      const key = a.slice(2);
      const next = argv[i + 1];
      if (typeof next === 'undefined' || next.startsWith('--')) { out[key] = true; }
      else { out[key] = next; i += 1; }
    }
  }
  return out;
}

async function main() {
  const args = parseArgs(process.argv);
  if (!args.scenario || !args.out) {
    process.stderr.write('uzycie: node run_stop.mjs --scenario <plik.json> --out <katalog>\n');
    return 2;
  }

  const scenarioPath = path.resolve(String(args.scenario));
  const outDir = path.resolve(String(args.out));
  const scenario = JSON.parse(fs.readFileSync(scenarioPath, 'utf8'));
  fs.mkdirSync(outDir, { recursive: true });

  // --- 1) symulator ------------------------------------------------------ //
  const sim = new Sim(scenario);
  setSim(sim);

  // --- 2) atrapa przegladarki ------------------------------------------- //
  const dom = installDOM({
    width: Number(scenario.width_px ?? 1280),
    height: Number(scenario.height_px ?? 720),
    now: () => sim.t * 1000.0,
    platform: String(scenario.platform ?? 'Win32'),
    search: String(scenario.url_params ?? ''),
  });
  dom.window.closed = false;

  // --- 3) RNG: ten sam LCG co w symulatorze Python ------------------------ //
  Math.random = () => sim.rng.random();

  // --- 4) integracja z launcherem (`window.electronTest`) ----------------- //
  let payload = null;
  let sentResults = 0;
  let closedByScript = false;
  if (scenario.launcher !== false) {
    dom.window.electronTest = {
      sendResults(p) { payload = p; sentResults += 1; },
      close() { closedByScript = true; dom.window.closed = true; },
    };
  }

  // --- 5) dostarczanie zdarzen do listenerow (jak w prawdziwej przegladarce) //
  sim.dispatch = makeDispatcher(dom);

  // opcjonalne dzienniki diagnostyczne
  if (process.env.SIM_DEBUG_MOUSE) globalThis.__mouse_log = [];

  // log konsoli (stop.js loguje m.in. cala paczke wynikow)
  const consoleLines = [];
  const realConsole = { log: console.log, warn: console.warn, error: console.error };
  const capture = (...args) => {
    consoleLines.push(args.map((a) => {
      if (typeof a === 'string') return a;
      try { return JSON.stringify(a); } catch { return String(a); }
    }).join(' '));
  };
  console.log = capture;
  console.warn = capture;
  console.error = (...args) => { capture(...args); realConsole.error(...args); };

  // --- 6) uruchomienie ORYGINALNEGO stop.js -------------------------------- //
  const t0 = process.hrtime.bigint();
  let error = null;
  let pumped = 0;
  const maxFrames = Number(scenario.max_frames ?? 500000);
  let stopped = false;

  process.on('unhandledRejection', (reason) => {
    if (!error) error = reason;
  });

  try {
    const entry = path.join(STOP_DIR, 'stop.js');
    await import(pathToFileURL(entry).href);
  } catch (e) {
    error = e;
  }

  if (!error) {
    while (dom.rafQueue.length > 0 && pumped < maxFrames) {
      const { cb } = dom.rafQueue.shift();
      try {
        // w prawdziwej przegladarce rAF dostaje `timestamp` startu klatki [ms]
        await cb(sim.t * 1000.0);
      } catch (e) {
        error = e;
        break;
      }
      pumped += 1;
      if (dom.window.closed) { stopped = true; break; }
    }
    if (!error && pumped >= maxFrames) {
      error = new Error(`przekroczono max_frames=${maxFrames}`);
    }
  }
  const wallMs = Number(process.hrtime.bigint() - t0) / 1e6;

  console.log = realConsole.log;
  console.warn = realConsole.warn;
  console.error = realConsole.error;

  // --- 7) zapis wynikow -------------------------------------------------- //
  const meta = {
    source: 'stop.js',
    runner: 'node',
    node: process.version,
    scenario: scenario.name ?? path.basename(scenarioPath, '.json'),
    seed: scenario.seed ?? null,
    frame_ms: sim.frameMs,
    launcher: scenario.launcher !== false,
    frames: sim.frame,
    raf_frames: pumped,
    virtual_ms: Math.round(sim.t * 1000.0 * 1000) / 1000,
    wall_ms: Math.round(wallMs * 10) / 10,
    trials_seen: sim.currentTrial + 1,
    trial_starts: sim.trialStarts,
    stop_onsets: sim.stopOnsets,
    rng_draws_total: sim.rng.draws,
    rng_draws_at_clear: sim.rngDrawsAtClear,
    rng_window_sizes: sim.rngWindowSizes,
    rng_state_final: sim.rng.state >>> 0,
    reseed_per_trial: sim.reseedPerTrial,
    rng_trace: process.env.SIM_DEBUG_RNG ? sim.rngTrace : undefined,
    window: sim.traceMeta.window ?? null,
    stims: sim.traceMeta.stims ?? {},
    input_log: sim.log,
    edge_log: sim.edgeLog,
    mouse_log: globalThis.__mouse_log ?? null,
    mouse_clicks: sim.mouseClickCount,
    send_results_calls: sentResults,
    closed_by_script: closedByScript,
    stopped_by_close: stopped,
    error: error ? (error.stack ?? String(error)) : null,
  };

  fs.writeFileSync(path.join(outDir, 'result_js.json'),
    JSON.stringify(payload, null, 2), 'utf8');
  fs.writeFileSync(path.join(outDir, 'meta_js.json'),
    JSON.stringify(meta, null, 2), 'utf8');
  if (sim.recordTrace) {
    fs.writeFileSync(path.join(outDir, 'trace_js.json'),
      JSON.stringify(sim.trace), 'utf8');
  }
  fs.writeFileSync(path.join(outDir, 'console_js.txt'),
    consoleLines.join('\n'), 'utf8');

  const lastErr = error ? String(error.stack ?? error).trim().split('\n').slice(-3).join(' | ') : null;
  process.stdout.write(JSON.stringify({
    ok: !error,
    error: lastErr,
    frames: sim.frame,
    trials: sim.currentTrial + 1,
    poprawne: (payload ?? {}).ilosc_poprawnych_nacisniec,
    bledne: (payload ?? {}).ilosc_blednych_nacisniec,
    sredni_rt_ms: (payload ?? {}).sredni_czas_reakcji,
    wall_ms: meta.wall_ms,
  }) + '\n');

  return error ? 1 : 0;
}

main().then((code) => { process.exitCode = code; }, (e) => {
  process.stderr.write(String(e?.stack ?? e) + '\n');
  process.exitCode = 1;
});

