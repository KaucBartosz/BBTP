// -*- coding: utf-8 -*-
/**
 * Rejestruje hak resolvera ESM (patrz `hooks.mjs`).  Ten plik należy
 * zaimportować PRZED oryginalnym `stop.js` (zaimportowany jest dynamicznie
 * w `run_stop.mjs`).
 */
import { register } from 'node:module';

register('./hooks.mjs', import.meta.url);
