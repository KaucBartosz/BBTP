// -*- coding: utf-8 -*-
/**
 * Atrapa PsychoJS 2025.1.1 dla testow parzystości.
 *
 * WAZNE: to NIE jest "wymyslone" API. Kazda klasa ponizej odtwarza logike
 * oryginalnego PsychoJS 2025.1.1, ktorego zrodla sa dostępne w tym repo:
 *   Stop/lib/psychojs-2025.1.1.js.map -> sourcesContent
 *   (src/util/Scheduler.js, src/util/Clock.js, src/util/Util.js,
 *    src/core/EventManager.js, src/core/Keyboard.js, src/core/Mouse.js,
 *    src/core/Window.js, src/core/PsychoJS.js, src/core/GUI.js,
 *    src/data/ExperimentHandler.js, src/data/TrialHandler.js,
 *    src/visual/VisualStim.js, src/visual/ImageStim.js, src/visual/TextStim.js,
 *    src/util/PsychObject.js)
 *
 * Odtwarza sie wylacznie logike, ktora test Stop obserwuje; miejsca zwiazane
 * z WebGL/PIXI/DOM sa zastapione stanem zapisywanym do `sim`.
 *
 * Znane zachowania (z oryginalnego zrodla), ktore sa celowo zachowane:
 *   - `Keyboard.getKeys({waitRelease:false})` zwraca nacisniecia z KEY_DOWN,
 *     a `Keyboard` ignoruje zdarzenia, dopoki nie zostanie `start()`-owany
 *     (w `welcome` jest to `callOnFlip`),
 *   - `EventManager.getKeys()` zjada (konsumuje) dopasowane klawisze,
 *   - `ExperimentHandler.addData()` zamienia tablice na `JSON.stringify`,
 *   - `ExperimentHandler.isEntryEmpty()` zwraca `keys(...).length > 0`
 *     (odwrócona logika - tak jest w oryginale, 2025.1.1),
 *   - `Window.getActualFrameRate()` liczy z `_lastDelta` schedulera, ktorego
 *     w chwili wywolania `updateInfo()` jeszcze nie ma -> `NaN`,
 *   - `VisualStim.contains()` uzywa polopeniomego `PIXI.Rectangle.contains`.
 */

import { sim } from './sim.mjs';

const r6 = (v) => Math.round(v * 1e6) / 1e6;

/**
 * Prog logowania decyzji `isPressedIn` w `sim.edgeLog` (w jednostkach okna).
 * 1e-6 jednostki okna = 7.2e-4 px przy oknie 1280x720, czyli ~9 ulp na
 * wspolrzednej typowej bodzca - wystarczajaco duzo, by zlapac przypadki
 * "klikniecie dokladnie na krawedzi", i zbyt wasko, zeby log pozostal maly.
 */
const EDGE_EPS_UNITS = 1e-6;

// ========================================================================= //
//  util
// ========================================================================= //
export function toNumerical(obj) {
  const conv = (v) => {
    const n = Number.parseFloat(v);
    if (Number.isNaN(n)) throw new Error(`unable to convert ${v} to a number`);
    return n;
  };
  if (typeof obj === 'number') return obj;
  if (Array.isArray(obj)) return obj.map(conv);
  if (typeof obj === 'string') return conv(obj);
  throw new Error('unable to convert the object to a number');
}

export function to_px(pos, posUnit, win) {
  if (posUnit === 'pix') return pos;
  if (posUnit === 'norm') return [pos[0] * win.size[0] / 2.0, pos[1] * win.size[1] / 2.0];
  if (posUnit === 'height') {
    const minSize = Math.min(win.size[0], win.size[1]);
    return [pos[0] * minSize, pos[1] * minSize];
  }
  throw new Error(`unsupported units: ${posUnit}`);
}

export function to_win(pos, posUnit, win) {
  const pos_px = to_px(pos, posUnit, win);
  if (win._units === 'pix') return pos_px;
  if (win._units === 'norm') return [pos_px[0] / (win.size[0] / 2), pos_px[1] / (win.size[1] / 2)];
  if (win._units === 'height') {
    const minSize = Math.min(win.size[0], win.size[1]);
    return [pos_px[0] / minSize, pos_px[1] / minSize];
  }
  throw new Error(`unknown window units: ${win._units}`);
}

export function getPositionFromObject(object, units) {
  let win;
  let pos = object;
  if (typeof object.getPos === 'function') {
    units = object.units;
    win = object.win;
    pos = object.getPos();
  }
  return to_px(pos, units, win);
}

export function pad(n, width = 2) {
  const integerPart = Number.parseInt(n);
  let decimalPart = (n + '').match(/\.[0-9]*/);
  if (!decimalPart) decimalPart = '';
  return (integerPart + '').padStart(width, '0') + decimalPart;
}

// UWAGA: to NIE jest `Math.round`-po-przedziale - takze nie jest to
// `random.randint(a, b+1)` z Pythona (patrz testy: `randint` ma rekordowane
// zachowanie `max` osiagalne = 999998, a nie 999999).
export function randint(min = 0, max) {
  let lo = min;
  let hi = max;
  if (typeof max === 'undefined') { hi = lo; lo = 0; }
  if (hi < lo) throw new Error('min should be <= max');
  return Math.floor(Math.random() * (hi - lo)) + lo;
}

export function round(input, places = 0) {
  return +(Math.round(`${input}e+${places}`) + `e-${places}`);
}

export function getUrlParameters() {
  return new URLSearchParams(globalThis.window.location.search.slice(1));
}

export function addInfoFromUrl(info) {
  getUrlParameters().forEach((value, key) => {
    if (key.indexOf('__') !== 0) info[key] = value;
  });
  return info;
}

export class Color {
  constructor(components) {
    if (typeof components === 'string') {
      this.name = components;
      this.int = components === 'white' ? 0xffffff : 0x000000;
      this.hex = `#${this.int.toString(16).padStart(6, '0')}`;
    } else {
      const [r = 0, g = 0, b = 0] = components;
      this.int = (r << 16) + (g << 8) + b;
      this.hex = `#${this.int.toString(16).padStart(6, '0')}`;
    }
  }
  get r() { return (this.int >> 16) & 255; }
  get g() { return (this.int >> 8) & 255; }
  get b() { return this.int & 255; }
}

export class MonotonicClock {
  constructor(startTime = MonotonicClock.getReferenceTime()) {
    this._timeAtLastReset = startTime;
  }
  getTime() { return MonotonicClock.getReferenceTime() - this._timeAtLastReset; }
  getLastResetTime() { return this._timeAtLastReset; }
  static getReferenceTime() {
    // zegar wirtualny: performance.now() jest podpięty do `sim.t`
    return performance.now() / 1000.0 - MonotonicClock._referenceTime;
  }
  static getDate(locales = 'en-CA', options) {
    const dataTimeOptions = Object.assign({
      hour12: false, year: 'numeric', month: '2-digit', day: '2-digit',
      hour: 'numeric', minute: 'numeric', second: 'numeric', fractionalSecondDigits: 3,
    }, options);
    return new Intl.DateTimeFormat(locales, dataTimeOptions).format(new Date());
  }
  static getDateStr() {
    return MonotonicClock.getDate()
      .replaceAll('/', '-')
      .replace(', ', '_')
      .replace(':', 'h')
      .replace(':', '.');
  }
}
MonotonicClock._referenceTime = performance.now() / 1000.0;

export class Clock extends MonotonicClock {
  constructor() { super(); }
  reset(newTime = 0) {
    this._timeAtLastReset = MonotonicClock.getReferenceTime() + newTime;
  }
  add(deltaTime) { this._timeAtLastReset += deltaTime; }
}

export class CountdownTimer extends Clock {
  constructor(startTime = 0) {
    super();
    this._timeAtLastReset = MonotonicClock.getReferenceTime();
    this._countdown_duration = startTime;
    if (startTime) this.add(startTime);
  }
  add(deltaTime) { this._timeAtLastReset += deltaTime; }
  reset(newTime) {
    if (typeof newTime === 'undefined') this._timeAtLastReset = MonotonicClock.getReferenceTime() + this._countdown_duration;
    else { this._countdown_duration = newTime; this._timeAtLastReset = MonotonicClock.getReferenceTime() + newTime; }
  }
  getTime() { return this._timeAtLastReset - MonotonicClock.getReferenceTime(); }
}

// ---- Scheduler (verbatim logika z src/util/Scheduler.js) ---------------- //
export class Scheduler {
  constructor(psychoJS) {
    this._psychoJS = psychoJS;
    this._taskList = [];
    this._currentTask = undefined;
    this._argsList = [];
    this._currentArgs = undefined;
    this._stopAtNextUpdate = false;
    this._stopAtNextTask = false;
    this._status = Scheduler.Status.STOPPED;
  }
  get status() { return this._status; }
  add(task, ...args) {
    this._taskList.push(task);
    this._argsList.push(args);
  }
  addConditional(condition, thenScheduler, elseScheduler) {
    const self = this;
    this.add(function () {
      if (condition()) self.add(thenScheduler); else self.add(elseScheduler);
      return Scheduler.Event.NEXT;
    });
  }
  start() {
    let schedulerResolve;
    const self = this;
    const update = async (timestamp) => {
      if (self._stopAtNextUpdate) {
        self._status = Scheduler.Status.STOPPED;
        schedulerResolve();
        return;
      }
      const state = await self._runNextTasks();
      if (state === Scheduler.Event.QUIT) {
        self._status = Scheduler.Status.STOPPED;
        schedulerResolve();
        return;
      }
      if (typeof self._timestamp !== 'undefined') {
        timestamp = self._timestamp;
        self._timestamp = undefined;
      }
      const lastTimestamp = (self._lastTimestamp === undefined) ? timestamp : self._lastTimestamp;
      self._lastDelta = timestamp - lastTimestamp;
      self._lastTimestamp = timestamp;
      self._psychoJS.window.render();
      requestAnimationFrame(update);
    };
    requestAnimationFrame(update);
    return new Promise((resolve) => { schedulerResolve = resolve; });
  }
  stop() {
    this._status = Scheduler.Status.STOPPED;
    this._stopAtNextTask = true;
    this._stopAtNextUpdate = true;
  }
  async _runNextTasks() {
    this._status = Scheduler.Status.RUNNING;
    let state = Scheduler.Event.NEXT;
    while (state === Scheduler.Event.NEXT) {
      if (this._stopAtNextTask) return Scheduler.Event.QUIT;
      if (typeof this._currentTask === 'undefined') {
        if (this._taskList.length > 0) {
          this._currentTask = this._taskList.shift();
          this._currentArgs = this._argsList.shift();
        } else {
          this._currentTask = undefined;
          this._currentArgs = undefined;
          return Scheduler.Event.QUIT;
        }
      }
      if (this._currentTask instanceof Function) {
        state = await this._currentTask(...this._currentArgs);
      } else {
        state = await this._currentTask._runNextTasks();
        if (state === Scheduler.Event.QUIT) {
          if (!this._psychoJS.experiment.experimentEnded) state = Scheduler.Event.NEXT;
        }
      }
      if (state !== Scheduler.Event.FLIP_REPEAT) {
        // Klatka, ktora nie zostanie FLIP_REPEAT, nie trafi do `render()`,
        // a wiec `Sim.snapshot()` (a z nim restart strumienia RNG w trybie
        // `reseed_per_trial`) na niej nie zadziala.  PsychoPy nie ma tego
        // problemu - tam `win.flip()` jest wywolywane w kazdej iteracji petli.
        // Wywolujemy wiec restart rowniez tutaj, zeby oba symulatory
        // restartowaly strumien w tym samym miejscu: po zakonczeniu klatki
        // proby, przed konfiguracja nastepnej.
        sim().sealFrame();
        this._currentTask = undefined;
        this._currentArgs = undefined;
      }
    }
    return state;
  }
}
Scheduler.Event = {
  NEXT: Symbol.for('NEXT'),
  FLIP_REPEAT: Symbol.for('FLIP_REPEAT'),
  FLIP_NEXT: Symbol.for('FLIP_NEXT'),
  QUIT: Symbol.for('QUIT'),
};
Scheduler.Status = { RUNNING: Symbol.for('RUNNING'), STOPPED: Symbol.for('STOPPED') };

export const util = {
  toNumerical, to_px, to_win, getPositionFromObject, pad, randint, round,
  getUrlParameters, addInfoFromUrl, Color,
  MonotonicClock, Clock, CountdownTimer,
  Scheduler,
  mix: (superclass) => (class extends superclass {}),
  toString: (obj) => {
    try { return JSON.stringify(obj); } catch { return String(obj); }
  },
  shuffle: (array, rng) => {
    if (!array || !Array.isArray(array)) return array;
    const f = rng || Math.random;
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(f() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
  },
};

// ========================================================================= //
//  core.Window
// ========================================================================= //
export class Window {
  constructor({ psychoJS, name, fullscr = false, color = new Color('black'), gamma = 1, units = 'pix', waitBlanking = false, autoLog = true, backgroundImage, backgroundFit } = {}) {
    this._psychoJS = psychoJS;
    this._name = name;
    this.fullscr = fullscr;
    this.color = color;
    this.gamma = gamma;
    this._units = units;
    this.waitBlanking = waitBlanking;
    this.autoLog = autoLog;
    this.backgroundImage = backgroundImage;
    this.backgroundFit = backgroundFit;

    this.size = [globalThis.window.innerWidth, globalThis.window.innerHeight];
    this._size = this.size;
    sim().size = [this.size[0], this.size[1]];
    sim().traceMeta.window = {
      size: [Number(this.size[0]), Number(this.size[1])],
      units: this._units,
      fullscr: !!fullscr,
      background_image: (typeof backgroundImage === 'undefined') ? null : backgroundImage,
      color: color.hex,
    };

    this._frameCount = 0;
    this._flipCallbacks = [];
    this._drawList = [];

    // "renderer"
    const canvas = globalThis.document.querySelector('canvas');
    this._renderer = { view: canvas, gl: undefined, render: () => {}, resize: () => {}, destroy: () => {} };
    globalThis.document.body.appendChild(canvas);
    this.psychoJS.eventManager.addMouseListeners(this._renderer);
  }

  // `WindowMixin` w oryginale: `psychoJS` / `win` / `units` jako gettery
  get psychoJS() { return this._psychoJS; }
  get win() { return this; }
  get units() { return this._units; }

  getActualFrameRate() {
    // dokladnie jak w oryginale: `1000 / _lastDelta` (delta w ms, w ms!)
    const lastDelta = this.psychoJS.scheduler._lastDelta;
    const fps = (lastDelta === 0) ? 60.0 : (1000.0 / lastDelta);
    return fps;
  }
  callOnFlip(fn, ...args) {
    this._flipCallbacks.push({ function: fn, arguments: args });
  }

  render() {
    if (!this._renderer) return;
    this._frameCount += 1;
    // 1) prezentacja klatki: zapis trace
    sim().snapshot();
    // 2) callbacki callOnFlip (kluczowy reset/start/clearEvents w `welcome`)
    for (const cb of this._flipCallbacks) cb.function(...cb.arguments);
    this._flipCallbacks = [];
    // 3) zegar wirtualny do przodu
    sim().advance();
  }

  addPixiObject() {}
  removePixiObject() {}

  close() {
    this._renderer = null;
  }

  closeFullScreen() {}
}

// ========================================================================= //
//  core.EventManager
// ========================================================================= //
const KEYCODE_MAP = {
  27: 'Escape', 32: 'Space', 37: 'ArrowLeft', 38: 'ArrowUp', 39: 'ArrowRight',
  40: 'ArrowDown', 13: 'Enter', 9: 'Tab', 89: 'KeyY', 78: 'KeyN',
};

const PYGLET_MAP = {
  escape: 'Escape', space: 'Space', left: 'ArrowLeft', right: 'ArrowRight',
  up: 'ArrowUp', down: 'ArrowDown', tab: 'Tab', return: 'Enter', enter: 'Enter',
  y: 'KeyY', n: 'KeyN', a: 'KeyA', b: 'KeyB', c: 'KeyC', d: 'KeyD', e: 'KeyE',
  f: 'KeyF', g: 'KeyG', h: 'KeyH', i: 'KeyI', j: 'KeyJ', k: 'KeyK', l: 'KeyL',
  m: 'KeyM', o: 'KeyO', p: 'KeyP', q: 'KeyQ', r: 'KeyR', s: 'KeyS', t: 'KeyT',
  u: 'KeyU', v: 'KeyV', w: 'KeyW', x: 'KeyX', z: 'KeyZ',
  0: 'Digit0', 1: 'Digit1', 2: 'Digit2', 3: 'Digit3', 4: 'Digit4',
  5: 'Digit5', 6: 'Digit6', 7: 'Digit7', 8: 'Digit8', 9: 'Digit9',
};

const REVERSE_PYGLET_MAP = {};
for (const k in PYGLET_MAP) REVERSE_PYGLET_MAP[PYGLET_MAP[k]] = k;

function w3c2pyglet(code) {
  return (code in REVERSE_PYGLET_MAP) ? REVERSE_PYGLET_MAP[code] : 'N/A';
}

export class EventManager {
  constructor(psychoJS) {
    this._psychoJS = psychoJS;
    this._keyBuffer = [];
    this._addKeyListeners();
    this._mouseInfo = {
      pos: [0, 0],
      wheelRel: [0.0, 0.0],
      buttons: { pressed: [0, 0, 0], clocks: [new Clock(), new Clock(), new Clock()], times: [0.0, 0.0, 0.0] },
      moveClock: new Clock(),
    };
  }

  getKeys({ keyList = null, timeStamped = false } = {}) {
    sim().flush();
    if (keyList != null) keyList = EventManager.pyglet2w3c(keyList);
    let newBuffer = [];
    const keys = [];
    for (let i = 0; i < this._keyBuffer.length; ++i) {
      const key = this._keyBuffer[i];
      let keyId = null;
      if (keyList != null) {
        let index = keyList.indexOf(key.code);
        if (index < 0) index = keyList.indexOf(KEYCODE_MAP[key.keyCode]);
        if (index >= 0) keyId = REVERSE_PYGLET_MAP[keyList[index]];
      } else {
        keyId = REVERSE_PYGLET_MAP[key.code];
      }
      if (keyId != null) {
        if (timeStamped) keys.push([keyId, key.timestamp]); else keys.push(keyId);
      } else {
        newBuffer.push(key);
      }
    }
    this._keyBuffer = newBuffer;
    return keys;
  }

  getMouseInfo() { return this._mouseInfo; }

  clearEvents() {
    // UWAGA: `clearEvents()` jest w `stop.js` wywolywane dokladnie raz na
    // probe (w `driveRoutineBegin`) - uzywamy tego jak wyznacznika granicy
    // proby, tak jak `event.clearEvents()` w wersji Python.
    sim().flush();
    sim().beginTrial();
    this.clearKeys();
  }

  clearKeys() { this._keyBuffer = []; }

  addMouseListeners(renderer) {
    const self = this;
    const view = renderer.view;
    view.addEventListener('pointerdown', (event) => {
      event.preventDefault();
      self._mouseInfo.buttons.pressed[event.button] = 1;
      self._mouseInfo.pos = [event.offsetX, event.offsetY];
    }, false);
    view.addEventListener('pointerup', (event) => {
      event.preventDefault();
      self._mouseInfo.buttons.pressed[event.button] = 0;
      self._mouseInfo.pos = [event.offsetX, event.offsetY];
    }, false);
    view.addEventListener('pointerout', (event) => {
      self._mouseInfo.buttons.pressed = [0, 0, 0];
      self._mouseInfo.pos = [event.offsetX, event.offsetY];
    }, false);
    view.addEventListener('pointermove', (event) => {
      event.preventDefault();
      self._mouseInfo.moveClock.reset();
      self._mouseInfo.pos = [event.offsetX, event.offsetY];
    }, false);
    view.addEventListener('touchstart', (event) => {
      event.preventDefault();
      self._mouseInfo.buttons.pressed[0] = 1;
      self._mouseInfo.pos = [event.touches[0].clientX, event.touches[0].clientY];
    }, false);
    view.addEventListener('touchend', (event) => {
      event.preventDefault();
      self._mouseInfo.buttons.pressed[0] = 0;
    }, false);
  }

  _addKeyListeners() {
    const self = this;
    window.addEventListener('keydown', (event) => {
      const timestamp = MonotonicClock.getReferenceTime();
      let code = PYGLET_MAP[event.key];
      if (typeof code === 'undefined') code = KEYCODE_MAP[event.keyCode];
      self._keyBuffer.push({ code, key: event.key, keyCode: event.keyCode, timestamp });
      event.stopPropagation();
    });
  }

  static pyglet2w3c(list) {
    return list.map((k) => (typeof PYGLET_MAP[k] === 'undefined' ? k : PYGLET_MAP[k]));
  }
  static w3c2pyglet(code) { return w3c2pyglet(code); }
  static keycode2w3c(keycode) { return KEYCODE_MAP[keycode]; }
}

// ========================================================================= //
//  core.Keyboard
// ========================================================================= //
export class KeyPress {
  constructor(code, tDown, name) {
    this.code = code;
    this.tDown = tDown;
    this.name = (typeof name !== 'undefined') ? name : w3c2pyglet(code);
    this.duration = undefined;
    this.rt = undefined;
  }
}

export class Keyboard {
  constructor({ psychoJS, bufferSize = 10000, waitForStart = false, clock, autoLog = false } = {}) {
    this._psychoJS = psychoJS;
    this._bufferSize = bufferSize;
    this._waitForStart = waitForStart;
    this._clock = (typeof clock === 'undefined') ? new Clock() : clock;
    this._status = waitForStart ? PsychoJS.Status.NOT_STARTED : PsychoJS.Status.STARTED;
    this.clearEvents();
    this._addKeyListeners();
  }

  // `Keyboard` w oryginale deklaruje `clock`/`status` przez
  // `PsychObject._addAttribute`, czyli jako accessory pod `_clock`/`_status` -
  // dlatego `stop.js` moze robic `key_resp.clock.reset()` i `key_resp.status`,
  // a `welcomeRoutineBegin` resetuje `status` do NOT_STARTED.
  get clock() { return this._clock; }
  set clock(v) { this._clock = v; }
  get status() { return this._status; }
  set status(v) { this._status = v; }

  start() { this._status = PsychoJS.Status.STARTED; }
  stop() { this._status = PsychoJS.Status.STOPPED; }

  getEvents() {
    if (this._bufferLength === 0) return [];
    const filteredEvents = [];
    const bufferWrap = (this._bufferLength === this._bufferSize);
    let i = bufferWrap ? this._bufferIndex : -1;
    do {
      i = (i + 1) % this._bufferSize;
      const keyEvent = this._circularBuffer[i];
      if (keyEvent) filteredEvents.push(keyEvent);
    } while (i !== this._bufferIndex);
    return filteredEvents;
  }

  getKeys({ keyList = [], waitRelease = true, clear = true } = {}) {
    sim().flush();
    if (this._bufferLength === 0) return [];

    let keyPresses = [];
    const bufferWrap = (this._bufferLength === this._bufferSize);
    let i = bufferWrap ? this._bufferIndex : -1;
    do {
      i = (i + 1) % this._bufferSize;
      const keyEvent = this._circularBuffer[i];
      if (keyEvent && keyEvent.status === Keyboard.KeyStatus.KEY_UP) {
        if (keyList.length === 0 || keyList.includes(keyEvent.pigletKey)) {
          const precedingKeydownIndex = keyEvent.keydownIndex;
          if (typeof precedingKeydownIndex !== 'undefined') {
            const precedingKeydownEvent = this._circularBuffer[precedingKeydownIndex];
            if (precedingKeydownEvent) {
              const tDown = precedingKeydownEvent.timestamp;
              const keyPress = new KeyPress(keyEvent.code, tDown, keyEvent.pigletKey);
              keyPress.rt = tDown - this._clock.getLastResetTime();
              keyPress.duration = keyEvent.timestamp - precedingKeydownEvent.timestamp;
              keyPresses.push(keyPress);
              if (clear) this._circularBuffer[precedingKeydownIndex] = null;
            }
          }
          if (clear) this._circularBuffer[i] = null;
        }
      }
    } while (i !== this._bufferIndex);

    if (!waitRelease) {
      for (const unmatchedKeyDownIndex of this._unmatchedKeydownMap.values()) {
        const keyEvent = this._circularBuffer[unmatchedKeyDownIndex];
        if (keyEvent) {
          if (keyList.length === 0 || keyList.includes(keyEvent.pigletKey)) {
            const tDown = keyEvent.timestamp;
            const keyPress = new KeyPress(keyEvent.code, tDown, keyEvent.pigletKey);
            keyPress.rt = tDown - this._clock.getLastResetTime();
            keyPresses.push(keyPress);
            if (clear) {
              this._unmatchedKeydownMap.delete(keyEvent.code);
              this._circularBuffer[unmatchedKeyDownIndex] = null;
            }
          }
        }
      }
    }

    if (clear && keyList.length === 0) this.clearEvents();
    return keyPresses;
  }

  clearEvents() {
    this._circularBuffer = new Array(this._bufferSize);
    this._bufferLength = 0;
    this._bufferIndex = -1;
    this._previousKeydownKey = undefined;
    this._unmatchedKeydownMap = new Map();
  }

  static includes(list, keyName) {
    if (!Array.isArray(list)) return false;
    return typeof list.find((kp) => kp.name === keyName) !== 'undefined';
  }

  _addKeyListeners() {
    const self = this;
    window.addEventListener('keydown', (event) => {
      if (event.repeat) return;
      const timestamp = MonotonicClock.getReferenceTime();
      if (self._status !== PsychoJS.Status.STARTED) return;
      self._previousKeydownKey = event.key;
      let code = PYGLET_MAP[event.key];
      if (typeof code === 'undefined') code = KEYCODE_MAP[event.keyCode];
      const pigletKey = w3c2pyglet(code);
      self._bufferIndex = (self._bufferIndex + 1) % self._bufferSize;
      self._bufferLength = Math.min(self._bufferLength + 1, self._bufferSize);
      self._circularBuffer[self._bufferIndex] = {
        code, key: event.key, pigletKey, status: Keyboard.KeyStatus.KEY_DOWN, timestamp,
      };
      self._unmatchedKeydownMap.set(event.code, self._bufferIndex);
      event.stopPropagation();
    });

    window.addEventListener('keyup', (event) => {
      const timestamp = MonotonicClock.getReferenceTime();
      if (self._status !== PsychoJS.Status.STARTED) return;
      self._previousKeydownKey = undefined;
      let code = PYGLET_MAP[event.key];
      if (typeof code === 'undefined') code = KEYCODE_MAP[event.keyCode];
      const pigletKey = w3c2pyglet(code);
      self._bufferIndex = (self._bufferIndex + 1) % self._bufferSize;
      self._bufferLength = Math.min(self._bufferLength + 1, self._bufferSize);
      self._circularBuffer[self._bufferIndex] = {
        code, key: event.key, pigletKey, status: Keyboard.KeyStatus.KEY_UP, timestamp,
      };
      const corresponding = self._unmatchedKeydownMap.get(event.code);
      if (typeof corresponding !== 'undefined') {
        self._circularBuffer[self._bufferIndex].keydownIndex = corresponding;
        self._unmatchedKeydownMap.delete(event.code);
      }
      event.stopPropagation();
    });
  }
}
Keyboard.KeyStatus = { KEY_DOWN: Symbol.for('KEY_DOWN'), KEY_UP: Symbol.for('KEY_UP') };

// ========================================================================= //
//  core.Mouse
// ========================================================================= //
export class Mouse {
  constructor({ name, win, autoLog = true } = {}) {
    this._psychoJS = win._psychoJS;
    this._name = name;
    this._win = win;
    this._units = win.units;
    this._visible = 1;
    this.autoLog = autoLog;
    this._lastPos = undefined;
    this.status = PsychoJS.Status.NOT_STARTED;
  }

  // `MinimalStim`/`PsychObject`: `psychoJS`, `win`, `units` jako gettery
  get psychoJS() { return this._psychoJS; }
  get win() { return this._win; }
  get units() { return this._units; }
  get visible() { return this._visible; }
  set visible(v) { this._visible = v; }

  getPos() {
    const mouseInfo = this.psychoJS.eventManager.getMouseInfo();
    const pos_px = mouseInfo.pos.slice();
    pos_px[0] = pos_px[0] - this.win.size[0] / 2;
    pos_px[1] = this.win.size[1] / 2 - pos_px[1];
    this._lastPos = to_win(pos_px, 'pix', this._win);
    return this._lastPos;
  }

  getPressed(getTime = false) {
    sim().flush();
    const buttonPressed = this.psychoJS.eventManager.getMouseInfo().buttons.pressed.slice();
    if (globalThis.__mouse_log) {
      globalThis.__mouse_log.push({
        t: r6(sim().t), tr: sim().currentTrial, pressed: buttonPressed.slice(),
        prev: globalThis._prevMousePressed ?? null,
      });
    }
    if (!getTime) return buttonPressed;
    return [buttonPressed, this.psychoJS.eventManager.getMouseInfo().buttons.times.slice()];
  }

  isPressedIn(...args) {
    sim().flush();
    const [{ shape: shapeMaybe } = {}] = args.filter((v) => !!v);
    const isShape = (object) => !!(object && typeof object.contains === 'function');
    const shape = (isShape(shapeMaybe) ? shapeMaybe : args.find(isShape)) || shapeMaybe;
    const info = this.psychoJS.eventManager.getMouseInfo();
    const { pressed } = info.buttons;
    const hasButtonPressed = pressed.some((v) => v > 0);
    const result = hasButtonPressed && !!shape && typeof shape.contains === 'function'
      ? shape.contains(this) : false;
    // --- pomiar: marginesy decyzji wobec krawedzi (dokladnie, bez zaokraglania)
    // Uzywamy DOKLADNIE tych samych wartosci, ktore porownuje `contains()`:
    // `getPositionFromObject(mouse)` (px, (0,0) w srodku okna, y w gore)
    // oraz `_getBoundingBox_px()`.  Kolejnosc marginesow jak w wersji Python:
    // [lewa, prawa, dolna, gorna]; >0 = wewnatrz, 0 = dokladnie na krawedzi.
    if (shape && typeof shape._getBoundingBox_px === 'function') {
      const box = shape._getBoundingBox_px();
      const m = getPositionFromObject(this);
      const scale = 1 / Math.min(this.win.size[0], this.win.size[1]);
      const margins = [
        (m[0] - box.x) * scale,
        (box.right - m[0]) * scale,
        (m[1] - box.y) * scale,
        (box.bottom - m[1]) * scale,
      ];
      if (Math.min(...margins) <= EDGE_EPS_UNITS) {
        sim().edgeLog.push({
          t: sim().t,
          tr: sim().currentTrial,
          stim: shape.simName ?? null,
          pressed: pressed.slice(),
          mousePx: [m[0], m[1]],
          stimPos: [shape.pos[0], shape.pos[1]],
          size: [shape.size[0], shape.size[1]],
          margins,
          result,
        });
      }
    }
    return result;
  }
}

// ========================================================================= //
//  visual
// ========================================================================= //
class Rectangle {
  constructor(x = 0, y = 0, width = 0, height = 0) {
    this.x = x; this.y = y; this.width = width; this.height = height;
  }
  get left() { return this.x; }
  get right() { return this.x + this.width; }
  get top() { return this.y; }
  get bottom() { return this.y + this.height; }
  // UWAGA: PIXI.Rectangle.contains jest polopeniome ("<" po prawej/dolnej).
  contains(x, y) {
    return (x >= this.left && x < this.right && y >= this.top && y < this.bottom);
  }
}

class Stim {
  constructor({ name, win, units, ori, opacity, depth, pos, anchor, size, autoDraw, autoLog }) {
    this._name = name;
    this._win = win;
    this.psychoJS = win._psychoJS;
    this._autoDraw = !!autoDraw;
    this._units = (typeof units === 'undefined' || units === null) ? win.units : units;
    this._pos = toNumerical((typeof pos === 'undefined' || pos === null) ? [0, 0] : pos);
    this._anchor = (typeof anchor === 'undefined') ? 'center' : anchor;
    this._size = (typeof size === 'undefined' || size === null) ? undefined : toNumerical(size);
    this._ori = (typeof ori === 'undefined' || ori === null) ? 0.0 : ori;
    this._opacity = (typeof opacity === 'undefined' || opacity === null) ? 1.0 : opacity;
    this._depth = (typeof depth === 'undefined' || depth === null) ? 0 : depth;
    this._boundingBox = new Rectangle();
    this._drawList = [];
    this.status = PsychoJS.Status.NOT_STARTED;
    this.simName = name;
  }

  get units() { return this._units; }
  get win() { return this._win; }
  get name() { return this._name; }
  get pos() { return this._pos; }
  set pos(v) { this.setPos(v); }
  get size() { return this._size; }
  set size(v) { this.setSize(v); }
  get opacity() { return this._opacity; }
  setOpacity(v) {
    this._opacity = v;
    return this;
  }
  setPos(pos) {
    this._pos = toNumerical(pos);
    if (this._boundingBox.width) {
      this._boundingBox.x = this._pos[0] - this._boundingBox.width / 2;
      this._pos[0]; // no-op
    }
    this._estimateBoundingBox();
    return this;
  }
  setSize(size) {
    this._size = toNumerical(size);
    this._estimateBoundingBox();
    return this;
  }
  setDepth(depth = 0) { this._depth = depth; return this; }

  setAutoDraw(autoDraw) {
    this._autoDraw = autoDraw;
    if (autoDraw) this.draw(); else this.hide();
  }

  draw() {
    this.status = PsychoJS.Status.STARTED;
    this._win._drawList.push(this);
  }

  hide() {
    const i = this._win._drawList.indexOf(this);
    if (i >= 0) this._win._drawList.splice(i, 1);
    this.status = PsychoJS.Status.STOPPED;
  }

  _getBoundingBox_px() {
    if (this._units === 'pix') return this._boundingBox;
    if (this._units === 'norm') {
      return new Rectangle(
        this._boundingBox.x * this._win.size[0] / 2,
        this._boundingBox.y * this._win.size[1] / 2,
        this._boundingBox.width * this._win.size[0] / 2,
        this._boundingBox.height * this._win.size[1] / 2,
      );
    }
    if (this._units === 'height') {
      const minSize = Math.min(this._win.size[0], this._win.size[1]);
      return new Rectangle(
        this._boundingBox.x * minSize,
        this._boundingBox.y * minSize,
        this._boundingBox.width * minSize,
        this._boundingBox.height * minSize,
      );
    }
    throw new Error(`unknown units: ${this._units}`);
  }

  contains(object) {
    const objectPos_px = getPositionFromObject(object);
    return this._getBoundingBox_px().contains(objectPos_px[0], objectPos_px[1]);
  }
}

export class ImageStim extends Stim {
  constructor(options = {}) {
    super(options);
    this._image = options.image;
    this.simName = String(options.image ?? '').replace(/\\/g, '/').split('/').pop().replace(/\.[^.]*$/, '');
    this._size = (typeof options.size === 'undefined' || options.size === null) ? [1, 1] : toNumerical(options.size);
    this._estimateBoundingBox();
    sim().stims.push(this);
    sim().traceMeta.stims = sim().traceMeta.stims || {};
    sim().traceMeta.stims[this.simName] = {
      pos: [Number(this._pos[0]), Number(this._pos[1])],
      size: [Number(this._size[0]), Number(this._size[1])],
      opacity: Number(this._opacity),
      units: this._units,
      depth: Number(this._depth),
    };
  }

  _getDisplaySize() { return this._size; }

  _estimateBoundingBox() {
    const size = this._getDisplaySize();
    if (typeof size !== 'undefined') {
      this._boundingBox = new Rectangle(
        this._pos[0] - size[0] / 2,
        this._pos[1] - size[1] / 2,
        size[0],
        size[1],
      );
    }
  }
}

export class TextStim extends Stim {
  constructor(options = {}) {
    super(options);
    this._text = options.text;
    this.simName = 'text';
    // brak WebGL - symulujemy rozmiar tekstu z `height`
    this._fakeTextWidth = Number(options.textWidth ?? 1.2);
    this._fakeTextHeight = Number(options.height ?? 0.05);
    this._estimateBoundingBox();
  }

  _estimateBoundingBox() {
    this._boundingBox = new Rectangle(
      this._pos[0] - this._fakeTextWidth / 2,
      this._pos[1] - this._fakeTextHeight,
      this._fakeTextWidth,
      this._fakeTextHeight,
    );
  }
}

export const visual = { Stim, ImageStim, TextStim };

// ========================================================================= //
//  data.ExperimentHandler
// ========================================================================= //
export class ExperimentHandler {
  constructor({ psychoJS, name, extraInfo, dataFileName } = {}) {
    this._psychoJS = psychoJS;
    this._name = name;
    this._extraInfo = extraInfo ?? {};
    this._experimentName = (typeof this._extraInfo.expName === 'string' && this._extraInfo.expName.length > 0)
      ? this._extraInfo.expName : 'UNKNOWN';
    this._participant = (typeof this._extraInfo.participant === 'string' && this._extraInfo.participant.length > 0)
      ? this._extraInfo.participant : 'PARTICIPANT';
    this._session = (typeof this._extraInfo.session === 'string' && this._extraInfo.session.length > 0)
      ? this._extraInfo.session : 'SESSION';
    this._datetime = (typeof this._extraInfo.date !== 'undefined') ? this._extraInfo.date : MonotonicClock.getDateStr();
    this._dataFileName = dataFileName ?? `${this._participant}_${this._experimentName}_${this._datetime}`;

    this._loops = [];
    this._unfinishedLoops = [];
    this._trialsKeys = [];
    this._trialsData = [];
    this._currentTrialData = {};
    this._isCsvHeaderNeeded = true;
    this._experimentEnded = false;
  }

  get extraInfo() { return this._extraInfo; }
  get experimentEnded() { return this._experimentEnded; }
  set experimentEnded(ended) { this._experimentEnded = ended; }
  get thisEntry() { return this._currentTrialData; }
  get _thisEntry() { return this._currentTrialData; }
  get _entries() { return this._trialsData; }

  // UWAGA: oryginalna implementacja zwraca `length > 0` (logika odwrócona).
  isEntryEmpty() { return Object.keys(this._currentTrialData).length > 0; }

  addLoop(loop) {
    this._loops.push(loop);
    this._unfinishedLoops.push(loop);
    loop.experimentHandler = this;
  }

  removeLoop(loop) {
    const index = this._unfinishedLoops.indexOf(loop);
    if (index !== -1) this._unfinishedLoops.splice(index, 1);
  }

  addData(key, value) {
    if (this._trialsKeys.indexOf(key) === -1) this._trialsKeys.push(key);
    if (Array.isArray(value)) value = JSON.stringify(value);
    this._currentTrialData[key] = value;
  }

  nextEntry(snapshots) {
    if (typeof snapshots !== 'undefined') {
      if (!Array.isArray(snapshots)) snapshots = [snapshots];
      for (const snapshot of snapshots) {
        const attributes = ExperimentHandler._getLoopAttributes(snapshot);
        for (const a in attributes) {
          if (Object.prototype.hasOwnProperty.call(attributes, a)) this._currentTrialData[a] = attributes[a];
        }
      }
    } else {
      for (const loop of this._unfinishedLoops) {
        const attributes = ExperimentHandler._getLoopAttributes(loop);
        for (const a in attributes) {
          if (Object.prototype.hasOwnProperty.call(attributes, a)) this._currentTrialData[a] = attributes[a];
        }
      }
    }
    for (const a in this.extraInfo) {
      if (Object.prototype.hasOwnProperty.call(this.extraInfo, a)) this._currentTrialData[a] = this.extraInfo[a];
    }
    this._trialsData.push(this._currentTrialData);
    this._currentTrialData = {};
  }

  async save() { return undefined; }

  getResultAsCsv() { return JSON.stringify(this._trialsData); }

  static _getLoopAttributes(loop) {
    const properties = ['thisRepN', 'thisTrialN', 'thisN', 'thisIndex', 'stepSizeCurrent', 'ran', 'order'];
    const attributes = {};
    const loopName = loop.name;
    for (const loopProperty in loop) {
      if (properties.includes(loopProperty)) {
        const key = (loopProperty === 'stepSizeCurrent') ? loopName + '.stepSize' : loopName + '.' + loopProperty;
        attributes[key] = loop[loopProperty];
      }
    }
    if (typeof loop.getCurrentTrial === 'function') {
      const currentTrial = loop.getCurrentTrial();
      for (const trialProperty in currentTrial) attributes[trialProperty] = currentTrial[trialProperty];
    }
    return attributes;
  }
}
ExperimentHandler.SaveFormat = { CSV: Symbol.for('CSV'), DATABASE: Symbol.for('DATABASE') };
ExperimentHandler.Environment = { SERVER: Symbol.for('SERVER'), LOCAL: Symbol.for('LOCAL') };

// ========================================================================= //
//  data.TrialHandler
// ========================================================================= //
export class TrialHandler {
  constructor({ psychoJS, trialList = [undefined], nReps, method = TrialHandler.Method.RANDOM, extraInfo = [], seed, name, autoLog = true } = {}) {
    this._psychoJS = psychoJS;
    this._trialList = (typeof trialList === 'undefined') ? [undefined]
      : (Array.isArray(trialList) ? (trialList.length === 0 ? [undefined] : trialList) : trialList);
    this._nReps = nReps;
    this._method = method;
    this._extraInfo = extraInfo;
    this._name = name;
    this._autoLog = autoLog;
    this._seed = seed;

    this.trialList = Array.isArray(this._trialList) ? this._trialList : [undefined];
    this.nReps = nReps;
    this.name = name;
    this.method = method;
    this.seed = seed;

    this.nStim = this.trialList.length;
    this.nTotal = this.nReps * this.nStim;
    this.nRemaining = this.nTotal;
    this.thisRepN = 0;
    this.thisTrialN = -1;
    this.thisN = -1;
    this.thisIndex = 0;
    this.ran = 0;
    this.order = -1;
    this._snapshots = [];
    this._prepareSequence();
    this._experimentHandler = null;
    this.thisTrial = null;
    this._finished = false;
  }

  get experimentHandler() { return this._experimentHandler; }
  set experimentHandler(exp) { this._experimentHandler = exp; }
  get finished() { return this._finished; }
  set finished(isFinished) {
    this._finished = isFinished;
    this._snapshots.forEach((snapshot) => { snapshot.finished = isFinished; });
  }

  [Symbol.iterator]() {
    return {
      next: () => {
        this.thisTrialN++;
        this.thisN++;
        this.nRemaining--;
        if (this.thisTrialN === this.nStim) { this.thisTrialN = 0; this.thisRepN++; }
        if (this.thisRepN >= this.nReps) { this.thisTrial = null; return { done: true }; }
        this.thisIndex = this._trialSequence[this.thisRepN][this.thisTrialN];
        this.thisTrial = this.trialList[this.thisIndex];
        this.ran = 1;
        this.order = this.thisN;
        return { value: this.thisTrial, done: false };
      },
    };
  }

  next() {
    const it = this[Symbol.iterator]();
    return it.next().value;
  }

  getSnapshot() {
    const currentIndex = this.thisIndex;
    const snapshot = {
      handler: this,
      name: this.name,
      nStim: this.nStim,
      nTotal: this.nTotal,
      nRemaining: this.nRemaining,
      thisRepN: this.thisRepN,
      thisTrialN: this.thisTrialN,
      thisN: this.thisN,
      thisIndex: this.thisIndex,
      ran: this.ran,
      finished: this._finished,
      getCurrentTrial: () => this.getTrial(currentIndex),
      getTrial: (index = 0) => this.getTrial(index),
      addData: (key, value) => this.addData(key, value),
    };
    const currentTrial = this.getCurrentTrial();
    const excludedAttributes = ['handler', 'name', 'nStim', 'nRemaining', 'thisRepN', 'thisTrialN', 'thisN', 'thisIndex', 'ran', 'finished'];
    const trialAttributes = [];
    for (const attribute in currentTrial) {
      if (!excludedAttributes.includes(attribute)) {
        snapshot[attribute] = currentTrial[attribute];
        trialAttributes.push(attribute);
      }
    }
    snapshot.trialAttributes = trialAttributes;
    this._snapshots.push(snapshot);
    return snapshot;
  }

  static fromSnapshot(snapshot) {
    if (typeof snapshot === 'undefined') return;
    snapshot.handler.nStim = snapshot.nStim;
    snapshot.handler.nTotal = snapshot.nTotal;
    snapshot.handler.nRemaining = snapshot.nRemaining;
    snapshot.handler.thisRepN = snapshot.thisRepN;
    snapshot.handler.thisTrialN = snapshot.thisTrialN;
    snapshot.handler.thisN = snapshot.thisN;
    snapshot.handler.thisIndex = snapshot.thisIndex;
    snapshot.handler.ran = snapshot.ran;
    snapshot.handler._finished = snapshot._finished;
    snapshot.handler.thisTrial = snapshot.handler.getCurrentTrial();
    let name = snapshot.name;
    if (name[name.length - 1] === 's') name = name.substr(0, name.length - 1);
    name = `this${name[0].toUpperCase()}${name.substr(1)}`;
    const value = {};
    for (const attribute of snapshot.trialAttributes) value[attribute] = snapshot[attribute];
    window[name] = value;
  }

  getTrialIndex() { return this.thisIndex; }
  setTrialIndex(index) { this.thisIndex = index; }

  getAttributes() {
    if (!Array.isArray(this.trialList) || this.nStim === 0) return [];
    if (!this.trialList[0]) return [];
    return Object.keys(this.trialList[0]);
  }

  getCurrentTrial() { return this.trialList[this.thisIndex]; }

  getTrial(index = 0) {
    if (index < 0 || index > this.nTotal) return undefined;
    return this.trialList[index];
  }

  addData(key, value) {
    if (this._experimentHandler) this._experimentHandler.addData(key, value);
  }

  _prepareSequence() {
    const indices = Array.from(this.trialList.keys());
    if (this._method === TrialHandler.Method.SEQUENTIAL) {
      this._trialSequence = Array(this.nReps).fill(indices);
    } else if (this._method === TrialHandler.Method.RANDOM) {
      this._trialSequence = [];
      for (let i = 0; i < this.nReps; ++i) this._trialSequence.push(util.shuffle(indices.slice()));
    } else if (this._method === TrialHandler.Method.FULL_RANDOM) {
      const flatSequence = [];
      for (let i = 0; i < this.nReps; ++i) flatSequence.push(...indices);
      util.shuffle(flatSequence);
      this._trialSequence = [];
      for (let i = 0; i < this.nReps; i++) this._trialSequence.push(flatSequence.slice(i * this.nStim, (i + 1) * this.nStim));
    } else {
      throw new Error('unknown method');
    }
    return this._trialSequence;
  }
}
TrialHandler.Method = {
  SEQUENTIAL: Symbol.for('SEQUENTIAL'),
  RANDOM: Symbol.for('RANDOM'),
  FULL_RANDOM: Symbol.for('FULL_RANDOM'),
  FULLRANDOM: Symbol.for('FULL_RANDOM'),
};

export class MultiStairHandler extends TrialHandler {}
export const data = { ExperimentHandler, TrialHandler, MultiStairHandler };

// ========================================================================= //
//  core.GUI
// ========================================================================= //
export class GUI {
  constructor(psychoJS) {
    this._psychoJS = psychoJS;
    this._dialogComponent = undefined;
    this._dialogLog = [];
  }

  get dialogComponent() { return this._dialogComponent; }

  /**
   * Atrapa okna dialogowego. Zachowanie jest dokladnie takie, jak w
   * `GUI.DlgFromDict`: pierwsza klatka pokazuje okno i zwraca FLIP_REPEAT,
   * a od nastepnej klatki "uzytkownik" klika OK (badanie nie modeluje
   * interakcji - zakladamy natychmiastowe klikniecie, czyli 1 klatka).
   */
  DlgFromDict({ dictionary, title, requireParticipantClick = true } = {}) {
    this._progressBarMax = 0;
    this._allResourcesDownloaded = false;
    this._requiredKeys = [];
    this._requireParticipantClick = requireParticipantClick;
    this._dictionary = dictionary;
    this._dialogComponent = {};
    this._dialogComponent.status = PsychoJS.Status.NOT_STARTED;
    this._dialogComponent.button = 'Cancel';
    let rendered = 0;
    return () => {
      if (this._dialogComponent.status === PsychoJS.Status.NOT_STARTED) {
        this._dialogComponent.status = PsychoJS.Status.STARTED;
        rendered += 1;
        return Scheduler.Event.FLIP_REPEAT;
      }
      // "uzytkownik" klika OK po 1 klatce
      this._dialogComponent.button = 'OK';
      this._dialogLog.push({ title, rendered });
      this._dialogComponent.status = PsychoJS.Status.FINISHED;
      return Scheduler.Event.NEXT;
    };
  }

  dialog({ message, warning, error, onOK, onCancel, showOK = true, showCancel = false } = {}) {
    this._dialogLog.push({ message: message ?? null, error: error ? String(error.message ?? error) : null, auto: 'OK' });
    if (onOK) onOK();
    return Promise.resolve();
  }

  finishDialog() {}
  finishDialogNextStep() {}
  closeDialog() {}
}

// ========================================================================= //
//  core.Logger
// ========================================================================= //
function makeLogger() {
  const noop = () => {};
  return { trace: noop, debug: noop, info: noop, warn: noop, error: noop, fatal: noop, data: noop, exp: noop, log: noop, setLevel: noop, flush: () => Promise.resolve() };
}
export const Logger = { ServerLevel: { INFO: 'INFO', ERROR: 'ERROR', EXP: 'EXP' } };

// ========================================================================= //
//  core.PsychoJS
// ========================================================================= //
export class PsychoJS {
  constructor({ debug = true, collectIP = false, hosts = [], topLevelStatus = true, autoStartScheduler = true, saveResults = true, captureErrors = true, checkWebGLSupport = false } = {}) {
    this._logger = { consoleLogger: makeLogger(), setLevel: noopSetLevel, flush: () => Promise.resolve() };
    this._debug = debug;
    this._browser = { name: 'node', version: '0' };
    this._monotonicClock = new MonotonicClock();
    this._eventManager = new EventManager(this);
    this._gui = new GUI(this);
    this._collectIP = collectIP;
    this._scheduler = new Scheduler(this);
    this._window = undefined;
    this._serverMsg = new Map();
    this._status = PsychoJS.Status.NOT_CONFIGURED;
    this._autoStartScheduler = autoStartScheduler;
    this._saveResults = saveResults;
    this._experiment = undefined;
    if (topLevelStatus) this._makeStatusTopLevel();
  }

  get status() { return this._status; }
  set status(s) { this._status = s; }
  get config() { return this._config; }
  get window() { return this._window; }
  get scheduler() { return this._scheduler; }
  get experiment() { return this._experiment; }
  get logger() { return this._logger.consoleLogger; }
  get experimentLogger() { return this._logger; }
  get eventManager() { return this._eventManager; }
  get gui() { return this._gui; }
  get serverMsg() { return this._serverMsg; }

  openWindow(options = {}) {
    this._window = new Window({ psychoJS: this, ...options });
  }

  schedule(task, args) { this._scheduler.add(task, args); }

  scheduleCondition(condition, thenScheduler, elseScheduler) {
    this._scheduler.addConditional(condition, thenScheduler, elseScheduler);
  }

  importAttributes(obj) {
    if (typeof obj === 'undefined') return;
    for (const attribute in obj) window[attribute] = obj[attribute];
  }

  async start({ configURL = 'config.json', expName = 'UNKNOWN', expInfo = {}, resources = [], dataFileName, surveyId } = {}) {
    this._config = {
      environment: ExperimentHandler.Environment.LOCAL,
      experiment: { name: expName, saveFormat: ExperimentHandler.SaveFormat.CSV, saveIncompleteResults: true, keys: [] },
    };
    this._config.experiment.resultsUpload = { period: -1, intervalId: -1 };
    this._serverMsg = new Map();
    getUrlParameters().forEach((value, key) => { if (key.indexOf('__') === 0) this._serverMsg.set(key, value); });
    this.status = PsychoJS.Status.CONFIGURED;

    this._experiment = new ExperimentHandler({ psychoJS: this, extraInfo: expInfo, dataFileName });
    if (this._autoStartScheduler) {
      this.status = PsychoJS.Status.STARTED;
      this._scheduler.start();
    }
  }

  async quit({ message, isCompleted = false, closeWindow = true, showOK = true, closeBrowserTab = false } = {}) {
    this._experiment.experimentEnded = true;
    this._experiment.isCompleted = isCompleted;
    this.status = PsychoJS.Status.STOPPED;
    this._scheduler.stop();
    const onTerminate = () => {
      if (closeWindow) this._window.close();
      this.status = PsychoJS.Status.FINISHED;
      this._window.closeFullScreen();
    };
    if (isCompleted || this._config.experiment.saveIncompleteResults) {
      await this._experiment.save();
    }
    if (showOK) this._gui.dialog({ message, onOK: onTerminate });
    else { this._gui.closeDialog(); onTerminate(); }
  }

  _makeStatusTopLevel() {
    for (const status in PsychoJS.Status) window[status] = PsychoJS.Status[status];
  }
}
function noopSetLevel() {}

PsychoJS.Status = {
  NOT_CONFIGURED: Symbol.for('NOT_CONFIGURED'),
  CONFIGURING: Symbol.for('CONFIGURING'),
  CONFIGURED: Symbol.for('CONFIGURED'),
  NOT_STARTED: Symbol.for('NOT_STARTED'),
  STARTED: Symbol.for('STARTED'),
  PAUSED: Symbol.for('PAUSED'),
  FINISHED: Symbol.for('FINISHED'),
  STOPPED: Symbol.for('FINISHED'),
  ERROR: Symbol.for('ERROR'),
};

export const core = { PsychoJS, Window, Keyboard, Mouse, EventManager, Logger, KeyPress };
export const sound = {};
export const hardware = {};
