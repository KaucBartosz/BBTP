// -*- coding: utf-8 -*-
/**
 * Minimalna atrapa DOM przegladarki dla testow parzystości.
 *
 * `stop.js` (oraz atrapa PsychoJS) korzystaja z:
 *   - `window` (globalny obiekt) z `addEventListener` / `removeEventListener`,
 *     `location`, `innerWidth/innerHeight`, `devicePixelRatio`, `navigator`,
 *   - `document` z `getElementById('root')`, `createElement`, `querySelector`,
 *     `body`, `documentElement`, `fullscreenElement`,
 *   - `performance.now()` (sprzezone z zegarem wirtualnym symulatora),
 *   - `requestAnimationFrame` (kolejka klatek),
 *   - `canvas` jako EventTarget (pointerdown/up/move, touchstart/end).
 *
 * Nic nie jest renderowane - canvas to obiekt-lustro, do ktorego symulator
 * dostarcza zdarzenia wejsciowe.
 */

export class FakeEventTarget {
  constructor(name = 'target') {
    this.nodeName = name;
    this._listeners = new Map();
  }

  addEventListener(type, fn) {
    if (!this._listeners.has(type)) this._listeners.set(type, []);
    this._listeners.get(type).push(fn);
  }

  removeEventListener(type, fn) {
    const list = this._listeners.get(type);
    if (!list) return;
    const i = list.indexOf(fn);
    if (i >= 0) list.splice(i, 1);
  }

  dispatchEvent(ev) {
    const list = this._listeners.get(ev.type);
    if (!list) return true;
    for (const fn of [...list]) fn(ev);
    return !ev.defaultPrevented;
  }
}

function makeEvent(type, props = {}) {
  return {
    type,
    target: null,
    currentTarget: null,
    defaultPrevented: false,
    preventDefault() { this.defaultPrevented = true; },
    stopPropagation() {},
    repeat: false,
    key: undefined,
    code: undefined,
    keyCode: 0,
    ...props,
  };
}

class FakeElement extends FakeEventTarget {
  constructor(name) {
    super(name);
    this.style = {};
    this.classList = { add() {}, remove() {}, contains: () => false };
    this.children = [];
    this._innerHTML = '';
  }

  get innerHTML() { return this._innerHTML; }
  set innerHTML(v) { this._innerHTML = v; this.children = []; }

  appendChild(child) {
    child.parentNode = this;
    this.children.push(child);
    return child;
  }

  removeChild(child) {
    const i = this.children.indexOf(child);
    if (i >= 0) this.children.splice(i, 1);
    return child;
  }

  contains(child) { return this.children.includes(child); }
  hasChildNodes() { return this.children.length > 0; }
  get lastChild() { return this.children[this.children.length - 1]; }
  getContext2d() { return {}; }
  getBoundingClientRect() {
    return { left: 0, top: 0, right: globalThis.innerWidth, bottom: globalThis.innerHeight, width: globalThis.innerWidth, height: globalThis.innerHeight };
  }
}

class FakeCanvas extends FakeElement {
  constructor() {
    super('canvas');
    this.width = globalThis.innerWidth;
    this.height = globalThis.innerHeight;
  }
}

/**
 * Buduje globalne srodowisko przegladarki.
 * @param {object} opts
 * @param {number} opts.width  szerokosc okna [px]
 * @param {number} opts.height wysokosc okna [px]
 * @param {function(): number} opts.now  biezaca chwila symulacji [ms]
 * @param {string} opts.platform  window.navigator.platform
 * @param {string} opts.search  window.location.search (parametry URL)
 */
export function installDOM({ width = 1280, height = 720, now = () => 0, platform = 'Win32', search = '' } = {}) {
  const canvas = new FakeCanvas();

  const root = new FakeElement('div');
  root.classList.add = () => {};

  const body = new FakeElement('body');
  const documentElement = new FakeElement('html');
  documentElement.requestFullscreen = () => Promise.resolve();

  const elements = new Map([['root', root]]);

  const document = new FakeEventTarget('document');
  document.body = body;
  document.documentElement = documentElement;
  document.fullscreenElement = null;
  document.getElementById = (id) => (id === 'root' ? root : elements.get(id) ?? null);
  document.createElement = (tag) => (String(tag).toLowerCase() === 'canvas' ? new FakeCanvas() : new FakeElement(tag));
  document.querySelector = (sel) => (String(sel).toLowerCase() === 'canvas' ? canvas : null);
  document.querySelectorAll = () => [];
  document.exitFullscreen = () => Promise.resolve();

  const win = new FakeEventTarget('window');
  win.innerWidth = width;
  win.innerHeight = height;
  win.devicePixelRatio = 1;
  win.screen = { width, height };
  win.visualViewport = { width, height };
  win.navigator = { platform, userAgent: 'node-harness' };
  win.location = { search, href: `http://localhost/index.html${search}` };
  win.addEventListener = win.addEventListener.bind(win);
  win.close = () => { win.closed = true; };
  win.onerror = null;
  win.onunhandledrejection = null;

  // --- requestAnimationFrame: kolejka klatek --------------------------------
  const rafQueue = [];
  let rafId = 0;
  win.requestAnimationFrame = (cb) => { rafQueue.push({ id: ++rafId, cb }); return rafId; };
  win.cancelAnimationFrame = (id) => {
    const i = rafQueue.findIndex((e) => e.id === id);
    if (i >= 0) rafQueue.splice(i, 1);
  };
  globalThis.requestAnimationFrame = win.requestAnimationFrame;
  globalThis.cancelAnimationFrame = win.cancelAnimationFrame;

  // --- globalne obiekty -----------------------------------------------------
  const def = (name, value) => Object.defineProperty(globalThis, name, { value, writable: true, configurable: true });

  def('window', win);
  def('document', document);
  def('navigator', win.navigator);
  def('innerWidth', width);
  def('innerHeight', height);
  def('devicePixelRatio', 1);
  def('location', win.location);
  def('performance', { now });
  def('requestAnimationFrame', win.requestAnimationFrame);
  def('cancelAnimationFrame', win.cancelAnimationFrame);

  return {
    window: win,
    document,
    body,
    root,
    canvas,
    rafQueue,
    now,
  };
}
