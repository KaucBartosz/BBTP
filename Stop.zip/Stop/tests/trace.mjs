#!/usr/bin/env node
// -*- coding: utf-8 -*-
/**
 * Narzedzie diagnostyczne: wypisuje klatki z trace dla podanego scenariusza
 * i wybranej proby, w obu wersjach naraz (do porownania klatka po klatce).
 *
 *   node tests/trace.mjs <scenariusz> <próba> [maxKlatek]
 *   node tests/trace.mjs iso_edge_click 0 12
 *
 * Wymaga wcześniejszego `node tests/run_all.mjs <scenariusz>`.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const OUT = path.resolve(HERE, '..', 'out');

const [name = 'smoke', trialArg = '0', maxArg = '40'] = process.argv.slice(2);
const trial = Number(trialArg);
const max = Number(maxArg);

function load(side) {
  const dir = path.join(OUT, name);
  const trace = JSON.parse(fs.readFileSync(path.join(dir, `trace_${side}.json`), 'utf8'));
  const meta = JSON.parse(fs.readFileSync(path.join(dir, `meta_${side}.json`), 'utf8'));
  return { trace, meta };
}

for (const side of ['py', 'js']) {
  const { trace, meta } = load(side);
  const rows = trace.filter((r) => r.tr === trial);
  const onset = (meta.stop_onsets ?? []).find((o) => o[0] === trial);
  process.stdout.write(`\n### ${side}  frames=${meta.frames} trials=${meta.trials_seen} ` +
    `trial_start=${(meta.trial_starts.find((s) => s[0] === trial) ?? [])[1]} ` +
    `stop_onset=${onset ? onset[1] : '-'}  (klatki w probie: ${rows.length})\n`);
  if (onset) {
    const rel = rows.filter((r) => r.t >= onset[1] - 0.02);
    for (const r of rel.slice(0, max)) {
      const s = Object.entries(r)
        .filter(([k]) => !['f', 't', 'tr'].includes(k))
        .map(([k, v]) => `${k}=[${v.map((x) => (typeof x === 'number' ? x.toFixed(4) : x)).join(',')}]`)
        .join(' ');
      process.stdout.write(`  f=${String(r.f).padStart(6)} t=${r.t.toFixed(4)}  ${s}\n`);
    }
  }
  const log = (meta.input_log ?? []).filter((e) => e.t >= (onset ? onset[1] - 1 : 0));
  process.stdout.write(`  input: ${JSON.stringify(log).slice(0, 600)}\n`);
}
