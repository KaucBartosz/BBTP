// -*- coding: utf-8 -*-
/**
 * Porownuje wyniki obu wersji testu (`main.py` / `stop.js`) i buduje raport.
 *
 *     node --no-warnings tests/compare.mjs              # wszystkie scenariusze
 *     node --no-warnings tests/compare.mjs mixed touch  # wybrane
 *
 * Wyniki: out/<scenariusz>/report.md + report.json oraz out/REPORT.md
 *
 * Raport sklada sie z trzech czesci:
 *   1. porownanie scenariusz po scenariuszu (paczka wynikowa, `wyniki`,
 *      os czasu, trace bodzcow, strumien RNG),
 *   2. automatycznie wykryte ROZNICE LOGIKI w kodzie zrodlowym wraz
 *      z dowodami liczonymi z trace klatek,
 *   3. roznice, ktore wynikaja wylacznie z formatu paczki wynikowej.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { SCENARIOS } from './scenarios.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const OUT = path.resolve(HERE, '..', 'out');

// tolerancje
const EPS_NUM = 1e-9;        // porownanie liczb w JSON-ach (1 ns dla czasu w sekundach)
const EPS_POS = 1e-6;        // pozycja bodzca (jednostki okna)

/** Klucze, ktorych wartosc z definicji rozni sie miedzy uruchomieniami. */
const VOLATILE = new Set(['timestamp', 'subjectId', 'date', 'psychopyVersion', 'OS', 'frameRate', 'session']);

/** Bodzce przeszkodowe - jedyne, ktore sa przesuwane w petli. */
const DISTRACTORS = ['jelonek', 'drzewo'];
/** Polozenie startowe dystraktorow - `main.py:107-108`, `stop.js` (driveRoutineBegin). */
const DISTRACTOR_START_Y = -0.1;
/** Granica "zawiniecia" - `main.py:148`/`154` oraz `stop.js:709`/`715`. */
const WRAP_Y = -0.6;
/**
 * Prog skoku, ktory rozpoznaje zawiniecie w trace. Zawiniecie przestawia `y`
 * z okolic `-0.6` na `-0.1`, czyli skok ok. `0.5` jedn. okna; prog `0.1` jest
 * dostatecznie czuly i nie lapie zwyklego ruchu (maks. ok. `0.05` na klatke).
 */
const WRAP_JUMP = 0.1;
/** Zabronione pola tablicy `wyniki` (raportowane osobno, w formie wierszy). */
const RESULTS_KEY = 'wyniki';
const TRIAL_KEYS = ['stopOnset', 'responded', 'correct', 'isFalstart', 'rt'];

/** Krawedzie prostokata w kolejnosci marginesow obu symulatorow. */
const EDGE_NAMES = ['lewa', 'prawa', 'dolna', 'górna'];
/** Prog, ponizej ktorego decyzja `isPressedIn` jest "na krawedzi" (1e-6 jedn. okna = 7.2e-4 px). */
const EDGE_EPS = 1e-6;

/** PsychoPy: `abs(x-sx) <= w and abs(y-sy) <= h` - wszystkie cztery krawedzie `<=`. */
const hitPsychopy = (m) => m.every((v) => v >= 0);
/** PsychoJS: `PIXI.Rectangle.contains` - dol `>=`, gora/prawa `<`. */
const hitPixi = (m) => m[0] >= 0 && m[1] > 0 && m[2] >= 0 && m[3] > 0;

// ------------------------------------------------------------------------ //
//  formatowanie
// ------------------------------------------------------------------------ //
const readJson = (f) => (fs.existsSync(f) ? JSON.parse(fs.readFileSync(f, 'utf8')) : null);

/** Pelna, dokladna reprezentacja wartosci (dowod). */
function rd(v) {
  if (v === null || v === undefined) return '—';
  if (typeof v === 'boolean') return v ? 'true' : 'false';
  if (typeof v === 'number') return Number.isFinite(v) ? String(v) : String(v);
  if (typeof v === 'string') return v.length > 120 ? `«${v.slice(0, 117)}…»` : v;
  if (Array.isArray(v)) {
    if (v.length === 0) return '[]';
    if (v.every((x) => x === null || typeof x !== 'object')) {
      const head = v.slice(0, 6).map(rd).join(', ');
      return `[${head}${v.length > 6 ? `, … (${v.length})` : ''}]`;
    }
    return `${v.length}×{${Object.keys(v[0] ?? {}).join(', ')}}`;
  }
  if (typeof v === 'object') {
    const ks = Object.keys(v);
    return `{${ks.slice(0, 10).join(', ')}${ks.length > 10 ? ', …' : ''}}`;
  }
  return String(v);
}

/** Krotka reprezentacja do tabel podsumowan. */
function rs(v) {
  if (v === null || v === undefined) return '—';
  if (typeof v === 'number') return num(v);
  if (typeof v === 'string') return v.length > 40 ? `«${v.slice(0, 37)}…»` : v;
  if (Array.isArray(v)) return v.length === 0 ? '[]' : `${v.length} elem.`;
  if (typeof v === 'object') return `{${Object.keys(v).length} pól}`;
  return String(v);
}

/** Liczba z adaptywna precyzja. */
function num(v, sig = 9) {
  if (v === null || v === undefined || !Number.isFinite(v)) return '—';
  if (v === 0) return '0';
  const a = Math.abs(v);
  if (Number.isInteger(v) && a < 1e15) return String(v);
  if (a >= 1e-4 && a < 1e9) return String(Number(v.toPrecision(sig)));
  return Number(v.toExponential(4)).toExponential(4);
}

/** Roznica z jawnym zaznaczeniem szumu numerycznego. */
function delta(x, unit = '', eps = 1e-12) {
  if (x === null || x === undefined || !Number.isFinite(x)) return '—';
  const a = Math.abs(x);
  if (a === 0) return `0${unit}`;
  const s = unit === ' ms' || unit === ' s' ? x.toFixed(6) : num(x, 4);
  return `${a < 1e-9 ? '≈0' : s}${unit}`;
}

const bool = (v) => (v === 1 || v === true ? 'tak' : v === 0 || v === false ? 'nie' : '—');
const numEq = (a, b, eps = EPS_NUM) =>
  (typeof a === 'number' && typeof b === 'number' ? Math.abs(a - b) <= eps : a === b);

function table(headers, rows) {
  if (!rows.length) return '_brak danych_';
  const out = [`| ${headers.join(' | ')} |`, `| ${headers.map(() => '---').join(' | ')} |`];
  for (const r of rows) out.push(`| ${r.map((c) => String(c ?? '—')).join(' | ')} |`);
  return out.join('\n');
}

function flatLeaf(v, prefix, out) {
  if (v && typeof v === 'object' && !Array.isArray(v)) {
    for (const k of Object.keys(v)) flatLeaf(v[k], prefix ? `${prefix}.${k}` : k, out);
  } else {
    out[prefix] = v;
  }
  return out;
}

// ------------------------------------------------------------------------ //
//  trace: porownanie pozycji bodzcow klatka po klatce
// ------------------------------------------------------------------------ //
function rowsByTrial(trace) {
  const m = new Map();
  for (const r of trace) {
    if (r.tr < 0) continue;
    if (!m.has(r.tr)) m.set(r.tr, []);
    m.get(r.tr).push(r);
  }
  return m;
}

/**
 * Indeksy (w ramach proby) klatek zawiniecia bodzca.
 *
 * Nie mozna szukac `y < WRAP_Y` w trace: `main.py` sprawdza warunek PO ruchu, wiec
 * pozycja ponizej progu nigdy nie trafia do trace - bodziec jest w tej samej klatce
 * przesuwany na nowe miejsce. Zawiniecie rozpoznajemy po skoku wspord:
 * `y[i] - y[i-1] > WRAP_JUMP` (pozycja skacze w gore, z dolnej polowy na -0.1).
 */
function wrapIndices(rows, stim) {
  const out = [];
  for (let i = 1; i < rows.length; i += 1) {
    const a = rows[i - 1][stim];
    const b = rows[i][stim];
    if (a && b && b[1] - a[1] > WRAP_JUMP) out.push(i);
  }
  return out;
}

/** Ostatnia pozycja `y` przed danym zawinieciem (dowod na to, gdzie byl prog). */
function preWrapY(rows, stim, idx) {
  const s = rows[Math.max(0, idx - 1)][stim];
  return s ? s[1] : null;
}

function compareTrace(tracePy, traceJs, metaPy, metaJs, opts = {}) {
  const byPy = rowsByTrial(tracePy);
  const byJs = rowsByTrial(traceJs);
  const startOf = (m) => Object.fromEntries((m.trial_starts ?? []).map((x) => [x[0], x[1]]));
  const sPy = startOf(metaPy);
  const sJs = startOf(metaJs);

  const res = {
    framesPy: tracePy.length,
    framesJs: traceJs.length,
    perTrial: [],
    maxPosDelta: 0,
    worstTrial: null,
    worstStim: null,
    // --- dowody na roznice w logice ruchu dystraktorow ---
    firstFrame: null,
    wrapOffset: {
      trialsWithWraps: 0, trialsWithBothWraps: 0,
      wrapsPy: 0, wrapsJs: 0,
      jsLater: 0, pyLater: 0, same: 0,
      examples: [],       // pierwszy rozjezd w wybranym scenariuszu
    },
    trialsFirstFrameStillAtStart: { py: 0, js: 0, considered: 0 },
    /** Zawiniecia na probe: dowod zwiazku "4 losowania na zawiniecie". */
    wrapPerTrial: [],
  };

  for (const [trial, rowsA] of byPy) {
    const rowsB = byJs.get(trial);
    if (!rowsB) continue;
    const t0a = sPy[trial] ?? 0;
    const t0b = sJs[trial] ?? 0;

    // --- klatka pierwsza proby: czy dystraktor w ogole sie ruszyl? ---
    const first = rowsA[0];
    const firstB = rowsB.find((r) => r.f === first.f) ?? rowsB[0];
    if (first && firstB) {
      res.trialsFirstFrameStillAtStart.considered += 1;
      for (const st of DISTRACTORS) {
        const a = first[st];
        const b = firstB[st];
        if (!a || !b) continue;
        if (Math.abs(a[1] - DISTRACTOR_START_Y) <= EPS_POS) res.trialsFirstFrameStillAtStart.py += 1;
        if (Math.abs(b[1] - DISTRACTOR_START_Y) <= EPS_POS) res.trialsFirstFrameStillAtStart.js += 1;
      }
      if (res.firstFrame === null) {
        res.firstFrame = {
          trial,
          pyFrame: first.f,
          jsFrame: firstB.f,
          py: Object.fromEntries(DISTRACTORS.map((s) => [s, first[s] ? first[s][1] : null])),
          js: Object.fromEntries(DISTRACTORS.map((s) => [s, firstB[s] ? firstB[s][1] : null])),
        };
      }
    }

    // --- klatka zawiniecia: o ile pozniej JS wykonuje "wrap"? ---
    // Po rozjechaniu strumienia RNG obie wersje losuja inne predkosci, wiec para
    // "to samo zawiniecie" przestaje byc porownywalna - liczymy wtedy tylko surowe liczniki.
    const pairable = trial < (opts.pairUpTo ?? Infinity);
    let perTrialPy = 0;
    let perTrialJs = 0;
    for (const st of DISTRACTORS) {
      const wA = wrapIndices(rowsA, st);
      const wB = wrapIndices(rowsB, st);
      perTrialPy += wA.length;
      perTrialJs += wB.length;
      if (!wA.length && !wB.length) continue;
      res.wrapOffset.trialsWithWraps += 1;
      res.wrapOffset.wrapsPy += wA.length;
      res.wrapOffset.wrapsJs += wB.length;
      if (!wA.length || !wB.length) continue;
      res.wrapOffset.trialsWithBothWraps += 1;
      if (pairable) {
        const n = Math.min(wA.length, wB.length);
        for (let k = 0; k < n; k += 1) {
          const d = wB[k] - wA[k];
          if (d > 0) res.wrapOffset.jsLater += 1;
          else if (d < 0) res.wrapOffset.pyLater += 1;
          else res.wrapOffset.same += 1;
        }
      }
      // Pierwszy przypadek z co najmniej dwoma zawinieciami na obu stronach
      // sluzy jako tabela dowodowa (narastanie roznicy klatka po klatce).
      if (pairable && !res.wrapOffset.examples.length && wA.length >= 2 && wB.length >= 2) {
        res.wrapOffset.examples.push({
          trial, stim: st,
          wrapsPy: wA.length, wrapsJs: wB.length,
          pyFrames: wA.slice(0, 10), jsFrames: wB.slice(0, 10),
          preWrapPy: preWrapY(rowsA, st, wA[0]),
          preWrapJs: preWrapY(rowsB, st, wB[0]),
          minPy: Math.min(...rowsA.map((r) => (r[st] ? r[st][1] : Infinity))),
          minJs: Math.min(...rowsB.map((r) => (r[st] ? r[st][1] : Infinity))),
        });
      }
    }
    res.wrapPerTrial.push({ trial, py: perTrialPy, js: perTrialJs });

    // --- najwieksza roznica pozycji w klatkach wyrownanych po czasie ---
    let worst = 0;
    let worstStim = null;
    const A = rowsA.map((r) => ({ dt: r.t - t0a, r }));
    const B = rowsB.map((r) => ({ dt: r.t - t0b, r }));
    for (const { dt, r: a } of A) {
      let best = null;
      for (const { dt: dtB, r: b } of B) {
        const d = Math.abs(dtB - dt);
        if (best === null || d < best.d) best = { d, b };
      }
      if (!best || best.d > 0.5 * (metaPy.frame_ms ?? 16.667) / 1000) continue;
      for (const st of ['car', 'stop', ...DISTRACTORS]) {
        if (!a[st] || !best.b[st]) continue;
        for (let k = 0; k < 3; k += 1) {
          const d = Math.abs(a[st][k] - best.b[st][k]);
          if (d > worst) { worst = d; worstStim = st; }
        }
      }
    }
    res.perTrial.push({ trial, framesPy: rowsA.length, framesJs: rowsB.length, worstPosDelta: worst, worstStim });
    if (worst > res.maxPosDelta) { res.maxPosDelta = worst; res.worstTrial = trial; res.worstStim = worstStim; }
  }

  res.frameDeltaTotal = traceJs.length - tracePy.length;
  res.trialFrameDelta = res.perTrial.map((t) => t.framesJs - t.framesPy);
  res.maxTrialFrameDelta = res.trialFrameDelta.length
    ? Math.max(...res.trialFrameDelta.map(Math.abs)) : 0;
  res.identicalTrials = res.perTrial.filter((t) => t.worstPosDelta <= EPS_POS).length;
  return res;
}

// ------------------------------------------------------------------------ //
//  porownanie jednego scenariusza
// ------------------------------------------------------------------------ //
function compareScenario(name) {
  const dir = path.join(OUT, name);
  const py = readJson(path.join(dir, 'result_py.json'));
  const js = readJson(path.join(dir, 'result_js.json'));
  const metaPy = readJson(path.join(dir, 'meta_py.json')) ?? {};
  const metaJs = readJson(path.join(dir, 'meta_js.json')) ?? {};
  const tracePy = readJson(path.join(dir, 'trace_py.json')) ?? [];
  const traceJs = readJson(path.join(dir, 'trace_js.json')) ?? [];

  const res = {
    name,
    okPy: py !== null,
    okJs: js !== null,
    errorPy: metaPy.error ?? null,
    errorJs: metaJs.error ?? null,
    reseedPerTrial: Boolean(metaPy.reseed_per_trial),
    frameMs: metaPy.frame_ms ?? null,
  };

  // --- 1) paczka wynikowa ------------------------------------------------- //
  res.payload = { keysOnlyPy: [], keysOnlyJs: [], keyValues: {}, equal: [], different: [], volatile: [] };
  if (py && js) {
    const kPy = Object.keys(py);
    const kJs = Object.keys(js);
    res.payload.keysOnlyPy = kPy.filter((k) => !kJs.includes(k));
    res.payload.keysOnlyJs = kJs.filter((k) => !kPy.includes(k));
    for (const k of res.payload.keysOnlyPy) res.payload.keyValues[k] = { py: py[k], js: undefined };
    for (const k of res.payload.keysOnlyJs) res.payload.keyValues[k] = { py: undefined, js: js[k] };
    const fPy = flatLeaf(py, '', {});
    const fJs = flatLeaf(js, '', {});
    const onlyIn = new Set([...res.payload.keysOnlyPy, ...res.payload.keysOnlyJs]);
    for (const key of [...new Set([...Object.keys(fPy), ...Object.keys(fJs)])].sort()) {
      if (key === RESULTS_KEY) continue;          // raportowane osobno
      if (onlyIn.has(key.split('.')[0])) continue; // raportowane w tabeli kluczy
      const a = fPy[key];
      const b = fJs[key];
      const leaf = key.split('.').pop();
      const row = { key, py: a, js: b };
      if (VOLATILE.has(leaf)) res.payload.volatile.push(row);
      else if (numEq(a, b)) res.payload.equal.push(row);
      else res.payload.different.push(row);
    }
  }
  if (py && js && typeof py.score === 'string' && typeof js.score === 'string') {
    const norm = (s) => s.replace(/\s*\|\s*Kliknięcia:\s*\d+/, '');
    res.scorePy = py.score;
    res.scoreJs = js.score;
    res.scoreNormalizedEqual = norm(py.score) === norm(js.score);
    res.scoreNormPy = norm(py.score);
    res.scoreNormJs = norm(js.score);
  }

  // --- 2) tablica `wyniki` proba po probie -------------------------------- //
  const tPy = (py && Array.isArray(py[RESULTS_KEY])) ? py[RESULTS_KEY] : [];
  const tJs = (js && Array.isArray(js[RESULTS_KEY])) ? js[RESULTS_KEY] : [];
  res.trials = {
    countPy: tPy.length,
    countJs: tJs.length,
    rows: [],
    sameCount: 0,
    diffIndices: [],
    firstDiff: null,
    extraKeysJs: [],
    rtDeltasMs: [],
    maxRtDeltaMs: 0,
  };
  const jsKeys = [...new Set(tJs.flatMap((t) => Object.keys(t ?? {})))];
  const pyKeys = [...new Set(tPy.flatMap((t) => Object.keys(t ?? {})))];
  res.trials.keysJs = jsKeys;
  res.trials.keysPy = pyKeys;
  res.trials.extraKeysJs = jsKeys.filter((k) => !pyKeys.includes(k));
  res.trials.missingKeysJs = pyKeys.filter((k) => !jsKeys.includes(k));

  for (let i = 0; i < Math.max(tPy.length, tJs.length); i += 1) {
    const a = tPy[i];
    const b = tJs[i];
    const row = { i, py: a ?? null, js: b ?? null, fields: {}, diff: false };
    if (!a || !b) {
      row.diff = true;
      row.fields = { _: { py: a ? 'jest' : 'brak', js: b ? 'jest' : 'brak' } };
    } else {
      for (const k of TRIAL_KEYS) {
        if (!numEq(a[k], b[k])) row.fields[k] = { py: a[k], js: b[k] };
      }
      if (typeof a.rt === 'number' && typeof b.rt === 'number') {
        const d = (a.rt - b.rt) * 1000;
        row.rtDeltaMs = d;
        res.trials.rtDeltasMs.push({ trial: i, delta: d });
      }
      row.diff = Object.keys(row.fields).length > 0;
    }
    res.trials.rows.push(row);
    if (row.diff) { res.trials.diffIndices.push(i); res.trials.firstDiff = res.trials.firstDiff ?? i; }
    else res.trials.sameCount += 1;
  }
  res.trials.maxRtDeltaMs = res.trials.rtDeltasMs.length
    ? Math.max(...res.trials.rtDeltasMs.map((x) => Math.abs(x.delta))) : 0;
  res.trials.agreeingRts = res.trials.rtDeltasMs.length -
    res.trials.rtDeltasMs.filter((x) => Math.abs(x.delta) > 1e-6).length;

  // --- 3) os czasu -------------------------------------------------------- //
  const pairs = (arr) => Object.fromEntries((arr ?? []).map((x) => [x[0], x[1]]));
  const sPy = pairs(metaPy.trial_starts);
  const sJs = pairs(metaJs.trial_starts);
  const oPy = pairs(metaPy.stop_onsets);
  const oJs = pairs(metaJs.stop_onsets);
  const duration = (starts, i) => {
    const a = starts[i];
    const b = starts[i + 1];
    return a !== undefined && b !== undefined ? b - a : null;
  };
  res.timeline = {
    framesPy: metaPy.frames ?? null,
    framesJs: metaJs.frames ?? null,
    virtualMsPy: metaPy.virtual_ms ?? null,
    virtualMsJs: metaJs.virtual_ms ?? null,
    trialsPy: (metaPy.trial_starts ?? []).length,
    trialsJs: (metaJs.trial_starts ?? []).length,
    onsetsPy: (metaPy.stop_onsets ?? []).length,
    onsetsJs: (metaJs.stop_onsets ?? []).length,
    onsetRelDiff: [],
    durationMs: [],
    maxStartDeltaMs: 0,
    maxRelOnsetDeltaMs: 0,
    maxDurationDeltaMs: 0,
    maxDurationDeltaFrames: 0,
  };
  const shared = Object.keys(oPy).map(Number).filter((i) => oJs[i] !== undefined && sPy[i] !== undefined && sJs[i] !== undefined);
  for (const i of shared) {
    const relPy = oPy[i] - sPy[i];
    const relJs = oJs[i] - sJs[i];
    res.timeline.onsetRelDiff.push({ trial: i, relPy, relJs, delta: (relPy - relJs) * 1000 });
    res.timeline.maxRelOnsetDeltaMs = Math.max(res.timeline.maxRelOnsetDeltaMs, Math.abs(relPy - relJs) * 1000);
    res.timeline.maxStartDeltaMs = Math.max(res.timeline.maxStartDeltaMs, Math.abs(sPy[i] - sJs[i]) * 1000);
  }
  for (const i of Object.keys(sPy).map(Number)) {
    if (sJs[i] === undefined) continue;
    const dPy = duration(sPy, i);
    const dJs = duration(sJs, i);
    if (dPy === null || dJs === null) continue;
    res.timeline.durationMs.push({ trial: i, py: dPy * 1000, js: dJs * 1000, delta: (dPy - dJs) * 1000 });
    res.timeline.maxDurationDeltaMs = Math.max(res.timeline.maxDurationDeltaMs, Math.abs(dPy - dJs) * 1000);
  }
  res.timeline.identicalRelOnsets = res.timeline.onsetRelDiff.filter((o) => Math.abs(o.delta) <= 1e-5).length;
  res.timeline.identicalDurations = res.timeline.durationMs.filter((o) => Math.abs(o.delta) <= 1e-5).length;

  // --- 4) wejscie (dowod, ze skrypt podano w obu wersjach tak samo) ------- //
  // Roznica `t` miedzy wersjami jest NASTEPISTWA innych roznic (przesuwa sie
  // caly start proby), dlatego raportujemy ja osobno; tozsamosc akcji (rodzaj
  // + wspolrzedne) jest tym, co faktycznie musi byc zgodne.
  res.input = { py: metaPy.input_log ?? [], js: metaJs.input_log ?? [], rows: [], same: false, maxTimeDeltaMs: 0 };
  const idOf = (e) => `${e.ev}|${e.name ?? ''}|${(e.pos ?? []).map((v) => num(v, 12)).join(',')}`;
  const n = Math.max(res.input.py.length, res.input.js.length);
  res.input.same = res.input.py.length === res.input.js.length;
  for (let i = 0; i < n; i += 1) {
    const a = res.input.py[i];
    const b = res.input.js[i];
    const sameRow = !!a && !!b && idOf(a) === idOf(b);
    const dMs = a && b ? (a.t - b.t) * 1000 : null;
    if (!sameRow) res.input.same = false;
    if (dMs !== null) res.input.maxTimeDeltaMs = Math.max(res.input.maxTimeDeltaMs, Math.abs(dMs));
    res.input.rows.push({ i, py: a ?? null, js: b ?? null, same: sameRow, dMs });
  }
  res.input.countPy = res.input.py.length;
  res.input.countJs = res.input.js.length;
  res.mouseClicks = { py: metaPy.mouse_clicks ?? null, js: metaJs.mouse_clicks ?? null };

  // --- 5) strumien RNG ---------------------------------------------------- //
  res.rng = {
    totalPy: metaPy.rng_draws_total ?? null,
    totalJs: metaJs.rng_draws_total ?? null,
    stateFinalPy: metaPy.rng_state_final ?? null,
    stateFinalJs: metaJs.rng_state_final ?? null,
    windowPy: metaPy.rng_window_sizes ?? [],
    windowJs: metaJs.rng_window_sizes ?? [],
    setupDrawsSeenPy: [...new Set(metaPy.rng_window_sizes ?? [])],
    setupDrawsSeenJs: [...new Set(metaJs.rng_window_sizes ?? [])],
    perTrialPy: [],
    firstDiffTrial: null,
  };
  const at = (m) => metaPy[m] ?? [];
  const cPy = at('rng_draws_at_clear');
  const cJs = metaJs.rng_draws_at_clear ?? [];
  for (let i = 0; i < Math.max(cPy.length, cJs.length); i += 1) {
    const a = i === 0 ? cPy[0] : (cPy[i] ?? 0) - (cPy[i - 1] ?? 0);
    const b = i === 0 ? cJs[0] : (cJs[i] ?? 0) - (cJs[i - 1] ?? 0);
    res.rng.perTrialPy.push({ trial: i, py: cPy[i] ?? null, js: cJs[i] ?? null, pyDraws: a, jsDraws: b });
    if (a !== b && res.rng.firstDiffTrial === null) res.rng.firstDiffTrial = i;
  }
  // zgodność samych wartości konfiguracji proby (RNG-izolowane scenariusze)
  res.rng.onsetRelIdentical = res.timeline.identicalRelOnsets;
  res.rng.onsetRelTotal = res.timeline.onsetRelDiff.length;

  // --- 6) krawedzie bodzca (`Mouse.isPressedIn`) -------------------------- //
  res.edge = edgeAnalysis(name, metaPy, metaJs);

  // --- 7) trace ----------------------------------------------------------- //
  res.trace = compareTrace(tracePy, traceJs, metaPy, metaJs, {
    // Po rozjechaniu strumienia RNG obie wersje losuja inne predkosci, wiec "ta sama"
    // proba przestaje byc ta sama proba. Zawiniecia parujemy tylko wczesniej.
    pairUpTo: res.rng.firstDiffTrial === null ? Infinity : res.rng.firstDiffTrial,
  });

  return res;
}

/**
 * Porownanie decyzji `isPressedIn` dla klikow lezacych na krawedzi bodzca.
 *
 * Symulatory loguja (tylko gdy margines do krawedzi jest malejacy niz
 * `EDGE_EPS`) cztery odleglosci kursora od krawedzi prostokata, w jednostkach
 * okna, w ukladzie (0,0) w srodku okna / y w gore, w kolejnosci
 * [lewa, prawa, dolna, gora] - dokladnie te wartosci, ktore porownuje
 * `isPressedIn` w danej wersji.  Dzieki temu mozna rozdzielic dwa zrodla
 * rozbieznosci: sama SEMANTYKA krawedzi (`<=` vs przedzial polotwarty)
 * oraz szum zmiennoprzecinkowy rzędu 1 ulp.
 */
function edgeAnalysis(name, metaPy, metaJs) {
  const sc = readJson(path.join(HERE, 'scenarios', `${name}.json`)) ?? {};
  const stopName = String(sc.stop_stim ?? 'stop');
  const out = {
    stopStim: stopName,
    scenarios: [],
    pyOnly: 0,
    jsOnly: 0,
    observedDiff: [],
    semanticOnly: [],
    floatNoise: [],
    maxMarginGap: 0,
    minMarginAbs: null,
  };
  if (!Array.isArray(metaPy.edge_log) || !Array.isArray(metaJs.edge_log)) return out;

  const firstBy = (arr) => {
    const m = new Map();
    for (const e of arr) if (e.stim === stopName && !m.has(e.tr)) m.set(e.tr, e);
    return m;
  };
  const mPy = firstBy(metaPy.edge_log);
  const mJs = firstBy(metaJs.edge_log);
  const trials = [...new Set([...mPy.keys(), ...mJs.keys()])].sort((a, b) => a - b);

  for (const t of trials) {
    const a = mPy.get(t) ?? null;
    const b = mJs.get(t) ?? null;
    if (!a) { out.pyOnly += 1; continue; }
    if (!b) { out.jsOnly += 1; continue; }
    const row = {
      trial: t,
      offset: (sc.actions ?? []).find((x) => x.trial === t && x.target === stopName)?.target_offset ?? null,
      pyMargins: a.margins,
      jsMargins: b.margins,
      pyHit: Boolean(a.result),
      jsHit: Boolean(b.result),
    };
    // ktora krawedz jest najblizsza (po obu wersjach)
    const m = [...row.pyMargins, ...row.jsMargins];
    const i = m.reduce((best, v, k) => (Math.abs(v) < Math.abs(m[best]) ? k : best), 0);
    row.edge = EDGE_NAMES[i % 4];
    row.margin = m[i];
    // jaki werdykt dalaby DRUGA semantyka na tych samych floatach
    row.pyHitOnJsFloats = hitPsychopy(row.jsMargins);
    row.jsHitOnPyFloats = hitPixi(row.pyMargins);
    // (a) sama semantyka: na identycznych floatach oba operatory daja inny werdykt
    row.semanticDiffers = hitPsychopy(row.jsMargins) !== hitPixi(row.jsMargins);
    // (b) sama arytmetyka float: te same operatory na marginesach policzonych
    //     przez druga wersje daja inny werdykt
    row.floatDiffers = (hitPsychopy(row.pyMargins) !== hitPsychopy(row.jsMargins))
      || (hitPixi(row.pyMargins) !== hitPixi(row.jsMargins));
    row.observedDiffers = row.pyHit !== row.jsHit;
    for (let k = 0; k < 4; k += 1) {
      out.maxMarginGap = Math.max(out.maxMarginGap, Math.abs(row.pyMargins[k] - row.jsMargins[k]));
      out.minMarginAbs = out.minMarginAbs === null
        ? Math.abs(row.margin) : Math.min(out.minMarginAbs, Math.abs(row.margin));
    }
    out.scenarios.push(row);
    if (row.observedDiffers) out.observedDiff.push(row);
    if (row.semanticDiffers) out.semanticOnly.push(row);
    if (row.floatDiffers) out.floatNoise.push(row);
  }
  return out;
}

// ------------------------------------------------------------------------ //
//  raport - czesc 1: szczegoly scenariusza
// ------------------------------------------------------------------------ //
function trialTable(res) {
  const rows = res.trials.rows.map((r) => {
    const a = r.py ?? {};
    const b = r.js ?? {};
    const mark = r.diff ? '**różni się**' : 'identyczna';
    return [
      r.i,
      num(a.stopOnset ?? null, 12), num(b.stopOnset ?? null, 12),
      bool(a.responded), bool(b.responded),
      bool(a.correct), bool(b.correct),
      bool(a.isFalstart), bool(b.isFalstart),
      a.rt === undefined || a.rt === null ? '—' : num(a.rt, 12),
      b.rt === undefined || b.rt === null ? '—' : num(b.rt, 12),
      r.rtDeltaMs === undefined ? '—' : delta(r.rtDeltaMs, ' ms'),
      mark,
    ];
  });
  return table(
    ['#', 'stopOnset PY', 'stopOnset JS', 'resp. PY', 'resp. JS', 'ok. PY', 'ok. JS',
      'falstart PY', 'falstart JS', 'rt [s] PY', 'rt [s] JS', 'Δrt', 'werdykt'],
    rows,
  );
}

function scenarioReport(res, desc) {
  const L = [];
  L.push(`## Scenariusz \`${res.name}\``);
  if (desc) L.push('', `*${desc}*`);
  L.push('', res.reseedPerTrial
    ? '> Tryb **`reseed_per_trial`** — każda próba dostaje generator losowy zrestartowany '
      + 'na jej własnym numerze, więc każdą próbę można porównywać niezależnie od pozostałych. '
      + 'Różnica w jednej próbie nie psuje następnych.'
    : '> Tryb **ciągły** — obie wersje korzystają z jednego strumienia RNG, więc pierwsza '
      + 'różnica w liczbie losowań rozjeżdża wszystkie kolejne próby.');
  L.push('');
  L.push(table(['metryka', 'Python (`main.py`)', 'JS (`stop.js`)'], [
    ['paczka wynikowa', res.okPy ? 'tak' : '**BRAK**', res.okJs ? 'tak' : '**BRAK**'],
    ['próby w `wyniki`', res.trials.countPy, res.trials.countJs],
    ['próby przejrzane (symulator)', res.timeline.trialsPy, res.timeline.trialsJs],
    ['klatki', res.trace.framesPy, res.trace.framesJs],
    ['czas wirtualny [ms]', num(res.timeline.virtualMsPy, 8), num(res.timeline.virtualMsJs, 8)],
    ['kliknięcia (licznik symulatora)', res.mouseClicks.py, res.mouseClicks.js],
    ['akcji w skrypcie (rodzaj + współrzędne)', `${res.input.countPy} · ${res.input.same ? '**zgodne**' : 'różne'}`, `${res.input.countJs} · ${res.input.same ? '**zgodne**' : 'różne'}`],
    ['Δ dostarczenia akcji (max) [ms]', '0', delta(res.input.maxTimeDeltaMs, ' ms')],
    ['losowań RNG łącznie', res.rng.totalPy, res.rng.totalJs],
  ]));
  L.push('');

  // --- paczka -------------------------------------------------------------
  L.push('### 1. Paczka wysłana do launchera');
  L.push('');
  if (!res.okPy || !res.okJs) {
    L.push(`> Jedna z wersji nie wyprodukowała paczki: Python=${res.okPy} JS=${res.okJs}.`);
    L.push('');
  } else {
    if (res.payload.keysOnlyPy.length || res.payload.keysOnlyJs.length) {
      const rows = [];
      for (const k of res.payload.keysOnlyPy) rows.push([`\`${k}\``, rd(res.payload.keyValues[k].py), '**brak**']);
      for (const k of res.payload.keysOnlyJs) rows.push([`\`${k}\``, '**brak**', rd(res.payload.keyValues[k].js)]);
      L.push(table(['klucz', 'Python', 'JS'], rows));
      L.push('');
    } else {
      L.push('Zbiór kluczy na poziomie paczki jest identyczny.');
      L.push('');
    }
    if (res.payload.different.length) {
      L.push('Wartości różniące się (poza kluczami zdefinowanymi jako losowe):');
      L.push('');
      L.push(table(['pole', 'Python', 'JS'],
        res.payload.different.map((d) => [`\`${d.key}\``, rs(d.py), rs(d.js)])));
      L.push('');
    }
    if (res.payload.volatile.length) {
      L.push(table(['pole (z definicji niezależne od logiki testu)', 'Python', 'JS'],
        res.payload.volatile.map((d) => [`\`${d.key}\``, rs(d.py), rs(d.js)])));
      L.push('');
    }
    if (res.scoreNormalizedEqual) {
      L.push('> Pole `score` różni się **wyłącznie** obecnością segmentu `| Kliknięcia: N`, '
        + 'który dokłada tylko `main.py` (`main.py:233`).');
      L.push('');
      L.push(table(['`score`', 'wartość'], [
        ['Python', `\`${res.scorePy}\``],
        ['JS', `\`${res.scoreJs}\``],
        ['po usunięciu `| Kliknięcia: N`', res.scoreNormalizedEqual ? '**identyczne**' : 'różne'],
      ]));
      L.push('');
    }
  }

  // --- proba po probie ----------------------------------------------------
  L.push('### 2. Tablica `wyniki` — próba po próbie');
  L.push('');
  L.push(`Zgodnych prób: **${res.trials.sameCount} / ${Math.max(res.trials.countPy, res.trials.countJs)}**`
    + (res.trials.firstDiff === null
      ? ' (wszystkie pola `stopOnset`/`responded`/`correct`/`isFalstart`/`rt` identyczne).'
      : `, pierwsza różnica w próbie **${res.trials.firstDiff}**.`));
  L.push('');
  L.push(trialTable(res));
  L.push('');
  L.push(`Czas reakcji: porównanych **${res.trials.rtDeltasMs.length}**, zgodnych do 1 ns: **${res.trials.agreeingRts}**, `
    + `maksymalna różnica: **${delta(res.trials.maxRtDeltaMs, ' ms')}**.`);
  L.push('');
  if (res.trials.extraKeysJs.length) {
    L.push(`> Wersja JS dokłada do **każdego** wiersza dodatkowe pola `
      + `(${res.trials.extraKeysJs.length}): ${res.trials.extraKeysJs.map((k) => `\`${k}\``).join(', ')}. `
      + 'To efekt `psychojs.experiment.addData(...)` w `driveRoutineEnd`/`updateInfo` '
      + '(`stop.js:564`, `stop.js:835-842`) — `main.py` nie ma odpowiednika.');
    L.push('');
    const stringy = ['mouse.x', 'mouse.y', 'mouse.leftButton', 'mouse.midButton', 'mouse.rightButton', 'mouse.time'];
    if (res.trials.extraKeysJs.filter((k) => stringy.includes(k)).length) {
      L.push('> Uwaga na pułapkę formatu: pola `mouse.*` to **napisy** `"[]"`, a nie tablice — '
        + '`ExperimentHandler.addData` w PsychoJS 2025.1.1 zamienia je na `JSON.stringify`.');
      L.push('');
    }
  }
  if (res.trials.missingKeysJs.length) {
    L.push(`> Tylko w Python: ${res.trials.missingKeysJs.map((k) => `\`${k}\``).join(', ')}.`);
    L.push('');
  }

  // --- oś czasu -----------------------------------------------------------
  L.push('### 3. Oś czasu');
  L.push('');
  L.push(table(['metryka', 'Python', 'JS'], [
    ['Δ startu próby (max) [ms]', '0', delta(res.timeline.maxStartDeltaMs, ' ms')],
    ['Δ pojawienia się STOP względem startu próby (max) [ms]', '0', delta(res.timeline.maxRelOnsetDeltaMs, ' ms')],
    ['zgodnych `stopOnset` wzgl. startu próby', '—', `${res.timeline.identicalRelOnsets} / ${res.timeline.onsetRelDiff.length}`],
    ['Δ długości próby (max) [ms]', '0', delta(res.timeline.maxDurationDeltaMs, ' ms')],
    ['Δ długości próby (max) [klatki]', '0', res.trace.maxTrialFrameDelta],
    [`zgodnych długości prób`, '—', `${res.timeline.identicalDurations} / ${res.timeline.durationMs.length}`],
  ]));
  L.push('');
  L.push(`Rozmieszczenie bodźców w klatkach wyrownanych po czasie: maks. różnica `
    + `**${num(res.trace.maxPosDelta, 4)}** jednostek okna`
    + (res.trace.worstStim ? ` (bodziec \`${res.trace.worstStim}\`, próba ${res.trace.worstTrial})` : '')
    + `; prób w pełni zgodnych pozycjami: **${res.trace.identicalTrials} / ${res.trace.perTrial.length}**.`);
  L.push('');
  {
    const w = res.trace.wrapOffset;
    L.push('**Zawinięcia dystraktorów** (`y` skacze w górę po przekroczeniu progu '
      + `${num(WRAP_Y, 2)}):`);
    L.push('');
    L.push(table(['metryka', 'Python', 'JS'], [
      ['prób z zawinięciem', w.trialsWithWraps, w.trialsWithWraps],
      ['zawinięć łącznie', w.wrapsPy, w.wrapsJs],
    ]));
    L.push('');
    L.push(`Zawinięcia pozycjonowane parami (tylko próby przed rozjazdem strumienia RNG): `
      + `JS o **${w.jsLater}** klatek później, Python o **${w.pyLater}** później, `
      + `zgodnie w **${w.same}**.`);
    L.push('');
    if (w.examples.length) {
      const e = w.examples[0];
      L.push(`Dowód klatka po klatce (próba ${e.trial}, \`${e.stim}\`): zawinięcia w klatkach `
        + `PY ${e.pyFrames.join(', ')}; JS ${e.jsFrames.join(', ')} → Δ `
        + `${e.pyFrames.map((f, k) => e.jsFrames[k] - f).join(', ')}. `
        + `\`y\` przed 1. zawinięciem: PY ${num(e.preWrapPy, 8)}, JS ${num(e.preWrapJs, 8)}.`);
      L.push('');
    }
  }

  // --- RNG ----------------------------------------------------------------
  L.push('### 4. Strumień liczb pseudolosowych');
  L.push('');
  L.push(table(['metryka', 'Python', 'JS'], [
    ['losowań łącznie', res.rng.totalPy, res.rng.totalJs],
    ['stan na końcu', res.rng.stateFinalPy, res.rng.stateFinalJs],
    ['rozmiary okna konfiguracji proby', res.rng.setupDrawsSeenPy.join(', ') || '—', res.rng.setupDrawsSeenJs.join(', ') || '—'],
  ]));
  L.push('');
  if (res.rng.firstDiffTrial !== null) {
    L.push(`Liczba losowań rozbiega się od **proby ${res.rng.firstDiffTrial}** `
      + `(${res.rng.perTrialPy[res.rng.firstDiffTrial].pyDraws} vs ${res.rng.perTrialPy[res.rng.firstDiffTrial].jsDraws}). `
      + 'Od tego miejsca obie wersje losują zupełnie inne wartości, więc dalsze porównanie '
      + 'liczb bezpośrednio nie ma sensu — porównujemy wtedy rozłączne eksperymenty.');
    L.push('');
    L.push('Pierwsze 12 prob (losowania na próbę):');
    L.push('');
    L.push(table(['#', 'PY', 'JS', 'Δ'],
      res.rng.perTrialPy.slice(0, 12).map((r) => [r.trial, r.pyDraws, r.jsDraws, r.pyDraws - r.jsDraws])));
    L.push('');
  } else {
    L.push('Liczba losowań na próbę jest identyczna we **wszystkich** próbach.');
    L.push('');
  }

  // --- wejscie ------------------------------------------------------------
  if (!res.input.same) {
    L.push('### 5. Skrypt wejściowy — różnice dostarczenia');
    L.push('');
    L.push(table(['#', 'akcja (Python)', 'akcja (JS)'], res.input.rows.filter((r) => !r.same).map((r) => [
      r.i,
      r.py ? `${r.py.ev} @ ${num(r.py.t * 1000, 7)} ms` : '—',
      r.js ? `${r.js.ev} @ ${num(r.js.t * 1000, 7)} ms` : '—',
    ])));
    L.push('');
  } else if (res.input.maxTimeDeltaMs > 1e-6) {
    L.push(`### 5. Skrypt wejściowy`);
    L.push('');
    L.push(`Wszystkie ${res.input.countPy} akcji są **te same** (rodzaj + współrzędne co do `
      + `ostatniej cyfry), ale dostarczone są najwyżej **${delta(res.input.maxTimeDeltaMs, ' ms')}** `
      + 'później w JS — to konsekwencja przesuniętego startu próby, a nie przyczyna.');
    L.push('');
  }

  // --- krawedzie bodzca ---------------------------------------------------
  if (res.edge.scenarios.length) {
    L.push('### 6. `isPressedIn` na krawędzi bodźca');
    L.push('');
    L.push('Marginesy kursora wobec czterech krawędzi bodźca `stop` w jednostkach okna, '
      + 'w kolejności `[lewa, prawa, dolna, górna]`; `> 0` = wewnątrz, `= 0` = dokładnie '
      + 'na krawędzi. PsychoPy trafia wszystkie krawędzie (`<=`), PsychoJS/PIXI tylko lewą '
      + 'i dolną (`[lo, hi)`).');
    L.push('');
    L.push(table(
      ['próba', 'offset', 'krawędź', 'marginesy PY', 'marginesy JS', 'trafienie PY', 'trafienie JS', 'co rozstrzygnęło'],
      res.edge.scenarios.map((r) => {
        const fmt = (m) => `[${m.map((v) => num(v, 4)).join(', ')}]`;
        const why = [];
        if (r.floatDiffers) why.push('float');
        if (r.semanticDiffers) why.push('semantyka');
        return [
          r.trial,
          r.offset ? `[${r.offset.map((v) => num(v, 5)).join(', ')}]` : '—',
          r.edge, fmt(r.pyMargins), fmt(r.jsMargins), rd(r.pyHit), rd(r.jsHit),
          why.length ? why.join(' + ') : '—',
        ];
      }),
    ));
    L.push('');
    L.push(`Różny werdykt w **${res.edge.observedDiff.length}** z ${res.edge.scenarios.length} `
      + 'zmierzonych decyzji; szczegóły i wniosek — `../REPORT.md` → sekcja 2 → D. '
      + 'Marginesy na krawędzi są rzędu `1 ulp`, a różnica między wersjami wynika z '
      + 'dodatkowego przebiegu `×720` / `÷720` w PsychoJS, nie z operatora `<=`/`<`.');
    L.push('');
  }
  return L.join('\n');
}

// ------------------------------------------------------------------------ //
//  raport - czesc 2: roznice w logice wykryte automatycznie
// ------------------------------------------------------------------------ //
function logicDifferences(results) {
  const L = [];
  const withTrace = results.filter((r) => r.res.trace.firstFrame !== null);
  const pick = withTrace.find((r) => r.res.reseedPerTrial) ?? withTrace[0];
  const pickAny = withTrace.find((r) => !r.res.reseedPerTrial) ?? pick;
  /** Do tabeli zawiniec wybieramy scenariusz, w ktorym zawiniecia faktycznie wystapily. */
  const pickWrap = withTrace.find((r) => (r.res.trace.wrapOffset?.examples ?? []).length) ?? pickAny;

  L.push('## 2. Różnice w logice — wykryte automatycznie i potwierdzone pomiarem');
  L.push('');
  L.push('Różnice A–C są jedynymi znalezionymi różnicami w **algorytmie samego testu**. '
    + 'Wszystkie pozostałe rozbieżności w raporcie wynikają z nich pośrednio '
    + `(patrz \`out/REPORT.md\` → sekcja 1) albo z formatu paczki wynikowej (sekcja 3). `
    + 'Różnica D jest różnicą **frameworka** — `stop.js` korzysta z `isPressedIn` '
    + 'PsychoJS, `main.py` z `isPressedIn` PsychoPy, a obie implementacje sprawdzają '
    + 'krawędzie bodźca inaczej.');
  L.push('');

  // --- A ------------------------------------------------------------------
  L.push('### A. `dt` wynosi 0 w pierwszej klatce każdej próby (tylko Python)');
  L.push('');
  L.push('**Kod:**');
  L.push('');
  L.push(table(['plik', 'linie', 'kod'], [
    ['`main.py`', '117', '`last_frame_time = global_start`'],
    ['`main.py`', '128–130', '`current_time = core.getTime()` / `dt = current_time - last_frame_time` / `last_frame_time = current_time`'],
    ['`stop.js`', '706', '`let dt = frameDur \|\| (1.0 / 60.0);`'],
  ]));
  L.push('');
  L.push('W `main.py` `last_frame_time` jest ustawiane na `global_start` tuż **przed** wejściem '
    + 'do pętli, więc w pierwszej iteracji `current_time == last_frame_time` i `dt == 0`. '
    + 'Dystraktory (`main.py:147`, `main.py:153`) nie przesuwają się więc w pierwszej klatce próby. '
    + '`stop.js` używa na sztywno `1/60 s`, więc w pierwszej klatce przesuwa je zawsze.');
  L.push('');
  if (pickAny) {
    const ff = pickAny.res.trace.firstFrame;
    const t = ff.trial;
    L.push(`**Pomiar** (scenariusz \`${pickAny.res.name}\`, próba ${t}, pierwsza klatka — współrzędna \`y\` dystraktorów):`);
    L.push('');
    L.push(table(['bodziec', 'pozycja startowa', `Python (klatka ${ff.pyFrame})`, `JS (klatka ${ff.jsFrame})`, 'Python ruszył się?', 'JS ruszył się?'],
      DISTRACTORS.map((s) => [
        `\`${s}\``, num(DISTRACTOR_START_Y, 4),
        num(ff.py[s], 12), num(ff.js[s], 12),
        Math.abs(ff.py[s] - DISTRACTOR_START_Y) <= EPS_POS ? '**nie**' : 'tak',
        Math.abs(ff.js[s] - DISTRACTOR_START_Y) <= EPS_POS ? '**nie**' : '**tak**',
      ])));
    L.push('');
    const counts = pickAny.res.trace.trialsFirstFrameStillAtStart;
    L.push(`W tym scenariuszu z ${counts.considered} wspólnych prób: w **${counts.py}** pierwszych klatkach `
      + `Python wciąż trzyma dystraktor w pozycji startowej, a w **${counts.js}** robi to JS.`);
    L.push('');
  }
  L.push('**Konsekwencja:** dystraktory poruszają się w obu wersjach innymi prędkościami '
    + 'klatka po klatce, więc pozycja ich rozjeżdża się z każdą klatką. W połączeniu '
    + 'z różnicą B daje to narastające przesunięcie zawinięć — tabela klatka po klatce '
    + 'poniżej. Uwaga na wzajemne zniesienie się obu błędów: `dt = 0` w pierwszej klatce '
    + 'opóźnia dystraktor w Pythonie o jedną klatkę, a sprawdzanie stanu sprzed ruchu '
    + 'opóźnia zawinięcie w JS o jedną klatkę, dlatego **pierwsze** zawinięcie wypada '
    + 'w obu wersjach w tej samej klatce, a każde kolejne już nie.');
  L.push('');

  // --- B ------------------------------------------------------------------
  L.push('### B. „Zawijanie” dystraktora o jedną klatkę później w `stop.js`');
  L.push('');
  L.push('**Kod:**');
  L.push('');
  L.push(table(['plik', 'linie', 'kod', 'co sprawdzane'], [
    ['`main.py`', '147–148', '`jelonek.pos = (jx, jy - distraction_speed * dt)` / `if jelonek.pos[1] < -0.6:`', 'pozycja **po** ruchu'],
    ['`main.py`', '153–154', '`drzewo.pos = (dx, dy - distraction_speed * dt)` / `if drzewo.pos[1] < -0.6:`', 'pozycja **po** ruchu'],
    ['`stop.js`', '708–709', '`jelonek.setPos([pos_j[0], pos_j[1] - distraction_speed * dt]);` / `if (pos_j[1] < -0.6) {`', 'pozycja **przed** ruchem'],
    ['`stop.js`', '714–715', '`drzewo.setPos([pos_d[0], pos_d[1] - distraction_speed * dt]);` / `if (pos_d[1] < -0.6) {`', 'pozycja **przed** ruchem'],
  ]));
  L.push('');
  L.push('`stop.js` zapamiętuje `pos_j` / `pos_d` **zanim** przestawi bodziec, a warunek sprawdza '
    + 'tę starą zmienną. `main.py` robi to poprawnie: po `jelonek.pos = ...` sprawdza '
    + '**nową** wartość `jelonek.pos[1]`. Efekt: `stop.js` wykonuje zawinięcie jedną klatkę później.');
  L.push('');
  const w = pickWrap.res.trace.wrapOffset;
  L.push('**Jak to zmierzyć.** Zawinięcia nie da się szukać w trace jako „pozycja spadła '
    + 'poniżej -0.6”, bo `main.py` sprawdza warunek **po** ruchu — pozycja poniżej progu '
    + 'nigdy więc nie trafia do zapisu, bo bodziec jest w tej samej klatce przeniesiony na '
    + 'nowe miejsce. Zawinięcie rozpoznajemy po skoku `y` w górę (z okolic `-0.6` na `-0.1`), '
    + 'a pozycję sprzed zawinięcia czytamy z klatki poprzedzającej skok.');
  L.push('');
  L.push(`**Pomiar zbiorczy** (scenariusz \`${pickWrap.res.name}\`): w ${w.trialsWithWraps} wspólnych `
    + `próbach z co najmniej jednym zawinięciem Python wykonał łącznie ${w.wrapsPy} zawinięć, `
    + `JS ${w.wrapsJs}. Zawinięcia parujemy wg numeru w próbie **tylko do momentu rozjazdu `
    + 'strumienia RNG** (różnica C) — dalej obie wersje losują różne prędkości, więc „ta sama '
    + `para” zawinięć już nic nie znaczy. Na tym odcinku: JS zawija **później** w `
    + `${w.jsLater} przypadkach, Python później w ${w.pyLater}, a w ${w.same} obie wersje `
    + 'zawijają w tej samej klatce.');
  L.push('');
  for (const e of w.examples) {
    L.push(`**Pomiar klatka po klatce** (scenariusz \`${pickWrap.res.name}\`, próba ${e.trial}, bodziec `
      + `\`${e.stim}\` — ${e.wrapsPy} zawinięć w Pythonie, ${e.wrapsJs} w JS; klatki numerowane od początku próby):`);
    L.push('');
    const rows = [];
    const n = Math.min(e.pyFrames.length, e.jsFrames.length);
    for (let k = 0; k < n; k += 1) {
      rows.push([k + 1, e.pyFrames[k], e.jsFrames[k], `**${e.jsFrames[k] - e.pyFrames[k]}**`]);
    }
    L.push(table(['zawinięcie', 'klatka PY', 'klatka JS', 'Δ klatek'], rows));
    L.push('');
    L.push(`Pozycja \`y\` w ostatniej klatce **przed** pierwszym zawinięciem oraz najniższa `
      + `pozycja osiągnięta w całej próbie (próg zawinięcia to ${num(WRAP_Y, 2)}):`);
    L.push('');
    L.push(table(['wielkość', 'Python', 'JS'], [
      ['`y` przed 1. zawinięciem', num(e.preWrapPy, 8), num(e.preWrapJs, 8)],
      ['najniższe `y` w próbie', num(e.minPy, 8), num(e.minJs, 8)],
    ]));
    L.push('');
    L.push('Tu widać tę różnicę w liczbach: Python przekracza próg i od razu zawija, więc jego '
      + 'najniższa pozycja leży tuż **nad** `-0.6`. JS wykonuje najpierw ruch, a warunek '
      + 'sprawdza dopiero w następnej klatce, więc pozycja wykracza poza próg o cały krok '
      + '(`-0.6 - speed·dt`) i zawinięcie wypada o jedną klatkę później. Przy kolejnym '
      + 'zawinięciu obie wersje startują z tego samego miejsca, więc różnica się nie znosi — '
      + 'narasta o jedną klatkę na każde zawinięcie (kolumna „Δ klatek”).');
    L.push('');
  }

  // --- C ------------------------------------------------------------------
  L.push('### C. Konsekwencja: rozjazd strumienia RNG, czyli dwa różne eksperymenty');
  L.push('');
  L.push('Zawięcie to `2 × Math.random()` na dystraktor (jedno losowanie na stronę, jedno na '
    + 'odległość), czyli **2 losowania**. Różna liczba zawinięć w próbie N oznacza więc inną '
    + 'liczbę losowań, a to — w trybie ciągłym — zupełnie inne `stopOnset`, pozycje i prędkości '
    + 'we **wszystkich kolejnych** próbach.');
  L.push('');
  L.push(table(['scenariusz', 'tryb', 'pierwsza próba o innej liczbie losowań', 'zgodnych `stopOnset` (względem startu próby)', 'zgodnych RT'],
    results.map(({ res }) => [
      `\`${res.name}\``,
      res.reseedPerTrial ? 'izolowany' : 'ciągły',
      res.rng.firstDiffTrial === null ? 'brak' : `próba ${res.rng.firstDiffTrial}`,
      `${res.timeline.identicalRelOnsets} / ${res.timeline.onsetRelDiff.length}`,
      `${res.trials.agreeingRts} / ${res.trials.rtDeltasMs.length}`,
    ])));
  L.push('');
  const iso = results.filter(({ res }) => res.reseedPerTrial);
  if (iso.length) {
    L.push('W scenariuszach `iso_*` (restart generatora na każdej próbie) te trzy różnice są '
      + 'widoczne **w czystej postaci** — jedna próba, jeden bodziec, jedna klatka — '
      + 'a mimo to zgodne pozostają wszystkie czasy reakcji.');
    L.push('');
  }
  // --- C: dowod zwiazku przyczynowego 4 losowania = 1 zawiniecie ----------
  // `rng_draws_at_clear[t]` to liczba losowan od `clearEvents()` proby t-1 do
  // `clearEvents()` proby t, wiec zawiera PETLE proby t-1 (zawiniecia) plus
  // KONFIGURACJE proby t. Dlatego zawiniecia porownujemy z poprzednia proba.
  const causal = results.map(({ res }) => {
    const t = res.rng.firstDiffTrial;
    if (t === null || t === 0) return null;
    const w = res.trace.wrapPerTrial.find((x) => x.trial === t - 1) ?? { py: 0, js: 0 };
    const d = res.rng.perTrialPy[t];
    return { res, t, d, w };
  }).filter(Boolean);
  if (causal.length) {
    L.push('**Dowód związku przyczynowego.** Licznik `rng_draws_at_clear[t]` mierzy losowania '
      + 'od `clearEvents()` próby `t-1` do `clearEvents()` próby `t`, czyli obejmuje **pętlę '
      + 'próby `t-1`** (zawinięcia, po 2 losowania na bodziec) oraz konfigurację próby `t` '
      + '(stałe 7 losowań). Bierzemy więc pierwszą próbę, w której licznik się rozjechał, i '
      + 'porównujemy go z liczbą zawinięć zmierzoną w **poprzedniej** próbie:');
    L.push('');
    L.push(table(['scenariusz', 'okno', 'Δ losowań', 'zawinięć w próbie t-1: PY', 'JS', 'Δ zawinięć', '2 × Δ zawinięć', 'zgodne?'],
      causal.map(({ res, t, d, w }) => {
        const dw = w.py - w.js;
        return [
          `\`${res.name}\``, `${t - 1} → ${t}`, `**${d.pyDraws - d.jsDraws}**`, w.py, w.js, `**${dw}**`,
          2 * dw, d.pyDraws - d.jsDraws === 2 * dw ? '**tak**' : 'nie',
        ];
      })));
    L.push('');
    const okCount = causal.filter(({ d, w }) => d.pyDraws - d.jsDraws === 2 * (w.py - w.js)).length;
    L.push(`Zgodność w **${okCount} z ${causal.length}** scenariuszy. `
      + 'Każde zawinięcie to `2 × Math.random()` (jedno na stronę, jedno na odległość), '
      + 'więc jedno brakujące zawinięcie = 2 brakujące losowania, a jeden dystraktor '
      + 'zawijający się o jedną klatkę wcześniej = dokładnie tyle. Niezgodne wiersze to '
      + 'przypadki, w których pierwszą rozbieżność wprowadziło coś innego — '
      + '`training` to znana różnica strukturalna (`main.py:22` robi 5 prób treningowych, '
      + '`stop.js` ignoruje flagę i robi 50, więc okno losowań obejmuje różny liczbę prób).');
    L.push('');
  }

  // --- D ------------------------------------------------------------------
  L.push('### D. Kliknięcie na krawędzi bodźca: `isPressedIn` `<=` vs przedział półotwarty');
  L.push('');
  L.push('**Kod:**');
  L.push('');
  L.push(table(['framework', 'gdzie', 'warunek', 'krawędzie "trafione"'], [
    ['PsychoPy', '`Mouse.isPressedIn`', '`abs(pos[0]-sx) <= w and abs(pos[1]-sy) <= h`', 'wszystkie cztery (`<=`)'],
    ['PsychoJS', '`Mouse.isPressedIn` → `VisualStim.contains` → `PIXI.Rectangle.contains`', '`x >= left and x < right and y >= top and y < bottom`', 'tylko lewa i dolna'],
  ]));
  L.push('');
  L.push('To różnica **semantyczna**, nie numeryczna: strona `stop.js` nie porównuje pozycji, '
    + 'tylko korzysta z tego, czym `isPressedIn` zrobi framework. Znaczy: klik dokładnie na '
    + 'prawej albo górnej krawędzi znaku STOP jest w Pythonie trafieniem, a w JS nie; '
    + 'klik na lewej albo dolnej — odwrotnie.');
  L.push('');
  L.push('**Pomiar.** Symulatory logują cztery odległości kursora od krawędzi prostokata '
    + '(w jednostkach okna, układ (0,0) w środku okna, y w górę — dokładnie te wartości, '
    + `które porównuje \`isPressedIn\`) dla każdej decyzji, w której margines jest mniejszy `
    + `niż ${EDGE_EPS} jednostki okna (${num(EDGE_EPS * 720, 1)} px). `
    + 'Kolumna „margines" to najmniejsza z ośmiu zmierzonych wartości: '
    + '`> 0` = wewnątrz, `= 0` = dokładnie na krawędzi, `< 0` = o ~1 ulp na zewnątrz.');
  L.push('');
  const edgeRows = results.filter(({ res }) => res.edge.scenarios.length);
  if (edgeRows.length) {
    const tableRows = [];
    for (const { res } of edgeRows) {
      for (const r of res.edge.scenarios) {
        const off = r.offset ? `[${r.offset.map((v) => num(v, 5)).join(', ')}]` : '—';
        const why = [];
        if (r.floatDiffers) why.push('float');
        if (r.semanticDiffers) why.push('semantyka');
        tableRows.push([
          `\`${res.name}\``, r.trial, off, r.edge,
          rd(r.margin), rd(r.pyHit), rd(r.jsHit),
          r.pyHit === r.jsHit ? 'zgodne' : `**${r.pyHit ? 'PY' : 'JS'} trafia**`,
          why.length ? why.join(' + ') : '—',
        ]);
      }
    }
    L.push(table(['scenariusz', 'próba', 'offset kliku', 'krawędź', 'margines', 'trafienie PY', 'trafienie JS', 'werdykt', 'co rozstrzygnęło'], tableRows));
    L.push('');
    const nObs = edgeRows.reduce((s, { res }) => s + res.edge.observedDiff.length, 0);
    const nSem = edgeRows.reduce((s, { res }) => s + res.edge.semanticOnly.length, 0);
    const nFloat = edgeRows.reduce((s, { res }) => s + res.edge.floatNoise.length, 0);
    const nAll = edgeRows.reduce((s, { res }) => s + res.edge.scenarios.length, 0);
    const gapUnits = Math.max(...edgeRows.map(({ res }) => res.edge.maxMarginGap));
    L.push(`Łącznie zmierzono ${nAll} decyzji \`isPressedIn\` podmiescionych na krawędzi. `
      + `Różny werdykt wyszedł w **${nObs}** z nich. W każdym z tych przypadków decyzję podjęła `
      + `**arytmetyka zmiennoprzecinkowa** — te same operatory zastosowane do marginesów `
      + `policzonych przez *drugą* wersję dają inny wynik w ${nFloat} przypadkach na `
      + `${nObs} rozbieżnych. W ${nSem} przypadku różniła się dodatkowo semantyka. `
      + 'Nigdy nie zdarzyło się, żeby przy identycznych wartościach zmiennoprzecinkowych '
      + 'sama semantyka przesądziła o wyniku — powód wyjaśnia punkt 2 niżej.');
    L.push('');
    L.push('**Wniosek: różnica jest realna w kodzie, ale nieobserwowalna w liczbach.**');
    L.push('');
    L.push('1. **Operatory różnią się tylko na granicy.** `<=` i `<` dają ten sam wynik dla '
      + 'każdego marginesu równego `0` i dla każdego marginesu różnego od `0` z obu stron. '
      + 'Jedyne miejsce, w którym predykaty się rozjeżdżają, to margines **dokładnie równy '
      + 'zero** — czyli kursor współrzędna co do bitu na krawędzi.');
    L.push('2. **Trafienie w dokładne zero jest przypadkiem.** Margines powstaje z losowej pozycji '
      + 'bodźca i losowej pozycji kursora, więc jest zwykłą liczbą `double`; szansa, że wyjdzie '
      + 'identycznie zero, jest rzędu `1 ulp`, a nie `1/2`. W tabeli widać, że marginesy równe '
      + 'zero pojawiają się wyłącznie dlatego, że scenariusz kładzie kursor **konstrukcyjnie** '
      + 'na krawędzi (`target_offset` = ±0.1 przy bodźcu o półwysokości 0.1).');
    L.push('3. **Na granicy i tak rozstrzyga zaokrąglenie, nie operator.** PsychoJS liczy '
      + 'margines w pikselach po dodatkowym przebiegu `×720` i `÷720` '
      + '(`Mouse.getPos()` → `to_win` → `getPositionFromObject` → `to_px`), PsychoPy liczy go '
      + 'wprost w jednostkach okna. Zmierzona różnica marginesów między wersjami dla tego samego '
      + `kliku to maksymalnie ${rd(gapUnits)} jednostki okna, czyli ${rd(gapUnits * 720)} px — `
      + 'a znak tego ~1 ulp decyduje o tym, kto „trafił". To szum arytmetyczny, nie różnica '
      + 'semantyki.');
    L.push('4. **Prawdziwy kursor eliminuje problem.** Mysz raportuje **całkowite piksele**. Przy '
      + 'oknie 1280×720 i `units=\'height\'` jeden piksel to `1/720 ≈ 0.00139` jednostki okna, '
      + `czyli ok. 8·10¹³ razy więcej niż ten ulp. Trafienie *dokładnie* w krawędź losowo `
      + 'położonego bodźca ma prawdopodobieństwo rzędu `1/10¹³` na klik.');
    const eEdge = results.find(({ res }) => res.name === 'edge_click')?.res;
    const eIso = results.find(({ res }) => res.name === 'iso_edge_click')?.res;
    L.push('5. **Konsekwencja praktyczna: brak.** Rozjazd z powodu krawędzi jest widoczny tylko '
      + 'w scenariuszach celowo kladających kursor na krawędź: '
      + (eIso ? `\`iso_edge_click\` — ${eIso.edge.observedDiff.length}/50 prób; ` : '')
      + (eEdge ? `\`edge_click\` — ${eEdge.edge.observedDiff.length}/50 prób (pozostałe rozjazdy `
        + 'w tym scenariuszu to skutek różnic A–C). ' : '')
      + 'W prawdziwym eksperymencie obie wersje dają identyczne wyniki. Nie zmienia to nawet '
      + 'tabeli wyników: w `edge_click` Python liczy 3 trafienia, JS 2, ale `stopOnset` i RT '
      + 'są zgodne we wszystkich 50 próbach.');
    L.push('');
    const mismatch = edgeRows.filter(({ res }) => res.edge.pyOnly || res.edge.jsOnly);
    if (mismatch.length) {
      L.push(`Uwaga: ${mismatch.map(({ res }) => `\`${res.name}\` (${res.edge.pyOnly} tylko PY, `
        + `${res.edge.jsOnly} tylko JS)`).join(', ')} — decyzje zalogowane tylko przez jedną wersję.`);
      L.push('');
    }
  } else {
    L.push('_Brak scenariuszy z kliknięciem na krawędzi bodźca._');
    L.push('');
  }
  return L.join('\n');
}

// ------------------------------------------------------------------------ //
//  raport - czesc 3: roznice w formacie paczki
// ------------------------------------------------------------------------ //
function payloadDifferences(results) {
  const L = [];
  const seen = new Map();
  for (const { res } of results) {
    if (!res.okPy || !res.okJs) continue;
    for (const d of res.payload.different) {
      const id = d.key;
      if (!seen.has(id)) seen.set(id, { key: id, scenarios: [], py: d.py, js: d.js, stable: true });
      const e = seen.get(id);
      e.scenarios.push(res.name);
      if (JSON.stringify(e.py) !== JSON.stringify(d.py) || JSON.stringify(e.js) !== JSON.stringify(d.js)) e.stable = false;
    }
  }
  L.push('## 3. Różnice w formacie paczki wynikowej');
  L.push('');
  L.push('Poniższe różnice **nie zmieniają zachowania testu** — dotyczą wyłącznie tego, '
    + 'co trafia do launchera. Występują we wszystkich scenariuszach, w których obie wersje '
    + 'w ogóle produkują paczkę.');
  L.push('');

  L.push('### 3.1. Klucze obecne tylko w jednej wersji');
  L.push('');
  const onlyPy = [...new Set(results.flatMap(({ res }) => res.payload.keysOnlyPy))];
  const onlyJs = [...new Set(results.flatMap(({ res }) => res.payload.keysOnlyJs))];
  L.push(table(['klucz', 'występuje w', 'źródło'], [
    ...onlyPy.map((k) => [`\`${k}\``, `tylko Python (${countIn(results, (r) => r.payload.keysOnlyPy.includes(k))}/${results.length} scenariuszy)`, '`main.py:36`, `main.py:39`, `main.py:45`']),
    ...onlyJs.map((k) => [`\`${k}\``, `tylko JS (${countIn(results, (r) => r.payload.keysOnlyJs.includes(k))}/${results.length} scenariuszy)`, '—']),
  ]));
  L.push('');
  L.push('* `totalClicks` (top-level), `statystyki.sredni_czas_ms` i `statystyki.totalClicks` '
    + 'dodaje wyłącznie `main.py`. `statystyki.sredni_czas_ms` jestduplikatem pola '
    + '`sredni_czas_reakcji` o tej samej wartości.');
  L.push('');

  L.push('### 3.2. Nadmiarowe pola w każdym wierszu `wyniki` (tylko JS)');
  L.push('');
  const extraAll = [...new Set(results.flatMap(({ res }) => res.trials.extraKeysJs))];
  L.push(table(['pole', 'typ', 'źródło'], extraAll.map((k) => [
    `\`${k}\``,
    k.startsWith('mouse.') ? 'napis `"[]"`' : (typeof (results.find(({ res }) => res.trials.keysJs.includes(k))?.res.trials.rows[0]?.js?.[k]) === 'object' ? 'obiekt' : 'liczba/napis'),
    k.startsWith('mouse.') ? '`stop.js:837-842` (psychojs serializuje tablicę na napis)'
      : k.startsWith('trials.') ? '`ExperimentHandler` (pętla w `updateInfo`)'
        : k.startsWith('drive.') ? '`stop.js:564`, `stop.js:835`'
          : '`ExperimentHandler` (`session`, `date`, `expName`, `psychopyVersion`, `OS`, `frameRate`)',
  ])));
  L.push('');

  L.push('### 3.3. Wartości różniące się między wersjami (stałe pola)');
  L.push('');
  if (!seen.size) {
    L.push('_brak stabilnych różnic poza kluczami losowymi_');
  } else {
    L.push(table(['pole', 'Python', 'JS', 'scenariusze'],
      [...seen.values()].map((e) => [
        `\`${e.key}\``, rs(e.py), rs(e.js),
        `${e.scenarios.length}${e.stable ? '' : ' (wartości zmienne między scenariuszami)'}`,
      ])));
  }
  L.push('');

  L.push('### 3.4. Znaczniki losowe / zależne od środowiska');
  L.push('');
  const vol = [...new Set(results.flatMap(({ res }) => res.payload.volatile.map((d) => d.key)))];
  L.push(`Pola oznaczone jako losowe/zależne od środowiska w tym przebiegu: ${vol.map((k) => `\`${k}\``).join(', ')}.`);
  L.push('');
  L.push(table(['pole', 'dlaczego różni się z definicji'], [
    ['`timestamp`', '`main.py:31` używa `datetime.utcnow().isoformat()` (mikrosekundy); `stop.js` zapisuje `new Date().toISOString()` — zawsze 3 miejsca po kropce'],
    ['`subjectId`', '`main.py:30` losuje numer **na końcu** eksperymentu (po wszystkich próbach), JS losuje `expInfo.participant` **przy ładowaniu modułu** (przed pierwszą próbą) — przy tym samym LCG dają różne wartości'],
    ['`session`, `date`, `expName`, `psychopyVersion`, `OS`, `frameRate`', 'dodaje wyłącznie `ExperimentHandler` PsychoJS'],
  ]));
  L.push('');
  L.push('Uwaga: również sama funkcja losowania jest inna — `random.randint(0, 999999)` w Pythonie '
    + 'osiąga wartość 999999, a `util.randint(0, 999999)` w PsychoJS 2025.1.1 tylko 999998 '
    + '(implementacja: `Math.floor(Math.random() * (max - min)) + min`). Różnica 1 na milion.');
  L.push('');
  return L.join('\n');
}

const countIn = (results, pred) => results.filter(({ res }) => pred(res)).length;

// ------------------------------------------------------------------------ //
function main() {
  const wanted = process.argv.slice(2).filter((a) => !a.startsWith('-'));
  const available = SCENARIOS.filter((s) => fs.existsSync(path.join(OUT, s.name, 'meta_py.json')));
  const list = wanted.length ? available.filter((s) => wanted.includes(s.name)) : available;
  if (!list.length) {
    process.stderr.write('brak wynikow w out/ - najpierw uruchom tests/run_all.mjs\n');
    return 2;
  }

  const results = [];
  for (const sc of list) {
    const dir = path.join(OUT, sc.name);
    const res = compareScenario(sc.name);
    fs.writeFileSync(path.join(dir, 'report.json'), JSON.stringify(res, null, 2), 'utf8');
    fs.writeFileSync(path.join(dir, 'report.md'),
      `# \`${sc.name}\`\n\n${scenarioReport(res, sc.description)}\n`, 'utf8');
    results.push({ res, sc });
    process.stdout.write(`porownano ${sc.name}: `
      + `${res.trials.sameCount}/${Math.max(res.trials.countPy, res.trials.countJs)} prob identycznych, `
      + `Δrt_max=${res.trials.maxRtDeltaMs.toExponential(2)} ms, `
      + `klucze tylko PY=[${res.payload.keysOnlyPy}] tylko JS=[${res.payload.keysOnlyJs}]\n`);
  }

  fs.writeFileSync(path.join(OUT, 'report.json'),
    JSON.stringify(results.map((r) => r.res), null, 2), 'utf8');

  const total = Math.max(...results.map(({ res }) => Math.max(res.trials.countPy, res.trials.countJs)));
  const L = [];
  L.push('# Test `Stop` — porównanie `main.py` (PsychoPy) ⇄ `stop.js` (PsychoJS)');
  L.push('');
  L.push(`Wygenerowano ${new Date().toISOString().replace('T', ' ').slice(0, 19)} · `
    + `${results.length} scenariuszy · ${total} prób na scenariusz · oba pliki uruchomione **bez modyfikacji**.`);
  L.push('');
  L.push('## 0. Metoda');
  L.push('');
  L.push('Oba pliki źródłowe są uruchamiane **w całości i bez zmian** — za atrapą frameworka:');
  L.push('');
  L.push(table(['plik', 'atrapa', 'atrapa'], [
    ['`main.py`', '`tests/py/psychopy/{_sim,visual,event,core}.py`', 'wirtualny zegar, LCG, bodźce, `event.getKeys`/`clearEvents`, `Mouse.isPressedIn`'],
    ['`stop.js`', '`tests/js/{psychojs_stub,dom,sim}.mjs`', 'jeden i ten sam zegar/LCG, natywne zdarzenia DOM, re-implementacja PsychoJS 2025.1.1'],
  ]));
  L.push('');
  L.push('Wspólny protokół, identyczny dla obu stron:');
  L.push('');
  L.push('* **zegar wirtualny** — startuje w `0` i rośnie o `frame_ms` przy każdej prezentacji klatki '
    + '(`win.flip()` / `render()`); `performance.now()` i `core.getTime()` czytają z niego;');
  L.push('* **generator losowy** — identyczny LCG w obu stronach: '
    + '`state = (state·1664525 + 1013904223) mod 2³²`, `random() = state / 2³²`, '
    + '`randint(a,b) = a + ⌊random()·(b−a+1)⌋` w Pythonie; `stop.js` dodatkowo losuje '
    + '`expInfo.participant` przy ładowaniu modułu, więc harness Pythonu zużywa jedno losowanie '
    + 'przed startem, żeby wyrównać strumienie;');
  L.push('* **wejście** — akcje scenariusza są dostarczane **leniwie**, przy każdym odczycie wejścia '
    + '(`getKeys` / `getPressed` / `getPos` / `isPressedIn`), a nie w chwili flipu. Dzięki temu obie '
    + 'wersje próbują odczytać wejście w tych samych absolutnych momentach wirtualnych;');
  L.push('* **scenariusz** — jeden plik JSON na scenariusz, generowany przez `tests/scenarios.mjs` '
    + 'i czytany przez oba runnery, więc obie strony dostają dane bajt w bajt identyczne.');
  L.push('');
  L.push('Konsekwencja protokołu: **każda różnica w wyniku jest realną różnicą logiki**, '
    + 'a nie artefaktem harnessa. Jedyny wyjątek to różnice zjawisk fizycznych, '
    + 'których symulator nie modeluje (czas reakcji sprzętowy, rozmycie, realne odświeżanie monitora) '
    + '— opisane w sekcji 5.');
  L.push('');

  // --- 1. podsumowanie ---------------------------------------------------- //
  L.push('## 1. Podsumowanie scenariuszy');
  L.push('');
  L.push(table(
    ['scenariusz', 'prób', 'identycznych', 'Δrt maks.', 'zgodnych `stopOnset`', 'zgodnych długości prób', 'różne pola paczki', 'tylko PY', 'tylko JS'],
    results.map(({ res }) => [
      `\`${res.name}\``,
      `${res.trials.countPy} / ${res.trials.countJs}`,
      `${res.trials.sameCount} / ${Math.max(res.trials.countPy, res.trials.countJs)}`,
      res.trials.maxRtDeltaMs === 0 ? '0' : res.trials.maxRtDeltaMs.toExponential(2),
      `${res.timeline.identicalRelOnsets} / ${res.timeline.onsetRelDiff.length}`,
      `${res.timeline.identicalDurations} / ${res.timeline.durationMs.length}`,
      res.payload.different.length,
      res.payload.keysOnlyPy.join(', ') || '—',
      res.payload.keysOnlyJs.join(', ') || '—',
    ]),
  ));
  L.push('');
  L.push('*„prób PY / JS” to liczba wierszy `wyniki`; „identycznych” liczy próby, w których '
    + 'wszystkie pola `stopOnset`, `responded`, `correct`, `isFalstart` i `rt` są równe '
    + '(dla `rt` tolerancja 1 ns).*');
  L.push('');
  L.push('Pełne tabelaryczne porównanie każdej scenariuszu: `out/<scenariusz>/report.md`; '
    + 'wersja maszynowa: `out/<scenariusz>/report.json` oraz `out/report.json`.');
  L.push('');

  L.push(logicDifferences(results));
  L.push('');
  L.push(payloadDifferences(results));
  L.push('');

  // --- 4. zachowanie poszczegolnych scenariuszy --------------------------- //
  L.push('## 4. Zachowanie szczególnych scenariuszy');
  L.push('');
  L.push('### 4.1. Tryb bez launchera (`no_launcher`)');
  L.push('');
  L.push('Żadna wersja nie zapisuje paczki: `main.py:215-216` robi `return` przed `_write_results`, '
    + 'a `stop.js` loguje tryb przeglądarkowy. Oba przebiegi są mimo to w pełni wykonane '
    + '(`out/no_launcher/meta_*.json`).');
  L.push('');
  L.push('### 4.2. Tryb treningowy (`training`, `NOUS_TRAINING=1`)');
  L.push('');
  L.push('`main.py:22` ustawia `N_TRIALS = 50 if not NOUS_TRAINING else 5`. `stop.js` ma '
    + 'zawsze `nReps: 50` i zmiennej środowiskowej w ogóle nie czyta — trening w JS po prostu '
    + 'nie istnieje (45 dodatkowych prób).');
  L.push('');
  L.push('### 4.3. Przerwanie klawiszem ESC');
  L.push('');
  L.push(table(['scenariusz', 'co robi', 'Python', 'JS'], [
    ['`esc_mid`', 'ESC w trakcie trwającej próby', 'przerwana próba **nie trafia** do `wyniki`; statystyki liczone z 3 ukończonych', 'tak samo'],
    ['`esc_welcome`', 'ESC na ekranie powitalnym', '`score: ""`, `wyniki: []`', '`score` = pełny tekst `Poprawne: 0 | Błędne: 0 | …`, `wyniki: []`'],
    ['`esc_and_space`', 'ESC i SPACJA w tej samej klatce', 'próba ginie całkowicie (`wyniki: []`)', 'tak samo'],
  ]));
  L.push('');
  L.push('Kolejność jest odwrotna: `main.py:167-170` sprawdza ESC **przed** obsługą reakcji, '
    + '`stop.js:800` sprawdza ESC **na końcu** klatki — po obsłudze kliknięć i SPACJI. '
    + 'Dlatego w `esc_and_space` obie wersje gubią próbę (w JS SPACJA najpierw ją „zatwierdza”, '
    + 'potem ESC przerywa cały eksperyment).');
  L.push('');
  L.push('### 4.4. Dotyk');
  L.push('');
  L.push('`main.py` nie ma żadnej obsługi dotyku — nie ma `pixi.Touch`, nie ma '
    + '`event.getTouches()`. Wszystkie próby z dotykiem kończą się u niego bez reakcji. '
    + '`stop.js` obsługuje dotyk, ale **dwiema niezależnymi drogami**, z czego działa tylko jedna:');
  L.push('');
  L.push('1. `EventManager.addMouseListeners` (`stop.js` w kodzie PsychoJS) — `touchstart` '
    + 'ustawia `pressed[0] = 1` i `Mouse.getPos()`; to jest ta droga, która faktycznie działa;');
  L.push('2. własna obsługa `touchToPsycho` (`stop.js:237-244`) — liczy '
    + '`x = 2·(clientX − W/2)/H`, `y = 2·(H/2 − clientY)/H`, czyli pozycję **2× większą** '
    + 'niż pozycja w jednostkach okna; dlatego `window._touchPsychoX/Y` i cała gałąź '
    + '`pointInStim` (`stop.js:684-691`, `771-787`) to kod nieosiągalny.');
  L.push('');
  L.push('### 4.5. Ekran powitalny');
  L.push('');
  L.push('Próg wejścia jest w obu wersjach ten sam (tylko `space`), ale `main.py:79` '
    + 'używa `event.waitKeys(keyList=[...])`, a `stop.js` `eventManager.getKeys(...)` '
    + 'wewnątrz pętli. Różnica pojawia się przy klawiszu wciśniętym **przed** pierwszą '
    + 'odczytaną klatką scenariusza `welcome_very_early` — dlatego wariant ten jest osobno '
    + 'przetestowany.');
  L.push('');

  // --- 5. zalozenia -------------------------------------------------------- //
  L.push('## 5. Założenia i ograniczenia harnessa');
  L.push('');
  L.push('| # | Założenie | Dlaczego |');
  L.push('| --- | --- | --- |');
  L.push('| 1 | Okno symulacji ma 1280×720 px, `units=\'height\'` → 1 jednostka = 720 px. | `Window(minSize = 720)` w obu wersjach; pozycje bodźców w jednostkach okna są niezależne od rozmiaru, ale kliknięcia — nie. |');
  L.push('| 2 | `Mouse.isPressedIn` w PsychoPy używa symetrycznego `<=` na obu osiach. | Prawdziwy PsychoPy: `withinRect` z porównaniem `<=`. Różnica zmierzona w sekcji 2 → D. |');
  L.push('| 3 | `Mouse.isPressedIn` w PsychoJS używa `>=` od dołu i `<` od góry/prawej. | Prawdziwy PsychoJS 2025.1.1 → `VisualStim.contains` → `_getBoundingBox_px().contains` → `PIXI.Rectangle.contains` (przedział półotwarty). Różnica zmierzona w sekcji 2 → D. |');
  L.push('| 4 | `stop.js` jest bundlem z mapą źródłową; stub PsychoJS odtworzony z `psychojs-2025.1.1.js.map`. | Jedyna wiarygodna podstawa — brak źródeł w repozytorium. |');
  L.push('| 5 | Zegar wirtualny przesuwa się **tylko** przy prezentacji klatki. | Dzięki temu „czas wirtualny” znaczy „czas prezentowany”, a nie czas ściany. `stop.js` liczy ruch z `frameDur = 1/60`, `main.py` z `dt` — to właśnie jest badana różnica. |');
  L.push('| 6 | PsychoJS nie prezentuje ostatniej klatki rutyny (`EachFrame` zwraca `NEXT`, nie `FLIP_REPEAT`). | Wymusza dodatkowy restart generatora w `Sim.sealFrame()` — inaczej losowania z ostatniej klatki trafiałyby do konfiguracji następnej próby i scenaariusze `iso_*` nie byłyby izolowane. |');
  L.push('| 7 | `datetime.utcnow()` w `main.py:31` jest deprecated od Pythona 3.12. | Runnery uruchamiane są z `-W ignore::DeprecationWarning`. |');
  L.push('| 8 | `main.py` jest kopiowany do `out/<scenariusz>/run/`, a `resources/` to dowiązanie symboliczne. | Żeby `results.json` nie lądował w repozytorium. |');
  L.push('| 9 | Zawinięcia dystraktorów wykrywane są po skoku `y` w górę, nie po przekroczeniu progu `-0.6`. | `main.py` sprawdza warunek **po** ruchu, więc pozycja poniżej progu nigdy nie trafia do trace — bodziec jest w tej samej klatce przeniesiony na nowe miejsce. Skok zawinięcia to ok. `0.5` jednostki okna, a zwykły ruch maks. ok. `0.05` na klatkę, więc próg `0.1` rozdziela je jednoznacznie. |');
  L.push('');
  L.push('### Czego harness **nie** modeluje');
  L.push('');
  L.push('* rzeczywistego czasu reakcji sprzętu (klawiatura/myszcz),');
  L.push('* realnego odświeżania monitora — `frame_ms` jest stałe w obrębie scenariusza, '
    + 'a `getActualFrameRate()` w PsychoJS raportuje 60 przez cały przebieg '
    + '(`_lastDelta === 0` w pierwszej klatce `updateInfo`);');
  L.push('* deprecacji `webkitResolveLocalFileSystemURL` i realnego wczytywania obrazków — '
    + 'stub ładuje je z metadanych bodźców.');
  L.push('');
  L.push('Dwie z powyższych różnic — `frameDur = 1/60` w JS wobec `dt` w Pythonie — są realnymi '
    + 'zachowaniami obu wersji i zostały przetestowane oddzielnie (scenariusze na 40 Hz: '
    + '`slow_reported_60` i `iso_slow_40hz`).');
  L.push('');

  // --- 6. szczegoly ------------------------------------------------------- //
  L.push('## 6. Szczegóły scenariuszy');
  L.push('');
  for (const { res, sc } of results) {
    L.push(scenarioReport(res, sc.description));
    L.push('');
  }

  fs.writeFileSync(path.join(OUT, 'REPORT.md'), L.join('\n'), 'utf8');
  process.stdout.write(`\nraport: ${path.relative(process.cwd(), path.join(OUT, 'REPORT.md'))}\n`);
  return 0;
}

process.exitCode = main();
