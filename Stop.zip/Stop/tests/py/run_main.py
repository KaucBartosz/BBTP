﻿# -*- coding: utf-8 -*-
"""Harness testowy: uruchamia ORYGINALNY `Stop/main.py` w wirtualnym
symulatorze PsychoPy i zapisuje wynik + trace do katalogu `out/`.

Uzycie:
    python run_main.py --scenario scenarios/full.json --out out/full
"""
from __future__ import annotations

import argparse
import json
import os
import random
import runpy
import shutil
import sys
import time
import traceback
from pathlib import Path

HERE = Path(__file__).resolve().parent
TESTS_DIR = HERE.parent
STOP_DIR = TESTS_DIR.parent

# katalog testowy musi byc PRZED ewentualnie zainstalowanym PsychoPy
sys.path.insert(0, str(HERE))
for _mod in [m for m in list(sys.modules) if m == "psychopy" or m.startswith("psychopy.")]:
    del sys.modules[_mod]

import psychopy  # noqa: E402  (atrapa, nie prawdziwy PsychoPy)
from psychopy import _sim  # noqa: E402


def prepare_run_dir(out_dir: Path) -> Path:
    """Kopia main.py do katalogu roboczego (zeby `results.json` nie trafilo
    do repozytorium) + dowiÄ…zanie do oryginalnych zasobow."""
    run_dir = out_dir / "run"
    if run_dir.exists():
        shutil.rmtree(run_dir)
    run_dir.mkdir(parents=True)
    shutil.copy2(STOP_DIR / "main.py", run_dir / "main.py")
    res_link = run_dir / "resources"
    if not res_link.exists():
        try:
            os.symlink(STOP_DIR / "resources", res_link, target_is_directory=True)
        except (OSError, NotImplementedError, AttributeError):
            pass
    return run_dir


def patch_random(lcg: _sim.LCG) -> None:
    """Podmienia `random` na ten sam LCG, ktory uzywa symulator JS."""
    random.random = lcg.random
    random.randint = lcg.randint


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--scenario", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    scenario = json.loads(Path(args.scenario).read_text(encoding="utf-8"))
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    run_dir = prepare_run_dir(out_dir)

    sim = _sim.Sim(scenario)
    _sim.SIM = sim
    lcg = sim.rng
    patch_random(lcg)
    # stop.js losuje `expInfo.participant` (util.randint) w momencie zaladowania
    # modulu, czyli PRZED pierwsza proba.  main.py losuje subjectId dopiero na
    # koncu.  Jedno "przeduzycie" wyrĂłwnuje strumienie RNG obu wersji.
    lcg.random()

    os.environ["NOUS_LAUNCHER"] = "1" if scenario.get("launcher", True) else "0"
    os.environ["NOUS_TRAINING"] = "1" if scenario.get("training", False) else "0"

    results_path = run_dir / "results.json"
    if results_path.exists():
        results_path.unlink()

    payload, error = None, None
    t0 = time.perf_counter()
    try:
        runpy.run_path(str(run_dir / "main.py"), run_name="__main__")
    except BaseException:                      # noqa: BLE001 - raportujemy wszystko
        error = traceback.format_exc()
    wall_ms = (time.perf_counter() - t0) * 1000.0

    if results_path.exists():
        payload = json.loads(results_path.read_text(encoding="utf-8"))

    meta = {
        "source": "main.py",
        "runner": "python",
        "scenario": scenario.get("name", Path(args.scenario).stem),
        "seed": scenario.get("seed"),
        "frame_ms": sim.frame_ms,
        "training": bool(scenario.get("training", False)),
        "launcher": bool(scenario.get("launcher", True)),
        "frames": sim.frame,
        "virtual_ms": round(sim.t * 1000.0, 3),
        "wall_ms": round(wall_ms, 1),
        "trials_seen": sim.current_trial + 1,
        "trial_starts": sim.trial_starts,
        "stop_onsets": sim.stop_onsets,
        "rng_draws_total": sim.rng.draws,
        "rng_draws_at_clear": sim.rng_draws_at_clear,
        "rng_window_sizes": sim.rng_window_sizes,
        "rng_state_final": sim.rng.state,
        "reseed_per_trial": sim.reseed_per_trial,
        "window": sim.trace_meta.get("window"),
        "stims": sim.trace_meta.get("stims", {}),
        "input_log": sim.log,
        "edge_log": sim.edge_log,
        "mouse_clicks": sim.mouse_click_count,
        "error": error,
    }

    (out_dir / "result_py.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    (out_dir / "meta_py.json").write_text(
        json.dumps(meta, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    if sim.record_trace:
        (out_dir / "trace_py.json").write_text(
            json.dumps(sim.trace, separators=(",", ":")), encoding="utf-8")

    print(json.dumps({
        "ok": error is None,
        "error": (error or "").strip().splitlines()[-1] if error else None,
        "frames": sim.frame,
        "trials": sim.current_trial + 1,
        "poprawne": (payload or {}).get("ilosc_poprawnych_nacisniec"),
        "bledne": (payload or {}).get("ilosc_blednych_nacisniec"),
        "sredni_rt_ms": (payload or {}).get("sredni_czas_reakcji"),
        "wall_ms": meta["wall_ms"],
    }, ensure_ascii=False))
    return 0 if error is None else 1


if __name__ == "__main__":
    raise SystemExit(main())

