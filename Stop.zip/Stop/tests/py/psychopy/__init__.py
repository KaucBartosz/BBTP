# -*- coding: utf-8 -*-
"""Atrapa pakietu `psychopy` (HPM) - tylko API uzywane przez main.py testu Stop.

Nie jest to emulator renderowania; jest to *kontrakt* zachowan testu:
zegar wirtualny + bodźce + wejście zdarzeniowe.  Używane wyłącznie
przez testy parzystości w tests/.
"""
from ._sim import Sim, sim, LCG  # noqa: F401
from . import core, visual, event  # noqa: F401,E402

__all__ = ["Sim", "sim", "LCG", "core", "visual", "event"]
