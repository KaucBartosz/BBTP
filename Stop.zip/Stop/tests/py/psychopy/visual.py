# -*- coding: utf-8 -*-
"""Atrapa `psychopy.visual` - okno i bodźce.

Bodźce nie sa renderowane; zapisujemy ich stan (pozycja/opuszkosc) do trace,
zeby mozna bylo porownac klatka po klatce z wersja JS.
"""
from ._sim import sim
from . import core


class _Stim:
    kind = "stim"

    def __init__(self, win, name, pos, size, opacity, units, **cfg):
        self.win = win
        self.name = name
        self.sim_name = name
        self.pos = tuple(pos)
        self.size = tuple(size) if size is not None else None
        self.opacity = 1.0 if opacity is None else opacity
        self.units = units
        self.cfg = dict(cfg)
        self.cfg.update({
            "pos": [float(self.pos[0]), float(self.pos[1])],
            "size": None if self.size is None else [float(self.size[0]), float(self.size[1])],
            "opacity": self.opacity,
            "units": units,
        })
        s = sim()
        s.stims.append(self)
        s.trace_meta.setdefault("stims", {})[name] = self.cfg

    def draw(self):
        return None

    def hide(self):
        return None

    def __repr__(self):
        return f"<{type(self).__name__} {self.name} pos={self.pos} op={self.opacity}>"


class TextStim(_Stim):
    kind = "text"

    def __init__(self, win, text="", color="white", height=None, pos=(0, 0),
                 units=None, wrapWidth=None, alignText=None, font=None, **cfg):
        super().__init__(win, "text", pos, (0, 0), cfg.pop("opacity", None), units,
                         text=text, color=color, height=height, wrapWidth=wrapWidth,
                         alignText=alignText, font=font, **cfg)


class ImageStim(_Stim):
    kind = "image"

    def __init__(self, win, image=None, size=None, pos=(0, 0), units=None,
                 interpolate=None, **cfg):
        name = "?"
        if image is not None:
            name = str(image).replace("\\", "/").rsplit("/", 1)[-1].rsplit(".", 1)[0]
        super().__init__(win, name, pos, size, cfg.pop("opacity", None), units,
                         image=str(image) if image is not None else None, **cfg)


class Window:
    def __init__(self, fullscr=False, units="pix", color=(0, 0, 0), allowGUI=True,
                 size=(1280, 720), **cfg):
        self.fullscr = fullscr
        self.units = units
        self.color = color
        self.allowGUI = allowGUI
        self.size = size
        self.frames = 0
        s = sim()
        s.win = self
        s.trace_meta["window"] = {
            "fullscr": bool(fullscr),
            "units": units,
            "color": list(color) if isinstance(color, (list, tuple)) else color,
            "backgroundImage": None,
        }

    def flip(self):
        """Prezentacja klatki: zapis trace, a potem zegar do przodu.

        UWAGA: wejscie jest dostarczane leniwie (przy odczycie klawiatury/myszy),
        a nie tutaj - dzieki temu oba symulatory (Python i JS) czytaja wejscie
        w tej samej chwili co `core.getTime()` w danej iteracji petli.
        """
        s = sim()
        s.snapshot()
        s.advance()
        self.frames += 1

    def callOnFlip(self, func, *args, **kwargs):
        return None

    def getActualFrameRate(self):
        return 1000.0 / s_fps()

    def close(self):
        self.closed = True

    def setSize(self, *args, **kwargs):
        return None


def s_fps():
    return 1000.0 / sim().frame_ms
