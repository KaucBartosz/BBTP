# -*- coding: utf-8 -*-
"""Atrapa `psychopy.core` - zegar i zdarzenia systemowe."""
from ._sim import sim


class Clock:
    def __init__(self, *args, **kwargs):
        self._t0 = sim().t

    def reset(self):
        self._t0 = sim().t

    def getTime(self):
        return sim().t - self._t0

    def add(self, dt):
        sim().t += dt

    def __repr__(self):
        return f"<Clock {self.getTime():.4f}>"


def getTime():
    """Aktualny czas wirtualny (w sekundach od startu symulacji)."""
    return sim().t


def quit():
    return None


def wait(*args, **kwargs):
    return None


class Stream:
    def __init__(self, *args, **kwargs):
        self._events = []

    def sendMessage(self, msg):
        self._events.append(msg)

    @property
    def lastMessage(self):
        return self._events[-1] if self._events else ""
