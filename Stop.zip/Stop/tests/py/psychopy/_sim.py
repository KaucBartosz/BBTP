# -*- coding: utf-8 -*-
"""
Wirtualny symulator PsychoPy dla testow parzystości (JS <-> Python).

Jedna instancja SIM jest współdzielona przez atrapy modułów `psychopy.visual`,
`psychopy.core` i `psychopy.event`.  Dzięki temu test uruchamia *oryginalny*
`main.py` bez żadnej modyfikacji, a my kontrolujemy:

  * zegar wirtualny (przesuwa się TYLKO przy `win.flip()`),
  * generator liczb pseudolosowych (LCG, identyczny w JS),
  * kolejność i czas zdarzeń wejściowych (klawiatura / mysz / dotyk),
  * rejestrowanie stanu ekranu klatka po klatce (trace).

Protokół (identyczny w tests/js/sim.mjs):
  - czas startuje w 0 i rośnie o `frame_ms` przy każdym flipie/renderze,
  - LCG: state = (state * 1664525 + 1013904223) mod 2**32,
          random() = state / 2**32   (po aktualizacji),
  - randint(a, b) = a + floor(random() * (b - a + 1)),
  - zdarzenia sa dostarczane leniwie: przy kazdym odczycie wejscia
    (`Mouse.getPressed`, `event.getKeys`, `Mouse.isPressedIn`) flushujemy
    wszystkie akcje scenariusza, ktore (a) maja `trial == biezaca proba`
    i (b) czas `trial_start + at_ms <= teraz`.
"""
from __future__ import annotations

import json
import math
import os
from pathlib import Path

FRAME_HISTORY_DECIMALS = 9


# --------------------------------------------------------------------------- #
#  Generator liczb pseudolosowych (identyczny z tests/js/sim.mjs)
# --------------------------------------------------------------------------- #
class LCG:
    def __init__(self, seed: int = 1):
        self.state = int(seed) & 0xFFFFFFFF
        self.draws = 0           # liczba wywolan - dowod zgodnosci strumienia

    def random(self) -> float:
        self.draws += 1
        self.state = (self.state * 1664525 + 1013904223) & 0xFFFFFFFF
        return self.state / 4294967296.0

    def randint(self, a: int, b: int) -> int:
        """Jest to odpowiednik *Python* random.randint (a, b) wlaczonego zakresu."""
        return a + int(self.random() * (b - a + 1))

    def reseed_window(self, seed_value: int, trial: int, k: int) -> None:
        """Ustawia stan na `seed + trial` przesuniety o `k` krokow.

        Uzywane w trybie `reseed_per_trial`: `k` to liczba losowan, ktora
        wypadla w oknie MIEDZY dwoma wywolaniami `event.clearEvents()`,
        czyli dokladnie losowania konfigurujace probu (`k` jest wykrywane
        dynamicznie, wiec nie zalezy od tego ile ich jest w kodzie zrodlowym).
        """
        s = (int(seed_value) + int(trial)) & 0xFFFFFFFF
        for _ in range(int(k)):
            s = (s * 1664525 + 1013904223) & 0xFFFFFFFF
        self.state = s


# --------------------------------------------------------------------------- #
#  Zdarzenia wejsciowe
# --------------------------------------------------------------------------- #
class KeyEvent:
    __slots__ = ("name", "t_down", "t_up", "consumed_down", "consumed_up")

    def __init__(self, name: str, t_down: float, t_up: float):
        self.name = name
        self.t_down = t_down
        self.t_up = t_up
        self.consumed_down = False
        self.consumed_up = False


class Sim:
    """Stan symulacji: zegar, RNG, wejscie, trace."""

    def __init__(self, scenario: dict):
        self.scenario = scenario
        self.frame_ms: float = float(scenario.get("frame_ms", 1000.0 / 60.0))
        self.t: float = 0.0
        self.frame: int = 0
        self.seed_value: int = int(scenario.get("seed", 1))
        self.rng = LCG(self.seed_value)
        # `reseed_per_trial`: restart strumienia na kazdej prezentowanej klatce
        # (patrz `snapshot()`), dzieki czemu proby sa niezalezne - roznica w
        # liczbie losowan w probie N nie uniewaznia pozniejszych prob.
        self.reseed_per_trial: bool = scenario.get("reseed_per_trial") is True
        # liczba losowan konfiguracyjnych jednej proby (`stopOnset`, `stop_x`,
        # 2x strona, 2x pozycja dystraktorow, `distraction_speed`)
        self.setup_draws: int = int(scenario.get("setup_draws", 7))
        self.rng_at_trial_start: int = 0
        # skumulowana liczba losowan w chwili kazdego `event.clearEvents()`;
        # roznica dwoch kolejnych wartosci = ile losowan "kosztowala" proba
        self.rng_draws_at_clear: list = []
        self.rng_window_sizes: list = []
        self.rng_draws_at_last_reseed: int = 0
        self.setup_draws_seen: set = set()
        self.record_trace: bool = bool(scenario.get("record_trace", True))
        self.trace_stim_names = list(
            scenario.get("trace_stims", ["tlo", "car", "stop", "jelonek", "drzewo"])
        )

        # akcje wejsciowe z scenariusza
        self.actions = sorted(
            scenario.get("actions", []),
            key=lambda a: (int(a.get("trial", -1)), float(a.get("at_ms", 0))),
        )
        self.action_cursor = 0

        # proba / czas
        self.current_trial: int = -1
        self.trial_start_time: float = 0.0
        self.trial_starts: list = []           # [(trial, time)]
        self.trial_start_index: dict = {}
        self.win = None

        # znak STOP: kiedy stal sie widoczny w biezacej probie
        self.stop_stim_name = str(scenario.get("stop_stim", "stop"))
        self.stop_visible = False
        self.stop_visible_at: float = None
        self.stop_onsets: list = []            # [(trial, czas pojawienia sie)]

        # bufor klawiatury
        self.key_events: list = []             # aktywne, niekonsumowane
        self.clock_marks: dict = {}            # id(Clock) -> ostatni reset

        # mysz
        self.mouse_pos = [0.0, 0.0]
        self.mouse_buttons = [0, 0, 0]
        self.mouse_release_at: float = None
        self.mouse_pressed_at: float = None
        self.mouse_click_count = 0

        # bodźce (rejestrowane globalnie)
        self.stims: list = []

        # trace
        self.trace: list = []
        self.trace_meta: dict = {}

        # log
        self.log: list = []

        # decyzje `Mouse.isPressedIn()` podmiescione w poblizu krawedzi bodzca
        # (pelny log bylby wielki - wywolywanie co klatke)
        self.edge_log: list = []

    # ------------------------------------------------------------------ #
    #  zegar
    # ------------------------------------------------------------------ #
    def advance(self) -> None:
        self.t += self.frame_ms / 1000.0
        self.frame += 1

    def snapshot(self) -> None:
        """Zapisuje stan bodzcow w chwili prezentacji klatki."""
        self.watch()
        self.apply_reseed()
        if not self.record_trace:
            return
        row = {"f": self.frame, "t": round(self.t, FRAME_HISTORY_DECIMALS),
               "tr": self.current_trial}
        for stim in self.stims:
            if stim.sim_name in self.trace_stim_names:
                row[stim.sim_name] = [
                    round(stim.pos[0], 6), round(stim.pos[1], 6),
                    round(float(stim.opacity), 4),
                ]
        self.trace.append(row)

    def apply_reseed(self) -> None:
        """Restart strumienia RNG na koncu klatki proby.

        Po kazdej klatce proby N nastepne losowania to konfiguracja proby
        N+1, wiec stan ustawiamy na `seed + (N + 1)` przesuniety o
        `setup_draws` krokow.  Dzieki temu `stopOnset`, pozycje i predkosc
        dystraktorow proby N+1 zaleza wylacznie od N, a roznica w liczbie
        losowan w probie N nie uniewaznia prob N+1, N+2, ...

        Wywolywane z `snapshot()`, czyli z kazdego `win.flip()`.  W `stop.js`
        odpowiednikiem jest `Scheduler.Event.FLIP_REPEAT` + `render()`; tamze
        brakuje klatki koncowej rutyny, wiec symulator JS wywoluje restart
        takze w `sealFrame()` (patrz tests/js/sim.mjs).
        """
        if not self.reseed_per_trial:
            return
        self.rng_draws_at_last_reseed = self.rng.draws
        self.rng.reseed_window(
            self.seed_value, self.current_trial + 1, self.setup_draws)

    def watch(self) -> None:
        """Wykrywa moment pojawienia sie znaku STOP (niezaleznie od kadrowania
        petli: raz na klatke, w chwili prezentacji)."""
        # identycznie jak w tests/js/sim.mjs: przed pierwsza proba (ekran
        # powitalny) znaku STOP nie szukamy.
        if self.current_trial < 0:
            return
        if self.stop_visible:
            return
        for stim in self.stims:
            if stim.sim_name == self.stop_stim_name:
                if float(stim.opacity) > 0.0:
                    self.stop_visible = True
                    self.stop_visible_at = self.t
                    self.stop_onsets.append([self.current_trial, round(self.t, 9)])
                return

    # ------------------------------------------------------------------ #
    #  proba
    # ------------------------------------------------------------------ #
    def begin_trial(self) -> None:
        """Wywolywane przez `event.clearEvents()` na poczatku kazdej proby."""
        self.current_trial += 1
        self.trial_start_time = self.t
        self.trial_starts.append([self.current_trial, round(self.t, 9)])
        self.trial_start_index[self.current_trial] = self.t
        self.stop_visible = False
        self.stop_visible_at = None
        # event.clearEvents() czysci tez bufor klawiatury
        self.key_events = []
        self.rng_at_trial_start = self.rng.draws
        if self.reseed_per_trial:
            # `k` = dokladnie losowania konfiguracyjne TEJ proby: od
            # ostatniego restartu strumienia (koniec poprzedniej proby) do
            # `clearEvents()`.  Sprawdzamy, czy jest ich dokladnie
            # `setup_draws` - inaczej restart w `apply_reseed()` bylby
            # przesuniety.
            k = self.rng.draws - self.rng_draws_at_last_reseed
            self.rng_window_sizes.append(k)
            self.setup_draws_seen.add(k)
        self.rng_draws_at_clear.append(self.rng.draws)

    # ------------------------------------------------------------------ #
    #  wejscie
    # ------------------------------------------------------------------ #
    def _action_time(self, act: dict) -> float:
        """Kiedy akcja ma byc dostarczona (czas absolutny w symulacji)."""
        if "after_stop_ms" in act or "after_stop_frames" in act:
            delta = float(act.get("after_stop_ms", 0.0)) + \
                float(act.get("after_stop_frames", 0)) * self.frame_ms
            base = self.stop_visible_at
            if base is None:
                return float("inf")
            return base + delta / 1000.0
        base = self.trial_start_index.get(self.current_trial, 0.0)
        return base + float(act.get("at_ms", 0)) / 1000.0

    def flush(self) -> None:
        """Dostarcza wszystkie akcje scenariusza nalezace do biezacej proby."""
        # puszczanie przycisku myszy (po czasie trzymania)
        if self.mouse_release_at is not None and self.t >= self.mouse_release_at:
            self.mouse_buttons = [0, 0, 0]
            self.mouse_release_at = None

        i = 0
        while i < len(self.actions):
            act = self.actions[i]
            trial = int(act.get("trial", -1))
            if trial > self.current_trial:
                break                      # akcja z przyszlej proby
            if trial != self.current_trial:
                i += 1
                continue                  # akcja z przeszlej, niewykonana proby
            when = self._action_time(act)
            if self.t + 1e-12 < when:
                i += 1
                continue                  # jeszcze za wczesnie
            del self.actions[i]            # akcja wykonana
            self._deliver(act, self.t)

    def stim_pos(self, name: str):
        for stim in self.stims:
            if stim.sim_name == name:
                return [float(stim.pos[0]), float(stim.pos[1])]
        raise KeyError(f"brak bodzca {name!r}")

    def _deliver(self, act: dict, now: float) -> None:
        kind = act.get("type")
        if kind == "key":
            hold = float(act.get("hold_ms", 40)) / 1000.0
            self.key_events.append(KeyEvent(act.get("key", "space"), now, now + hold))
            self.log.append({"t": round(now, 6), "ev": "key", "name": act.get("key", "space")})
        elif kind == "mouse_move":
            self.mouse_pos = self._resolve_pos(act)
            self.log.append({"t": round(now, 6), "ev": "mouse_move", "pos": list(self.mouse_pos)})
        elif kind == "click":
            if "pos" in act or "target" in act:
                self.mouse_pos = self._resolve_pos(act)
            btn = int(act.get("button", 0))
            self.mouse_buttons = [0, 0, 0]
            self.mouse_buttons[btn] = 1
            self.mouse_pressed_at = now
            self.mouse_click_count += 1
            hold = float(act.get("hold_ms", 40)) / 1000.0
            self.mouse_release_at = now + hold
            self.log.append({"t": round(now, 6), "ev": "click", "pos": list(self.mouse_pos)})
        elif kind == "touch":
            # Python nie ma obslugi dotyku - zapisujemy tylko do logu,
            # zeby raport pokazywal ze zdarzenie zignorowano.
            self.log.append({"t": round(now, 6), "ev": "touch_ignored",
                             "pos": self._resolve_pos(act)})
        else:
            raise ValueError(f"nieznany typ akcji: {kind!r}")

    def _resolve_pos(self, act: dict):
        if "target" in act:
            base = self.stim_pos(act["target"])
            off = act.get("target_offset", [0.0, 0.0])
            return [base[0] + float(off[0]), base[1] + float(off[1])]
        return [float(act["pos"][0]), float(act["pos"][1])]

    def take_keys(self, key_list=None) -> list:
        """Zwraca nacisniete klawisze (zdarzenie 'w dol'), jak robi to PsychoPy."""
        self.flush()
        out = []
        for ev in self.key_events:
            if ev.consumed_down:
                continue
            if key_list and ev.name not in key_list:
                continue
            out.append({"name": ev.name, "rt": ev.t_down})
            ev.consumed_down = True
        return out

    def keys_released(self, key_list=None) -> list:
        """Klawisze zwolnione od 'down' - semantyka PsychoJS core.Keyboard."""
        self.flush()
        out = []
        for ev in self.key_events:
            if ev.consumed_up or ev.t_up > self.t + 1e-12:
                continue
            if key_list and ev.name not in key_list:
                continue
            out.append({"name": ev.name, "rt": ev.t_down, "duration": ev.t_up - ev.t_down})
            ev.consumed_up = True
        return out

    def clear_keys(self) -> None:
        self.flush()
        self.key_events = []

    # ------------------------------------------------------------------ #
    #  mysz
    # ------------------------------------------------------------------ #
    def get_mouse(self):
        self.flush()
        return self.mouse_pos, list(self.mouse_buttons)


SIM: Sim = None  # wypelniane przez run_main.py


def sim() -> Sim:
    global SIM
    if SIM is None:
        raise RuntimeError("SIM nie zostalo zainicjalizowane")
    return SIM
