# -*- coding: utf-8 -*-
"""Atrapa `psychopy.event` - klawiatura i mysz na zegarze wirtualnym."""
from ._sim import sim

MAX_WAIT_FRAMES = 100000

# Prog logowania decyzji `isPressedIn` w `sim.edge_log` (w jednostkach okna).
# 1e-6 jednostki okna = 7.2e-4 px przy oknie 1280x720 - wystarczajaco duzo,
# by zlapac przypadki "klikniecie dokladnie na krawedzi", i zbyt wasko, zeby
# log pozostal maly.  Ta sama wartosc po drugiej stronie (psychojs_stub.mjs).
EDGE_EPS_UNITS = 1e-6


def _matches(names, key_list):
    if not key_list:
        return list(names)
    return [n for n in names if n in key_list]


def getKeys(keyList=None, modifiers=False, timeStamped=False):
    evs = sim().take_keys(keyList)
    if timeStamped:
        return [(e["name"], e["rt"]) for e in evs]
    return [e["name"] for e in evs]


def waitKeys(keyList=None, modifiers=False, timeStamped=False, clear=True):
    """Blokuje (a w symulacji: klatka po klatce) az do wcisniecia klawisza."""
    s = sim()
    for _ in range(MAX_WAIT_FRAMES):
        evs = s.take_keys(keyList)
        if evs:
            if timeStamped:
                return [(e["name"], e["rt"]) for e in evs]
            return [e["name"] for e in evs]
        s.win.flip()
    raise RuntimeError("waitKeys: przekroczono limit klatek")


def clearEvents(eventType=None):
    """Wywolywane raz na probe w `main.py` - sluzyrownie jako wyznacznik
    poczatku proby (tak samo jak `eventManager.clearEvents()` w wersji JS)
    oraz czysci bufor klawiatury (tak jak robi to PsychoPy)."""
    s = sim()
    s.flush()
    s.begin_trial()
    s.key_events = []


def setMouseVisible(visible=True):
    return None


class Mouse:
    def __init__(self, win=None, visible=True):
        self.win = win
        self.visible = visible
        self.pos = [0.0, 0.0]
        self.clicks = []

    # --- pozycja / stan -------------------------------------------------- #
    def getPos(self):
        pos, _ = sim().get_mouse()
        self.pos = list(pos)
        return list(pos)

    def getPressed(self):
        _, buttons = sim().get_mouse()
        return list(buttons)

    def getPosAndVel(self):
        return self.getPos(), (0, 0)

    def setPos(self, newPos):
        s = sim()
        s.flush()
        s.mouse_pos = [float(newPos[0]), float(newPos[1])]

    def setVisible(self, visible=True):
        self.visible = visible

    def isPressedIn(self, stim):
        """Psychopy: prawda, gdy przycisk jest wcisniety i kursor wprostrod bodzca."""
        s = sim()
        pos, buttons = s.get_mouse()
        if stim is None:
            return False
        sx, sy = float(stim.pos[0]), float(stim.pos[1])
        size = getattr(stim, "size", None)
        if not size or size[0] is None or size[1] is None:
            return False
        w, h = float(size[0]) / 2.0, float(size[1]) / 2.0
        result = any(buttons) and abs(pos[0] - sx) <= w and abs(pos[1] - sy) <= h
        # --- pomiar: marginesy decyzji wobec krawedzi (dokladnie, bez zaokraglania)
        # te same cztery marginesy co w wersji JS, w jednostkach okna, w tej samej
        # kolejnosci [lewa, prawa, dolna, gorna]; >0 = wewnatrz, 0 = dokladnie
        # na krawedzi, <0 = poza bodzcem.  Uklad jest taki sam jak w JS:
        # (0,0) w srodku okna, y w gore.
        margins = [
            w - (sx - pos[0]),      # lewa
            w - (pos[0] - sx),      # prawa
            h - (sy - pos[1]),      # dolna
            h - (pos[1] - sy),      # gorna
        ]
        if min(margins) <= EDGE_EPS_UNITS:
            s.edge_log.append({
                "t": s.t,
                "tr": s.current_trial,
                "stim": getattr(stim, "sim_name", None),
                "pressed": [int(b) for b in buttons],
                "pos": [pos[0], pos[1]],
                "stim_pos": [sx, sy],
                "size": [float(size[0]), float(size[1])],
                "margins": margins,
                "result": bool(result),
            })
        return bool(result)

    def clicked(self, buttons=None):
        s = sim()
        s.flush()
        return [s.mouse_click_count] * 3
