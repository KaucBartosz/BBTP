// -*- coding: utf-8 -*-
/**
 * Definicje scenariuszy testowych.
 *
 * Ten sam plik JSON musi byc zapisany RAZ i uzyty przez OBA runnery
 * (Node -> `stop.js`, Python -> `main.py`).  Dlatego scenariusze sa
 * generowane skryptem, a nie recznie - gwarantuje to bajtowa identycznosc
 * pliku dla obu stron.
 *
 * Akcje (scenariusza):
 *   type      : "key" | "click" | "touch" | "mouse_move"
 *   trial     : numer proby (0-based); -1 = ekran powitalny
 *   at_ms     : czas od poczatku proby (ms)
 *   after_stop_ms / after_stop_frames : czas od pojawienia sie znaku STOP
 *   key       : "space" | "escape" | ...
 *   target    : nazwa bodzca ("car", "stop") - klik w jego srodek
 *   pos       : [x, y] w jednostkach okna (units='height')
 *   hold_ms   : jak dlugo klawisz/przycisk jest wcisniety
 */
import { mkdirSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const SCEN_DIR = path.join(HERE, 'scenarios');

const FRAME_60 = 1000 / 60;
const SEED = 20260927;

/** skrot: proba startuje od t=0, znak STOP po `after_stop_ms` */
const key = (trial, after_stop_ms, k = 'space', extra = {}) =>
  ({ trial, type: 'key', key: k, after_stop_ms, ...extra });
const keyAt = (trial, at_ms, k = 'space', extra = {}) =>
  ({ trial, type: 'key', key: k, at_ms, ...extra });
const click = (trial, after_stop_ms, target, extra = {}) =>
  ({ trial, type: 'click', target, after_stop_ms, ...extra });
const touch = (trial, after_stop_ms, target, extra = {}) =>
  ({ trial, type: 'touch', target, after_stop_ms, ...extra });

const WELCOME = { trial: -1, type: 'key', key: 'space', at_ms: 150, hold_ms: 90 };

export const SCENARIOS = [
  {
    name: 'smoke',
    description: 'Test przeszkodowy: 50 prob, 3 poprawne reakcje + 1 falstart.',
    seed: SEED,
    frame_ms: FRAME_60,
    record_trace: true,
    launcher: true,
    training: false,
    actions: [
      WELCOME,
      key(0, 250),
      click(1, 300, 'car', { hold_ms: 45 }),
      keyAt(2, 400),                      // falstart - przed znakiem STOP
      click(3, 350, 'stop'),
    ],
  },

  {
    name: 'mixed',
    description: 'Kazda 5. proba reaguje (klik / spacja / dotyk / falstart / brak).',
    seed: SEED,
    frame_ms: FRAME_60,
    record_trace: true,
    launcher: true,
    training: false,
    actions: [
      WELCOME,
      key(0, 220),
      click(1, 280, 'car'),
      key(2, 400),
      click(3, 260, 'stop'),
      keyAt(4, 500),                      // falstart
      // 5: brak reakcji (timeout 5 s od znaku)
      click(6, 900, 'car'),
      touch(7, 300, 'car'),               // dotyk - tylko JS
      key(8, 180),
      keyAt(9, 300),                      // falstart
      click(10, 500, 'car'),
      key(11, 1000),
      click(12, 240, 'stop'),
      // 13, 14: brak reakcji
      key(15, 330),
      click(16, 270, 'car'),
    ],
  },

  {
    name: 'training',
    description: 'NOUS_TRAINING=1: Python robi 5 prob, JS zawsze 50.',
    seed: SEED,
    frame_ms: FRAME_60,
    record_trace: true,
    launcher: true,
    training: true,
    actions: [
      WELCOME,
      key(0, 250),
      click(1, 300, 'car'),
      key(2, 400),
      click(3, 350, 'stop'),
      key(4, 500),
    ],
  },

  {
    name: 'welcome_key_y',
    description: 'Ekran powitalny: klawisz `y` zamiast spacji (oba: brak reakcji).',
    seed: SEED,
    frame_ms: FRAME_60,
    record_trace: true,
    launcher: true,
    training: false,
    actions: [
      { trial: -1, type: 'key', key: 'y', at_ms: 150, hold_ms: 60 },
      { trial: -1, type: 'key', key: 'space', at_ms: 900, hold_ms: 60 },
      key(0, 250),
    ],
  },

  {
    name: 'welcome_very_early',
    description: 'SPACJA 5 ms po starcie - JS gubi klawisz (key_resp.start() dopiero po 1. flipie).',
    seed: SEED,
    frame_ms: FRAME_60,
    record_trace: true,
    launcher: true,
    training: false,
    actions: [
      { trial: -1, type: 'key', key: 'space', at_ms: 5, hold_ms: 20 },
      { trial: -1, type: 'key', key: 'space', at_ms: 400, hold_ms: 20 },
      key(0, 250),
    ],
  },

  {
    name: 'held_space',
    description: 'SPACJA trzymana przez 1500 ms od chwili pojawienia sie znaku (KEY_DOWN przed KEY_UP).',
    seed: SEED,
    frame_ms: FRAME_60,
    record_trace: true,
    launcher: true,
    training: false,
    actions: [
      WELCOME,
      key(0, 200, 'space', { hold_ms: 1500 }),
      key(1, 250, 'space', { hold_ms: 1500 }),
    ],
  },

  {
    name: 'touch',
    description: 'Dotyk w srodku auta (JS) - Python nie ma obslugi dotyku.',
    seed: SEED,
    frame_ms: FRAME_60,
    record_trace: true,
    launcher: true,
    training: false,
    actions: [
      WELCOME,
      touch(0, 300, 'car'),
      touch(1, 300, 'stop'),
      touch(2, 300, 'car'),
    ],
  },

  {
    name: 'esc_mid',
    description: 'ESC w trakcie proby 3.',
    seed: SEED,
    frame_ms: FRAME_60,
    record_trace: true,
    launcher: true,
    training: false,
    actions: [
      WELCOME,
      key(0, 250),
      key(1, 300),
      key(2, 300),
      { trial: 3, type: 'key', key: 'escape', at_ms: 600 },
    ],
  },

  {
    name: 'esc_welcome',
    description: 'ESC na ekranie powitalnym.',
    seed: SEED,
    frame_ms: FRAME_60,
    record_trace: true,
    launcher: true,
    training: false,
    actions: [
      { trial: -1, type: 'key', key: 'escape', at_ms: 300, hold_ms: 40 },
    ],
  },

  {
    name: 'esc_and_space',
    description: 'ESC i SPACJA w tej samej klatce po pojawieniu sie znaku - kto wygra?',
    seed: SEED,
    frame_ms: FRAME_60,
    record_trace: true,
    launcher: true,
    training: false,
    actions: [
      WELCOME,
      { trial: 0, type: 'key', key: 'escape', after_stop_ms: 250 },
      key(0, 250),
    ],
  },

  {
    name: 'slow_reported_60',
    description: 'Monitor 40 Hz (frame_ms=25), ale JS i tak liczy ruch z `frameDur = 1/60`.',
    seed: SEED,
    frame_ms: 25,
    record_trace: true,
    launcher: true,
    training: false,
    actions: [
      WELCOME,
      key(0, 250),
      key(1, 300),
    ],
  },

  {
    name: 'no_response',
    description: 'Badanie bez reakcji - sprawdza, ile trwa proba i co trafia do statystyk.',
    seed: SEED,
    frame_ms: FRAME_60,
    record_trace: true,
    launcher: true,
    training: false,
    actions: [WELCOME],
  },

  {
    name: 'rounding_half',
    description: 'Czas reakcji dokladnie 250.5 ms - test round() (Python bankers) vs Math.round (half-up).',
    seed: SEED,
    frame_ms: FRAME_60,
    record_trace: true,
    launcher: true,
    training: false,
    actions: [
      WELCOME,
      key(0, 250.5),
    ],
  },

  {
    name: 'no_launcher',
    description: 'Bez `window.electronTest` - tryb przegladarki: JS nie wysyla paczki.',
    seed: SEED,
    frame_ms: FRAME_60,
    record_trace: true,
    launcher: false,
    training: false,
    actions: [
      WELCOME,
      key(0, 250),
    ],
  },

  {
    name: 'edge_click',
    description: 'Klik dokladnie na dolnej krawedzi znaku STOP: psychopy `<=` (trafienie) vs PIXI `<` (pudlo).',
    seed: SEED,
    frame_ms: FRAME_60,
    record_trace: true,
    launcher: true,
    training: false,
    actions: [
      WELCOME,
      // znak STOP ma rozmiar 0.2x0.2 -> dolna krawedz = pos[1] - 0.1
      { trial: 0, type: 'click', target: 'stop', target_offset: [0, -0.1], after_stop_ms: 300 },
      // 0.0001 nad krawedzia - obie wersje trafiaja
      { trial: 1, type: 'click', target: 'stop', target_offset: [0, -0.0999], after_stop_ms: 300 },
      // dokladnie na prawej krawedzi
      { trial: 2, type: 'click', target: 'stop', target_offset: [0.1, 0], after_stop_ms: 300 },
    ],
  },

  // ===================================================================== //
  //  Scenariusze "izolowane" (`reseed_per_trial`)
  //
  //  W trybie normalnym jedna roznica w liczbie losowan uniewaznia wszystkie
  //  pozniejsze proby (patrz `iso_*` vs scenariusze bez prefiksu).  Tutaj
  //  symulatory PRZESAWAJĄ stan LCG na `seed + numer_proby` na poczatku kazdej
  //  proby, dzieki czemu kazda proba jest niezalezna od poprzednich i mozna
  //  porownywac logike pojedynczej proby czysto.
  // ===================================================================== //
  {
    name: 'iso_mixed',
    description: '[izolowane proby] kazda 4. proba reaguje inaczej: spacja / klik w auto / klik w znak / falstart / brak / dotyk.',
    seed: SEED,
    frame_ms: FRAME_60,
    record_trace: true,
    launcher: true,
    training: false,
    reseed_per_trial: true,
    actions: [
      WELCOME,
      key(0, 250),                       // spacja po znaku
      click(1, 300, 'car'),              // klik w auto
      click(2, 260, 'stop'),             // klik w znak STOP
      keyAt(3, 400),                     // falstart (przed znakiem)
      keyAt(4, 60),                      // bardzo wczesny falstart
      key(5, 2000),                      // bardzo pozna reakcja
      key(6, 4999),                      // tuz przed limitem 5 s
      touch(7, 300, 'car'),              // dotyk (tylko JS)
      click(8, 500, 'car', { pos: [0.25, -0.9] }),  // klik poza bodzcem
      key(9, 250.5),                     // RT dokladnie 250.5 ms
      click(10, 0, 'car'),               // klik w tej samej klatce co znak STOP
      // 11, 12: brak reakcji (timeout)
    ],
  },

  {
    name: 'iso_edge_click',
    description: '[izolowane proby] klik dokladnie na krawedzi bodzow - `isPressedIn` psychopy (`<=`) vs `Rectangle.contains` PIXI (`<`).',
    seed: SEED,
    frame_ms: FRAME_60,
    record_trace: true,
    launcher: true,
    training: false,
    reseed_per_trial: true,
    actions: [
      WELCOME,
      { trial: 0, type: 'click', target: 'stop', target_offset: [0, -0.1], after_stop_ms: 300 },
      { trial: 1, type: 'click', target: 'stop', target_offset: [0, 0.1], after_stop_ms: 300 },
      { trial: 2, type: 'click', target: 'stop', target_offset: [0.1, 0], after_stop_ms: 300 },
      { trial: 3, type: 'click', target: 'stop', target_offset: [-0.1, 0], after_stop_ms: 300 },
      { trial: 4, type: 'click', target: 'stop', target_offset: [0.1, 0.1], after_stop_ms: 300 },
      { trial: 5, type: 'click', target: 'stop', target_offset: [0, -0.09999], after_stop_ms: 300 },
      { trial: 6, type: 'click', target: 'stop', target_offset: [0.09999, 0], after_stop_ms: 300 },
    ],
  },

  {
    name: 'iso_touch',
    description: '[izolowane proby] dotyk w aucie i w znaku - `main.py` nie obsluguje dotyku w ogole.',
    seed: SEED,
    frame_ms: FRAME_60,
    record_trace: true,
    launcher: true,
    training: false,
    reseed_per_trial: true,
    actions: [
      WELCOME,
      touch(0, 300, 'car'),
      touch(1, 300, 'stop'),
      touch(2, 300, 'stop', { target_offset: [0, -0.1] }),   // na krawedzi
      touch(3, 300, 'car', { target_offset: [0.4, 0.4] }),  // poza bodzcem
      touch(4, 300, 'car', { hold_ms: 300 }),                // dlugi dotyk
      // 5: dotyk PRZED pojawieniem sie znaku (falstart)
      touch(5, 0, 'car', { at_ms: 400 }),
    ],
  },

  {
    name: 'iso_rounding',
    description: '[izolowane proby] RT na polowach milisekundy - `round()` w Pythonie (bankers) vs `Math.round()` w JS (half-up).',
    seed: SEED,
    frame_ms: FRAME_60,
    record_trace: true,
    launcher: true,
    training: false,
    reseed_per_trial: true,
    actions: [
      WELCOME,
      key(0, 250.5),
      key(1, 750.5),
      key(2, 1000.5),
      key(3, 1500.5),
      key(4, 2000.5),
      key(5, 3500.5),
    ],
  },

  {
    name: 'iso_slow_40hz',
    description: '[izolowane proby] monitor 40 Hz (frame_ms=25): Python liczy ruch z zmierzonego `dt`, JS z stale `frameDur = 1/60`.',
    seed: SEED,
    frame_ms: 25,
    record_trace: true,
    launcher: true,
    training: false,
    reseed_per_trial: true,
    actions: [
      WELCOME,
      key(0, 250),
      key(1, 300),
    ],
  },
];

export function writeScenarios(dir = SCEN_DIR) {
  mkdirSync(dir, { recursive: true });
  const written = [];
  for (const sc of SCENARIOS) {
    // `description` i `name` nie sa czescia protokolu - zapisujemy je
    // tylko w rejestrze, a plik scenariusza dostaje czyste dane.
    const { description, ...data } = sc;
    const file = path.join(dir, `${sc.name}.json`);
    writeFileSync(file, JSON.stringify(data, null, 2) + '\n', 'utf8');
    written.push({ name: sc.name, file, description: description ?? '' });
  }
  return written;
}

if (import.meta.url === `file://${process.argv[1].replace(/\\/g, '/')}`) {
  for (const w of writeScenarios()) {
    process.stdout.write(`zapisano ${path.relative(process.cwd(), w.file)}  -  ${w.description}\n`);
  }
}
