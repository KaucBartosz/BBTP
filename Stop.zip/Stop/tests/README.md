# Testy parzystości: `Stop/main.py` (PsychoPy) ⇄ `Stop/stop.js` (PsychoJS)

Ten katalog uruchamia **oba pliki źródłowe testu `Stop` w całości i bez żadnej
modyfikacji** — za atrapą frameworka — i porównuje wynik próba po próbie.

Cel: pokazać, **gdzie dokładnie** wersja JS różni się od wersji Python, i udowodnić
to pomiarem, a nie czytaniem kodu. Każda liczba w raporcie pochodzi z uruchomienia
oryginalnych plików.

Raport: [`../out/REPORT.md`](../out/REPORT.md) (zbiorczy),
`../out/<scenariusz>/report.md` (po jednym na scenariusz),
`../out/<scenariusz>/report.json` + `../out/report.json` (wersja maszynowa).

---

## 1. Uruchomienie

Wymagania: **Node.js ≥ 20** (testowane na 22.23) i **Python ≥ 3.10**
(testowane na 3.14). Żaden dodatkowy pakiet nie jest potrzebny — PsychoPy ani
PsychoJS **nie są instalowane**, używane są wyłącznie atrapy z tego katalogu.

```bash
cd Stop

# 1) przepuść każdy scenariusz przez obie wersje (nowy proces dla każdego przebiegu)
node --no-warnings tests/run_all.mjs

# 2) zbuduj raporty porównawcze
node --no-warnings tests/compare.mjs
```

Opcjonalnie tylko wybrane scenariusze:

```bash
node --no-warnings tests/run_all.mjs iso_edge_click iso_touch
node --no-warnings tests/compare.mjs iso_edge_click iso_touch
```

> **Uwaga o PowerShell.** Node pisze na stderr ostrzeżenie
> `MODULE_TYPELESS_PACKAGE_JSON` i PowerShell raportuje wtedy fałszywie
> „exited with code 1". Dlatego w każdej komendzie jest `--no-warnings`.
> Python: `main.py:31` używa `datetime.utcnow()`, deprecated od 3.12 — runner
> uruchamia go z `-W ignore::DeprecationWarning`.

Narzędzia pomocnicze:

```bash
node tests/trace.mjs <scenariusz> <próba> [maxKlatek]   # klatka po klatce, obie wersje naraz
node tests/bundle.mjs lib/psychojs-2025.1.1.js "isPressedIn" 0 800   # fragment z bundla PsychoJS
```

---

## 2. Pliki

```
tests/
  run_all.mjs        uruchamia każdy scenariusz w obu wersjach (osobny proces na przebieg)
  scenarios.mjs      definicja 20 scenariuszy + zapis do tests/scenarios/*.json
  compare.mjs        porównanie wyników i generator raportów (out/)
  trace.mjs          dump klatek z trace dla jednej próby
  bundle.mjs         wycinanie fragmentów z zminifikowanego bundla PsychoJS

  js/                atrapa środowiska przeglądarkowego (gałąź JS)
    loader.mjs         ładowanie `stop.js` w kontrolowanym kontekście
    dom.mjs            minimalne DOM + kolejka `requestAnimationFrame`
    psychojs_stub.mjs  re-implementacja PsychoJS 2025.1.1 (patrz niżej)
    sim.mjs            wirtualny zegar, generator, kolejka zdarzeń, trace
    hooks.mjs          przechwycenie `window.electronTest`, `console`, `performance.now`
    run_stop.mjs       runner: ładuje ORYGINALNY stop.js, zapisuje meta/result/trace

  py/                atrapa PsychoPy (gałąź Python)
    run_main.py        runner: kopiuje ORYGINALNY main.py i uruchamia go przez runpy
    psychopy/
      __init__.py      moduł `psychopy` (podrzuca atrape przed ewentualnym prawdziwym)
      _sim.py          wirtualny zegar, generator, kolejka zdarzeń, trace
      visual.py        Window, ImageStim, TextStim
      event.py         getKeys/waitKeys/clearEvents, Mouse (isPressedIn/getPos/getPressed)
      core.py          getTime/getActualFrameRate/Quit/Exit
```

**Nic w `Stop/main.py` ani `Stop/stop.js` nie zostało zmienione.** Python jest
kopiowany do `out/<scenariusz>/run/main.py` (żeby `results.json` nie lądował w
repozytorium), JS jest importowany wprost z `Stop/stop.js`.

---

## 3. Wspólny protokół

Aparaty obu stron implementują **ten sam** protokół, inaczej porównanie nic nie
znaczy:

| element | reguła |
| --- | --- |
| zegar wirtualny | startuje w `0`, rośnie o `frame_ms` **przy każdej prezentacji klatki** (`win.flip()` / `render()`); `performance.now()` i `core.getTime()` czytają z niego |
| generator losowy | identyczny LCG w obu stronach: `state = (state·1664525 + 1013904223) mod 2³²`, `random() = state / 2³²`, `randint(a,b) = a + ⌊random()·(b−a+1)⌋`; stan startuje z `scenario.seed` |
| wyrównanie strumieni | `stop.js` losuje `expInfo.participant` przy **załadowaniu modułu**, `main.py` losuje `subjectId` dopiero na końcu → harness Pythonu zużywa jedno losowanie przed startem |
| wejście | akcje scenariusza dostarczane **leniwie**, przy każdym odczycie (`getKeys` / `getPressed` / `getPos` / `isPressedIn`), a nie w chwili flipu — dzięki temu obie wersje próbują czytać wejście w tych samych absolutnych momentach wirtualnych |
| scenaariusz | jeden JSON na scenariusz, generowany przez `scenarios.mjs` i czytany przez oba runnery → obie strony dostają dane **bajt w bajt identyczne** |
| granica próby | `event.clearEvents()` (PY) / `eventManager.clearEvents()` (JS) — wywoływane **raz** na próbę, na końcu konfiguracji (po 7 losowaniach) |
| liczniki | `rng_draws_total`, `rng_draws_at_clear`, `rng_window_sizes`, `rng_state_final` — twardy dowód na zgodność lub rozjazd strumienia losowego |

Konsekwencja: **każda różnica w wyniku jest realną różnicą logiki**, a nie
artefaktem harnessa. Wyjątkiem są zjawiska fizyczne, których symulator nie
modeluje (czas reakcji sprzętu, rozmycie, realne odświeżanie monitora) — opisane
niżej w „Założenia".

### Atrapa PsychoJS

`stop.js` to zminifikowany bundl. Jedyne wiarygodne źródło to mapa źródłowa
`Stop/lib/psychojs-2025.1.1.js.map` → `sourcesContent`. Na jej podstawie
odtworzono logikę klas, których używa ten test: `Scheduler`, `Clock`, `Util`
(`to_px` / `to_win` / `getPositionFromObject` / `randint`), `EventManager`,
`Keyboard`, `Mouse`, `Window`, `PsychoJS`, `ExperimentHandler`, `TrialHandler`,
`VisualStim`, `ImageStim`, `TextStim`, `PsychObject`. Miejsca związane z WebGL/PIXI
są zastąpione stanem zapisywanym do symulatora.

Celowo zachowane znane zachowania oryginału (sprawdzone wobec źródeł):

* `Keyboard.getKeys({waitRelease:false})` zwraca naciśnięcia z `KEY_DOWN`, a
  `Keyboard` ignoruje zdarzenia, dopóki nie zostanie `start()`-owany (w
  `welcome` jest to `callOnFlip`);
* `EventManager.getKeys()` zjada (konsumuje) dopasowane klawisze;
* `ExperimentHandler.addData()` zamienia tablice na `JSON.stringify`;
* `ExperimentHandler.isEntryEmpty()` zwraca `keys(...).length > 0` (odwrócona
  logika — tak jest w oryginale 2025.1.1);
* `Window.getActualFrameRate()` liczy z `_lastDelta` schedulera, którego w chwili
  wywołania `updateInfo()` jeszcze nie ma → przez cały przebieg zgłasza 60.0;
* `util.randint(0, 999999)` daje maksymalnie **999998** (`Math.floor(random·(max−min)) + min`),
  a `random.randint(0, 999999)` w Pythonie daje 999999;
* `VisualStim.contains()` używa półotwartego `PIXI.Rectangle.contains`.

### Restart generatora na próbę (`reseed_per_trial`)

Scenariusze `iso_*` restartują LCG na końcu każdej klatki (`state = seed + (N+1)`
przesunięty o 7 kroków). Dzięki temu konfiguracja próby N zależy **wyłącznie** od
N, a nie od tego, ile losowań zużyły poprzednie próby — czyli jedna różnica nie
unieważnia kolejnych prób.

Jedna dziura w tym mechanizmie była i jest testowana: PsychoJS nie prezentuje
ostatniej klatki rutyny (`EachFrame` zwraca `Scheduler.Event.NEXT`, nie
`FLIP_REPEAT`), więc losowania z ostatniej klatki przeciekłyby do konfiguracji
następnej próby. Dlatego `Sim.sealFrame()` (JS) woła to samo, co flip. Kontrola:
`rng_window_sizes` musi mieć **7** w każdej próbie w obu wersjach — raport to
wypisuje.

---

## 4. Scenariusze

Wszystkie po 50 prób (o ile scenariusz nie mówi inaczej), startowe `space` na
ekranie powitalnym, 60 Hz chyba że podano inaczej.

| scenariusz | zegar | `iso` | co sprawdza |
| --- | --- | --- | --- |
| `smoke` | 60 Hz | nie | Test przeszkodowy: 50 prób, 3 poprawne reakcje + 1 falstart. |
| `mixed` | 60 Hz | nie | Każda 5. próba reaguje (klik / spacja / dotyk / falstart / brak). |
| `training` | 60 Hz | nie | `NOUS_TRAINING=1`: Python robi 5 prób, JS zawsze 50. |
| `welcome_key_y` | 60 Hz | nie | Ekran powitalny: klawisz `y` zamiast spacji (oba: brak reakcji). |
| `welcome_very_early` | 60 Hz | nie | SPACJA 5 ms po starcie — JS gubi klawisz (`key_resp.start()` dopiero po 1. flipie). |
| `held_space` | 60 Hz | nie | SPACJA trzymana 1500 ms od chwili pojawienia się znaku (KEY_DOWN przed KEY_UP). |
| `touch` | 60 Hz | nie | Dotyk w środku auta (JS) — Python nie ma obsługi dotyku. |
| `esc_mid` | 60 Hz | nie | ESC w trakcie próby 3. |
| `esc_welcome` | 60 Hz | nie | ESC na ekranie powitalnym. |
| `esc_and_space` | 60 Hz | nie | ESC i SPACJA w tej samej klatce po pojawieniu się znaku. |
| `slow_reported_60` | 25 ms | nie | Monitor 40 Hz, ale JS i tak liczy ruch z `frameDur = 1/60`. |
| `no_response` | 60 Hz | nie | Badanie bez reakcji — ile trwa próba i co trafia do statystyk. |
| `rounding_half` | 60 Hz | nie | Czas reakcji dokładnie 250.5 ms — `round()` (bankers) vs `Math.round()` (half-up). |
| `no_launcher` | 60 Hz | nie | Bez `window.electronTest` — tryb przeglądarkowy. |
| `edge_click` | 60 Hz | nie | Klik dokładnie na krawędzi znaku STOP. |
| `iso_mixed` | 60 Hz | tak | Każda 4. próba reaguje inaczej (spacja / klik w auto / klik w znak / falstart / brak / dotyk). |
| `iso_edge_click` | 60 Hz | tak | Klik dokładnie na każdej z 4 krawędzi bodźca + dwa kliknięcia tuż przy krawędzi. |
| `iso_touch` | 60 Hz | tak | Dotyk w aucie i w znaku. |
| `iso_rounding` | 60 Hz | tak | RT na połowach milisekundy. |
| `iso_slow_40hz` | 25 ms | tak | Monitor 40 Hz: Python liczy ruch z zmierzonego `dt`, JS z `frameDur = 1/60`. |

Scenariusze `iso_*` restartują generator na każdej próbie (patrz wyżej) — dzięki
nim widać **pojedynczą** różnicę, bez kumulowania się rozjazdu.

---

## 5. Co znaleziono (skrót — pełny opis w `out/REPORT.md`)

**Trzy różnice w algorytmie samego testu:**

1. **`dt == 0` w pierwszej klatce każdej próby** — `main.py:117`
   (`last_frame_time = global_start`) + `main.py:128-130` ⇒ dystraktory nie
   ruszają się w klatce 1. `stop.js:706` używa stałego `frameDur = 1/60` ⇒
   zawsze się ruszają.
2. **Zawijanie dystraktora o klatkę później w `stop.js`** — `stop.js:709`/`715`
   testują `pos_j[1] < -0.6` **przed** ruchem, `main.py:148`/`154` — **po** ruchu.
   Zmierzone: pierwsze zawinięcie wypada w obu wersjach w tej samej klatce
   (oba błędy się zniosły), każde następne o jedną klatkę później w JS — w
   scenariuszu `smoke`, próba 0, `jelonek`: klatki PY 32/64/96/128 vs JS
   32/65/98/131. Najniższe `y` w próbie: PY `-0.595895` (ledwo nad progiem),
   JS `-0.611892` (o pełen krok poniżej progu `-0.6`).
3. **Konsekwencja: rozjazd strumienia RNG** — zawinięcie to 2 losowania
   (`Math.random()` na stronę + na odległość), więc różna liczba zawinięć w próbie
   N oznacza zupełnie inne `stopOnset`, pozycje i prędkości we **wszystkich
   kolejnych** próbach. To nie dwie wersje jednego eksperymentu, tylko dwa różne
   eksperymenty. Związek przyczynowy jest zamknięty liczbowo: `Δ losowań =
   2 × Δ zawinięć` zgadza się w **16 z 17** scenariuszy (wyjątek to `training`,
   gdzie okno losowań obejmuje różną liczbę prób, bo `NOUS_TRAINING` daje 5 prób
   w Pythonie i 50 w JS).

**Jedna różnica frameworka:**

4. **Krawędzie bodźca w `isPressedIn`** — PsychoPy `<=` na czterech krawędziach,
   PsychoJS/PIXI `[lo, hi)`. Różnica realna w kodzie, ale **nieobserwowalna** w
   liczbach: predykaty rozjeżdżają się wyłącznie przy marginesie dokładnie równym
   zero, a tam rozstrzyga szum 1 ulp z przebiegu `×720 / ÷720` w PsychoJS
   (`Mouse.getPos` → `to_win` → `getPositionFromObject` → `to_px`). Raport podaje
   zmierzone marginesy (ródu `1e-17` jednostki okna, czyli `~6e-14` px) i wniosek:
   prawdziwy kursor raportuje całkowite piksele, więc szansa trafienia w dokładne
   zero jest rzędu `1/10¹³` na klik.

**Różnice paczki wynikowej** (nie zmieniają zachowania testu): `main.py` dokłada
`totalClicks` (top-level i w `statystyki`) oraz `statystyki.sredni_czas_ms`, i ma
w `score` dodatkowy segment `| Kliknięcia: N`; `stop.js` dopisuje do każdego
wiersza `wyniki` ~30 pól (`drive.*`, `mouse.x`, `trials.*`, `participant`,
`session`, `date`, `expName`, `psychopyVersion`, `OS`, `frameRate`), przy czym
`mouse.x` itd. to **napisy** `"[]"`, nie tablice.

**Pozostałe różnice potwierdzone kodem:** `NOUS_TRAINING` daje 5 prób w Pythonie
i 50 w JS; `no_launcher` nie zapisuje paczki w żadnej wersji; ESC jest sprawdzany
**przed** reakcją w `main.py:167-170` i **na końcu klatki** w `stop.js:800`;
`main.py` w ogóle nie ma obsługi dotyku, a własna `touchToPsycho` w `stop.js:237-244`
liczy pozycję 2× większą niż w jednostkach okna, więc cała gałąź `pointInStim`
(`stop.js:684-691`, `771-787`) jest nieosiągalna.

**Nieobserwowalne mimo różnicy w kodzie:** `round()` (bankers) vs `Math.round()`
(half-up) — `iso_rounding` daje identyczne `sredni_czas_reakcji: 1517` w obu,
bo kwantyzacja do klatek maskuje przypadki połówkowe; `getActualFrameRate()` w
PsychoJS raportuje 60.0 przez cały przebieg, więc przy 40 Hz JS i tak rusza
dystraktory o 1/60 s na klatkę — `iso_slow_40hz` = 50/50 identycznych prób, wpływa
tylko na pozycje, nie na wyniki.

---

## 6. Założenia i ograniczenia harnessa

Pełna tabela (z uzasadnieniem każdego punktu) jest w `out/REPORT.md` → sekcja 5.
Najważniejsze:

1. Okno symulacji ma **1280×720 px**, `units='height'` ⇒ 1 jednostka okna = 720 px.
   Pozycje bodźców są w jednostkach okna (niezależne od rozmiaru), ale kliknięcia —
   nie.
2. Zegar wirtualny przesuwa się **tylko** przy prezentacji klatki. „Czas wirtualny"
   znaczy „czas prezentowany", nie czas ściany. To jest też powód, dla którego
   różnica `frameDur = 1/60` (JS) wobec `dt` (Python) jest widoczna.
3. `frame_ms` jest stałe w obrębie scenariusza; nie modelujemy realnego odświeżania
   monitora ani czasu reakcji sprzętu (klawiatura/mysz).
4. `stop.js` nie jest importowany ponownie w tym samym procesie — każdy przebieg to
   osobny proces (`run_all.mjs`), więc stan globalny modułu nie przecieka między
   scenariuszami.
5. `main.py` jest kopiowany do `out/<scenariusz>/run/`, a `resources/` to dowiązanie
   symboliczne — `results.json` nie lądowuje w repozytorium.
6. Atrapa `isPressedIn` loguje decyzje podmiescione na krawędzi (margines mniejszy
   niż `1e-6` jednostki okna ≈ `7.2e-4` px) — mierzy dokładnie te wartości, które
   porównuje oryginał, w obu wersjach, z pełną precyzją `double`.
7. Zawinięcia dystraktora nie da się wykryć po `y < -0.6` w trace, bo `main.py`
   sprawdza warunek **po** ruchu (pozycja poniżej progu nigdy nie trafia do
   zapisu). `compare.mjs` rozpoznaje je po skoku `y` w górę
   (`wrapIndices()`, próg `WRAP_JUMP = 0.1` jednostki okna; zwykły ruch to maks.
   ok. `0.05`/klatkę, zawinięcie to skok o ok. `0.5`).

## 7. Czego harness nie modeluje

* rzeczywistego czasu reakcji sprzętu (klawiatura/mysz),
* realnego odświeżania monitora — `frame_ms` jest stałe w obrębie scenariusza,
  a `getActualFrameRate()` w PsychoJS raportuje 60 przez cały przebieg
  (`_lastDelta === 0` w pierwszej klatce `updateInfo`),
* deprecacji `webkitResolveLocalFileSystemURL` i realnego wczytywania obrazków —
  stub ładuje je z metadanych bodźców,
* WebGL/PIXI — rysowanie, `zIndex`, `alpha` i geometria renderowania są poza
  zakresem; porównywane są **pozycje i wartości logiczne**, nie piksele.
